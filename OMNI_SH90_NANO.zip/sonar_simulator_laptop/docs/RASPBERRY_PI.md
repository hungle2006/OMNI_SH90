# Chuyển bản laptop sang Raspberry Pi

Giai đoạn hiện tại ưu tiên chạy và kiểm tra trên laptop. Giao diện không phụ thuộc Windows; có thể dùng lại trên Raspberry Pi có desktop, Python 3.9+ và Chromium. Chưa có bước tự sửa hệ điều hành hay cài autostart trong gói này.

## Chạy thử thủ công trên Pi

1. Chép toàn bộ thư mục đã giải nén sang Pi.
2. Mở Terminal trong thư mục, chạy:

```bash
python3 server.py
```

3. Mở địa chỉ `http://127.0.0.1:8765` nếu trình duyệt không tự mở.
4. Thử các nút và phím; đặt chất lượng ở **Cân bằng**.
5. Khi hoạt động tốt, thử:

```bash
python3 server.py --kiosk
```

Không cần Node.js hoặc npm. Tốc độ khung hình và khả năng toàn màn hình cần kiểm tra thực tế trên mẫu Pi đang dùng.

## Hai phần khi cấu hình tự khởi động

- **Server:** dùng systemd để chạy `python3 /đường/dẫn/sonar-trainer/server.py --no-browser` khi khởi động, kèm `Restart=on-failure`.
- **Trình duyệt:** mở Chromium `--kiosk http://127.0.0.1:8765` sau khi phiên desktop đã đăng nhập.

Đường dẫn autostart phụ thuộc phiên desktop / compositor thực tế (ví dụ labwc, Wayfire hoặc LXDE/X11). Cần xác định đúng môi trường trên Pi trước khi thêm cấu hình; không nên ghi đè tệp autostart hiện có bằng cấu hình của một môi trường khác.

Không đưa trình duyệt vào service hệ thống nếu chưa cấu hình phiên đồ họa; server và trình duyệt có thời điểm khởi động khác nhau. Bước nâng cấp này cần thông tin mẫu Pi, phiên bản OS và desktop đang dùng.

## Nút bấm

Khi dùng bàn nút USB HID giả bàn phím, ánh xạ theo bảng trong README và giữ cửa sổ Kiosk có focus. GPIO / encoder thật cần một lớp đọc phần cứng bổ sung; hiện chưa có mã GPIO trong bản laptop.
