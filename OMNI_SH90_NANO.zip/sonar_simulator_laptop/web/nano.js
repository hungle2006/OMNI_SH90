/* USB adapter for the unchanged SH90 controls. No alternate dashboard. */
(()=>{'use strict';
const $=id=>document.getElementById(id),C=window.SonarCore,G=window.SonarCalibration;
const link={connected:false,liveMode:false,status:{},echoes:[],autoPan:false,direction:null,phase:0,holding:null,lastId:0,sweepPaused:false,latestEcho:null};
window.NanoLink=link;
let manualScan=null,scanDeadline=0,scanRevision=0,panPending=null,panRevision=0,sessionId=null,homeCycle=null;
let seq=0,epoch=0,queue=Promise.resolve(),renewBusy=false,keyHeld=null,pointerHeld=null,portOpen=false,lastEvent=0,panTarget=0,desiredScan=false,lastFrame=0;
const clientId=crypto.randomUUID?.()||String(Date.now())+Math.random();
const notice=t=>window.NanoUI?.notify(t);
async function api(path,payload){const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),1500);try{const resp=await fetch(path,payload===undefined?{signal:ctrl.signal}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:ctrl.signal}),data=await resp.json();if(!resp.ok)throw Error(data.error||'USB error');return data;}finally{clearTimeout(timer);}}
async function command(cmd){if(!link.connected)throw Error('Nano chưa kết nối');return api('/api/command',{command:cmd,client_id:clientId,sequence:++seq});}
function run(cmd,valid=()=>true,onError=()=>{}){const e=epoch;queue=queue.catch(()=>{}).then(()=>{if(e===epoch&&valid())return command(cmd);}).catch(err=>{onError();notice(err.message);});return queue;}
function clearTargets(){panPending=null;panTarget=link.status.servo2_deg||0;panRevision++;scanRevision++;}
link.release=()=>{if(!link.holding)return;link.holding=null;keyHeld=null;pointerHeld=null;epoch++;command('MOVE STOP').catch(()=>{});};
link.stop=()=>{clearTargets();scanDeadline=performance.now()+3000;link.sweepPaused=true;manualScan=false;link.release();epoch++;link.autoPan=false;desiredScan=false;command('STOP').catch(err=>notice(err.message));};
link.hold=(dir,key=null,pointer=null)=>{if(!link.connected||!link.status.homed||link.status.motor==='home'){notice('Chờ HOME xong trước khi nâng/hạ.');return;}if(window.NanoUI?.view().power===false){notice('Bật POWER bằng F3 trước.');return;}if(link.holding===dir)return;link.release();link.holding=dir;link.direction=dir;keyHeld=key;pointerHeld=pointer;renew();};
link.toggleMove=dir=>{if(link.holding===dir)link.release();else link.hold(dir);};
async function renew(){if(!link.holding||renewBusy)return;renewBusy=true;try{await command('MOVE '+link.holding);}catch(err){link.release();notice(err.message);}finally{renewBusy=false;}}
setInterval(renew,120);
link.scan=on=>{link.release();if(on&&window.NanoUI?.view().power===false){notice('Bật POWER trước khi quét.');return;}desiredScan=on;manualScan=on;link.sweepPaused=!on;scanDeadline=performance.now()+3000;const revision=++scanRevision;epoch++;command(on?'SCAN START':'SCAN STOP').catch(err=>{if(revision===scanRevision){manualScan=null;desiredScan=!!link.status.scanning;link.sweepPaused=!desiredScan;}notice(err.message);});};
link.toggleScan=()=>link.scan(!desiredScan);
link.panManual=()=>{};
link.auto=k=>{if(k==='autoTilt')link.toggleScan();};
link.power=on=>{if(!on)link.stop();};
link.parameter=(k,v)=>{if(k==='tx'&&v==='OFF')link.scan(false);};
link.setTilt=deg=>{if(link.status.motor==='home'){notice('Chờ HOME xong trước khi đổi góc.');return;}if(!link.connected){notice('Chưa kết nối Nano');return;}panTarget=C.clamp(Math.round(deg/10)*10,-30,30);const revision=++panRevision;panPending={target:panTarget,deadline:performance.now()+3000};run('PAN '+panTarget,()=>revision===panRevision,()=>{if(revision===panRevision){panPending=null;panTarget=link.status.servo2_deg||0;}});};
link.adjust=(k,d)=>{if(k==='tilt'){link.release();run('ARM');run('JOG '+(d>0?'-':'+')+Math.min(5000,Math.max(1,Math.abs(d)*40)));return true;}if(k==='bearing'){link.setTilt(panTarget+(d>0?10:-10));return true;}return false;};
link.readout=()=>!link.connected?'DISCONNECTED · giữ dữ liệu thật, không thay bằng demo':(link.status.motor==='home'?(link.status.home_confirming?'D4 LOW · XÁC NHẬN '+((link.status.home_confirm_ms||0)/1000).toFixed(1)+'/2.0 s':'ĐANG TÌM HOME · D4 HIGH'):(link.status.homed?'HOME OK':'CONNECT'))+' · '+(link.status.pos??0)+' xung · '+(link.status.sonar_ok?(link.status.distance_mm/10).toFixed(1)+' cm':'chưa có phản hồi')+' · S1 '+(link.status.servo1_us??1400)+' µs · S2 '+(link.status.servo2_deg??0)+'°';
link.measurement=()=>link.connected&&link.latestEcho&&Date.now()/1000-link.latestEcho.time<1.4?link.latestEcho:null;
link.projection=()=>{const e=link.measurement();return e?G.project(e.distance_mm/1000,e.servo1_us,e.servo2_deg):null;};
link.findEcho=(cursor,s)=>link.echoes.find(e=>{const p=G.project(e.distance_mm/1000,e.servo1_us,e.servo2_deg),b=C.wrap(s.heading+G.bearing(e.servo1_us,e.servo2_deg));const separation=Math.hypot(cursor.range*Math.sin(cursor.bearing*C.RAD)-p.radial*2*Math.sin(b*C.RAD),cursor.range*Math.cos(cursor.bearing*C.RAD)-p.radial*2*Math.cos(b*C.RAD));return e.distance_mm/1000<=s.range&&Date.now()/1000-e.time<20&&separation<Math.max(.005,s.range*.025);});
link.bearing=()=>G.bearing(link.phase,link.status.servo2_deg||0);
link.draw=(renderer,s)=>{link.renderer=renderer;link.view=s;const now=Date.now()/1000,ctx=renderer.ctx;link.echoes=link.echoes.filter(e=>now-e.time<20);if(!link.connected)return;
 if(!lastFrame){link.phase=link.status.servo1_us??1400;lastFrame=1;}if(manualScan===null)link.phase=link.status.servo1_us??1400;
 if(s.tx==='OFF'||!s.power)return;
 ctx.save();ctx.font='bold 12px Arial';ctx.textAlign='center';ctx.fillStyle='#fffbd0';for(const [b,t] of [[0,'+OY'],[90,'+OX'],[180,'−OY'],[270,'−OX']]){const q=renderer.point(s.heading+b,s.range*.88,s);ctx.fillText(t,q.x,q.y);}ctx.restore();
 ctx.save();ctx.beginPath();ctx.arc(renderer.cx,renderer.cy,renderer.radius,0,Math.PI*2);ctx.clip();
 for(const e of link.echoes){const d=e.distance_mm/1000;if(d>s.range)continue;const projection=G.project(d,e.servo1_us,e.servo2_deg),b=C.wrap(s.heading+G.bearing(e.servo1_us,e.servo2_deg));
 const p=renderer.point(b,projection.radial*2,s),near=1-d/6,fade=Math.max(0,1-(now-e.time)/20),strength=C.clamp((.14+.86*Math.pow(near,.8))*(.4+s.gain/22),.04,1),size=2+strength*5;
 const color=s.palette==='green'?'125,255,135':s.palette==='night'?'255,205,84':near>.6?'255,70,0':near>.25?'255,231,0':'0,244,242';
 const glow=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,size*2.7);glow.addColorStop(0,`rgba(${color},${strength*fade})`);glow.addColorStop(1,`rgba(${color},0)`);ctx.fillStyle=glow;ctx.fillRect(p.x-size*3,p.y-size*3,size*6,size*6);ctx.fillStyle=`rgba(${color},${strength*fade})`;ctx.beginPath();ctx.arc(p.x,p.y,size*.65,0,Math.PI*2);ctx.fill();
 }ctx.restore();};
$('sonar').addEventListener('click',e=>{if(!link.connected||!link.renderer)return;const renderer=link.renderer,s=link.view,rect=$('sonar').getBoundingClientRect(),x=e.clientX-rect.left,y=e.clientY-rect.top;let best=null,nearest=14;
 for(const sample of link.echoes){if(Date.now()/1000-sample.time>20||sample.distance_mm/1000>s.range)continue;const projected=G.project(sample.distance_mm/1000,sample.servo1_us,sample.servo2_deg),point=renderer.point(s.heading+G.bearing(sample.servo1_us,sample.servo2_deg),projected.radial*2,s),dist=Math.hypot(x-point.x,y-point.y);if(dist<nearest){nearest=dist;best={sample,projected};}}
 if(best){const p=best.projected,cm=n=>(n*100).toFixed(1);notice('Điểm đo: d='+cm(best.sample.distance_mm/1000)+' cm | X='+cm(p.x)+' Y='+cm(p.y)+' cm | r='+cm(p.radial)+' cm | Ø vòng quét='+cm(p.diameter)+' cm');}
});
function editable(e){return e.target.closest('input,select,textarea,[contenteditable=true]');}
function blocked(){return document.querySelector('dialog[open]:not(#controlsDialog)');}
document.addEventListener('keydown',e=>{if(!link.connected||e.ctrlKey||e.altKey||e.metaKey||e.isComposing)return;
 if(editable(e)||blocked())return;
 const dir={KeyW:'UP',KeyS:'DOWN',KeyI:'UP',KeyL:'DOWN'}[e.code];
 if(dir){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)link.hold(dir,e.code);return;}
 if(e.code==='Space'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)link.toggleScan();return;}
 if(['KeyA','KeyD'].includes(e.code)){e.preventDefault();e.stopImmediatePropagation();return;}
},true);
document.addEventListener('keyup',e=>{if(e.code===keyHeld){e.preventDefault();link.release();}},true);
// Existing UP/DOWN controls in F2 become press-and-hold motor controls.
function motorButton(target){const b=target.closest('button');if(!b)return null;const adjust=b.dataset.adjust;if(adjust?.startsWith('tilt:'))return {b,dir:adjust.endsWith(':1')?'UP':'DOWN'};if(b.dataset.action==='lower')return {b,dir:'DOWN'};if(b.dataset.action==='hoist')return {b,dir:'UP'};return null;}
document.addEventListener('pointerdown',e=>{if(!link.connected||e.button!==0)return;const m=motorButton(e.target);if(!m)return;e.preventDefault();e.stopImmediatePropagation();m.b.setPointerCapture?.(e.pointerId);link.hold(m.dir,null,e.pointerId);},true);
for(const ev of ['pointerup','pointercancel','lostpointercapture'])document.addEventListener(ev,()=>{if(pointerHeld!==null)link.release();},true);
document.addEventListener('click',e=>{if(link.connected&&motorButton(e.target)&&e.detail!==0){e.preventDefault();e.stopImmediatePropagation();}},true);
window.addEventListener('blur',()=>{link.release();link.autoPan=false;});document.addEventListener('visibilitychange',()=>{if(document.hidden){link.release();link.autoPan=false;}});
window.addEventListener('pagehide',()=>{if(!link.connected)return;link.release();fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:'MOVE STOP',client_id:clientId,sequence:++seq}),keepalive:true}).catch(()=>{});});

async function ports(){try{const {ports}=await api('/api/ports'),old=$('nanoPort').value;$('nanoPort').replaceChildren(new Option('Tự tìm Nano',''));for(const p of ports)$('nanoPort').append(new Option(p.device+' · '+p.description,p.device));if([...$('nanoPort').options].some(o=>o.value===old))$('nanoPort').value=old;}catch{}}
$('nanoBadge').onclick=()=>{link.release();ports();$('nanoDialog').showModal();};$('nanoClose').onclick=()=>$('nanoDialog').close();
$('nanoConnect').onclick=async()=>{try{if($('nanoPort').value)await api('/api/connect',{port:$('nanoPort').value,auto_home:true});else await api('/api/auto',{});}catch(e){notice(e.message);}};
$('nanoDisconnect').onclick=async()=>{link.release();link.autoPan=false;try{await api('/api/disconnect',{});}catch(e){notice(e.message);}};
const goHome=()=>{if(!link.connected){notice('Chưa kết nối Nano. Bấm CONNECT để kiểm tra USB.');return;}link.release();clearTargets();manualScan=false;desiredScan=false;scanDeadline=performance.now()+3000;link.sweepPaused=true;link.autoPan=false;epoch++;command('HOME').catch(err=>notice(err.message));};$('nanoHome').onclick=goHome;$('nanoScopeHome').onclick=goHome;$('nanoStop').onclick=link.stop;$('nanoScopeStop').onclick=link.stop;$('nanoTiltMinus').onclick=()=>link.setTilt(panTarget-10);$('nanoTiltPlus').onclick=()=>link.setTilt(panTarget+10);
function lost(){epoch++;link.release();link.connected=false;link.status={};link.echoes=[];link.latestEcho=null;link.autoPan=false;lastFrame=0;manualScan=null;desiredScan=false;clearTargets();link.sweepPaused=true;window.NanoUI?.lost();}
function layoutReadouts(){
 const toolbar=document.querySelector('.scope-tools'),stage=$('scopeStage'),demo=$('demoReadout');
 const split=window.NanoUI?.view().presentation==='split'?stage.getBoundingClientRect().height*.3:0;
 const base=split+toolbar.getBoundingClientRect().height+16;
 demo.style.bottom=base+'px';$('nanoGeometry').style.bottom=(base+(demo.hidden?0:demo.getBoundingClientRect().height)+8)+'px';
}
function renderMeasurement(state=null){
 const e=link.measurement(),p=link.projection(),hw=link.status,view=window.NanoUI?.view();
 let message;
 if(location.protocol==='file:')message='ĐO THẬT: Đang mở HTML DEMO. Đóng trang này, mở DO_CAM_BIEN_WINDOWS.bat hoặc main.py.';
 else if(!state)message='ĐO THẬT: Chưa kết nối Python. Mở DO_CAM_BIEN_WINDOWS.bat hoặc main.py; xem Terminal.';
 else if(!link.connected)message='ĐO THẬT: '+(state.error|| (state.port_open?'Đang xác minh Nano; chưa có phép đo.':'Chưa kết nối Nano. Cắm USB và nhấn CONNECT để kiểm tra.'));
 else if(hw.motor==='home')message='ĐO THẬT: Đang HOME; chờ công tắc D4 LOW đủ 2 giây.';
 else if(e&&p){
   const cm=n=>(n*100).toFixed(1);
   message='d='+cm(e.distance_mm/1000)+' cm | X='+cm(p.x)+' Y='+cm(p.y)+' cm | r='+cm(p.radial)+' cm | Ø quét='+cm(p.diameter)+' cm | D10 '+e.servo1_us+' µs / D9 '+e.servo2_deg+'°';
   if(!view?.power)message+=' · POWER OFF: F3';else if(view.tx==='OFF')message+=' · TX OFF: P để hiện chấm';
   else if(e.distance_mm/1000>view.range)message+=' · Ngoài Range '+Math.round(view.range*100)+' cm; tối đa 18 cm';
   else if(e.servo2_deg===0)message+=' · Điểm ở tâm O';
 }else if(hw.sonar_ok&&Number.isFinite(hw.distance_mm)&&hw.distance_mm>0)message='d='+(hw.distance_mm/10).toFixed(1)+' cm · '+(hw.orientation_ready===false?'Chưa đặt đủ hai servo để tính tọa độ':'Đang chờ mẫu có góc đo');
 else message='ĐO THẬT: Nano đã kết nối, chưa có mẫu cảm biến hợp lệ. Xem Terminal để kiểm tra.';
 $('nanoGeometry').hidden=false;$('nanoGeometry').textContent=message;$('nanoDistance').textContent=message;
 document.body.dataset.nanoLive=String(link.liveMode);layoutReadouts();
}
window.addEventListener('resize',layoutReadouts);
async function poll(){try{const v=await api('/api/state?since='+link.lastId),was=link.connected;portOpen=!!v.port_open;link.connected=!!v.connected;
 if(v.session_id&&v.session_id!==sessionId){sessionId=v.session_id;epoch++;link.release();link.lastId=0;link.echoes=[];link.latestEcho=null;lastFrame=0;manualScan=null;desiredScan=false;clearTargets();}else link.lastId=Math.max(link.lastId,v.last_id||0);
 if(link.connected){if(v.home_cycle!==undefined&&v.home_cycle!==homeCycle){const reset=homeCycle!==null||v.home_cycle>0;homeCycle=v.home_cycle;if(reset){epoch++;link.release();clearTargets();link.echoes=[];link.latestEcho=null;manualScan=null;desiredScan=false;window.NanoUI?.resetHome();}}link.liveMode=true;link.status=v.status||{};if(manualScan!==null&&(!!link.status.scanning===manualScan||performance.now()>scanDeadline))manualScan=null;if(manualScan===null){link.sweepPaused=!link.status.scanning;desiredScan=!!link.status.scanning;link.phase=link.status.servo1_us??1400;lastFrame=1;}const seen=new Set(link.echoes.map(e=>e.id));link.echoes.push(...(v.echoes||[]).filter(e=>!seen.has(e.id)));link.echoes=link.echoes.filter(e=>Date.now()/1000-e.time<20).slice(-500);link.latestEcho=v.latest_echo||link.echoes.at(-1)||null;if(panPending&&(link.status.servo2_deg===panPending.target||performance.now()>panPending.deadline))panPending=null;if(!panPending)panTarget=link.status.servo2_deg||0;$('nanoTiltValue').textContent=(link.status.servo2_deg>0?'+':'')+(link.status.servo2_deg||0)+'°';

 window.NanoUI?.receive(link.status);if(!was)notice('CONNECT · Nano '+v.port+' · HOME tự động. W/S nâng/hạ; Space quét.');}
 else {lost();if(was)notice('DISCONNECTED · motor ngừng; đang tìm lại Nano.');}
 $('nanoBadge').textContent=link.connected?'● CONNECT':portOpen?'◌ USB…':'○ CONNECT';$('nanoBadge').classList.toggle('connected',link.connected);
 $('nanoBadge').title=link.connected?link.readout():'Nhấn để xem kết nối Arduino Nano';$('nanoStatus').textContent=v.error||(link.connected?'CONNECT · '+v.port:portOpen?'Đang xác minh firmware Nano…':v.auto_connect?'Đang tìm Nano qua USB…':'Đã ngắt kết nối');$('nanoReadout').textContent=link.readout();$('nanoConnect').disabled=portOpen;
 renderMeasurement(v);if(link.connected)$('statusMessage').textContent=link.readout();
 const ev=v.events?.at(-1);if(ev&&ev.time!==lastEvent){lastEvent=ev.time;if(ev.type==='error'){if(manualScan!==null){manualScan=null;desiredScan=!!link.status.scanning;link.sweepPaused=!desiredScan;}const reasons={unexpected_home_switch_during_down:'Đã dừng: D4 bị nhấn ổn định khi đang hạ. Kiểm tra công tắc HOME và dây NO–GND.',home_switch_stuck_low:'Đã dừng: D4 vẫn bị giữ LOW khi rời HOME. Kiểm tra công tắc có nhả và đúng chân NO.'};notice(reasons[ev.message]||'Nano: '+ev.message);}}
 }catch(e){lost();$('nanoBadge').textContent='○ OFFLINE';$('nanoBadge').classList.remove('connected');$('nanoStatus').textContent='Không thấy Python. Mở main.py để dùng Nano.';renderMeasurement();}finally{setTimeout(poll,120);}}
renderMeasurement();
if(location.protocol==='http:'||location.protocol==='https:')poll();else{$('nanoBadge').textContent='○ DEMO';$('nanoStatus').textContent='Mở main.py để dùng Arduino; file HTML chỉ chạy demo.';}
})();
