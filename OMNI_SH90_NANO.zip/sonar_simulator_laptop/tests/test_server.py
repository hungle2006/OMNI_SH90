"""Standard-library tests for the local-only launcher and HTTP surface."""
from pathlib import Path
import json
import socket
import subprocess
import sys
import time
import unittest
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


class LocalServerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            cls.port = sock.getsockname()[1]
        cls.server = subprocess.Popen([sys.executable, str(ROOT / 'server.py'), '--no-browser', '--port', str(cls.port)],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        cls.url = f'http://127.0.0.1:{cls.port}'
        cls.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for _ in range(100):
            try:
                with cls.opener.open(cls.url + '/__sonar_health__', timeout=.2) as response:
                    if response.status == 200:
                        return
            except (OSError, urllib.error.URLError):
                time.sleep(.05)
        raise RuntimeError('Server startup failed')

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.communicate(timeout=5)

    def test_health_and_static_assets(self):
        with self.opener.open(self.url + '/__sonar_health__') as response:
            self.assertEqual(json.load(response)['app'], 'sh90-pc-range-cm-2.6')
        with self.opener.open(self.url) as response:
            self.assertIn('SH90', response.read().decode())
            self.assertEqual(response.headers['Cache-Control'], 'no-store')
            self.assertIn("frame-ancestors 'none'", response.headers['Content-Security-Policy'])
        with self.opener.open(self.url + '/core.js') as response:
            self.assertEqual(response.headers.get_content_type(), 'text/javascript')
            self.assertIn(b'SonarCore', response.read())

    def test_source_outside_web_is_not_served(self):
        for suffix in ['/server.py', '/../server.py', '/%2e%2e/server.py', '/docs/', '/tests/']:
            with self.assertRaises(urllib.error.HTTPError) as error:
                self.opener.open(self.url + suffix)
            self.assertEqual(error.exception.code, 404)

    def test_second_launch_reuses_existing_server(self):
        result = subprocess.run([sys.executable, str(ROOT / 'server.py'), '--no-browser', '--port', str(self.port)],
                                capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0)
        self.assertIn('already running', result.stdout)

    def test_invalid_port_reports_argument_error(self):
        result = subprocess.run([sys.executable, str(ROOT / 'server.py'), '--no-browser', '--port', '80'],
                                capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 2)
        self.assertIn('1024', result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
