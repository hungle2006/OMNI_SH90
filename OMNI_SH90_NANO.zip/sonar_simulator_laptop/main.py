#!/usr/bin/env python3
"""Double-click entry point. Sets up pyserial on first use, then opens the UI."""
from __future__ import annotations
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parent

def launch() -> int:
    os.chdir(ROOT)
    if sys.version_info < (3, 9):
        raise RuntimeError('Can cai Python 3.9 tro len. Chon Add Python to PATH khi cai.')
    if importlib.util.find_spec('serial') is None:
        env_python = ROOT / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        if env_python.exists():
            ready = subprocess.run([str(env_python), '-c', 'import serial; from serial.tools import list_ports; assert hasattr(serial, "Serial")'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
            if ready:
                return subprocess.call([str(env_python), str(ROOT / 'main.py'), *sys.argv[1:]], cwd=ROOT)
        print('Lan dau: dang cai thu vien USB pyserial. Can ket noi Internet.', flush=True)
        if not env_python.exists():
            import venv
            venv.EnvBuilder(with_pip=True).create(ROOT / '.venv')
        subprocess.run([str(env_python), '-m', 'pip', 'install', '-r', str(ROOT / 'requirements.txt')], check=True)
        return subprocess.call([str(env_python), str(ROOT / 'main.py'), *sys.argv[1:]], cwd=ROOT)
    from server import main
    return main()

if __name__ == '__main__':
    try:
        raise SystemExit(launch())
    except Exception:
        details = traceback.format_exc()
        (ROOT / 'startup_error.log').write_text(details, encoding='utf-8')
        print(details)
        try:
            import tkinter as tk
            from tkinter import messagebox
            ui = tk.Tk(); ui.withdraw()
            messagebox.showerror('OMNI Sonar', 'Khong khoi dong duoc. Xem startup_error.log trong thu muc da giai nen.\n\n' + details[-900:])
            ui.destroy()
        except Exception:
            if sys.stdin and sys.stdin.isatty(): input('Nhan Enter de dong...')
        raise SystemExit(1)
