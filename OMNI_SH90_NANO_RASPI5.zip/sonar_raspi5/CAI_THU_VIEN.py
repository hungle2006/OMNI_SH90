#!/usr/bin/env python3
"""Optional library-only check/install; does not connect Nano or move hardware."""
from pathlib import Path
from dependency_setup import ensure_dependencies

if __name__ == '__main__':
    try:
        ensure_dependencies(Path(__file__).resolve().parent)
        print('Thu vien san sang. Chay: python3 main.py')
    except Exception as exc:
        print('Khong cai duoc thu vien:', exc)
        raise SystemExit(1)
