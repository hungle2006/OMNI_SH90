# OMNI SH90 V16 — máy tính, Range 7–18 cm

Giữ giao diện SH90, Nano USB và logic HOME hiện có. Đổi thang cự ly sang cm để xem vật trong bể nhỏ.

## Chạy trên máy tính

1. Đóng Python cũ và Serial Monitor, giải nén toàn bộ ZIP.
2. Mở DO_CAM_BIEN_WINDOWS.bat để có giao diện và Terminal khoảng cách. Có thể dùng START_WINDOWS.bat hoặc `python main.py`.
3. Nano đã nạp firmware hệ thống V14/V15 thì không cần nạp lại: V16 chỉ đổi thang hiển thị/phần mềm máy tính. Nếu Nano đang chạy mã test UART, nạp lại firmware hệ thống trong `firmware/RF_Nano_Omni_Controller` trước khi chạy Python.
4. Cắm USB, đợi CONNECT và HOME OK, rồi bấm Quét servo 1/Space nếu muốn quét.

## Chọn Range

- Các mức chính xác: **7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 cm**.
- Mặc định **18 cm**. Q giảm 1 cm, E tăng 1 cm; kẹp ở 7/18. Chọn trong menu Range hoặc nút −/+ của nhóm Range ở F2 cũng được.
- Không tự chèn thêm các mức theo mét khi CONNECT. Cài đặt cũ 50 m được đưa về 18 cm và bỏ Zoom/Off Centre cũ nếu thang cũ không hợp lệ.
- Menu Range là khoảng cách nghiêng tối đa d; vật xa hơn Range không được vẽ, nhưng số d và Terminal vẫn báo khoảng cách cảm biến gửi về.
- Vòng tròn biểu diễn phép chiếu ngang. Vì D9 giới hạn ±30°, **Rxy = Range/2**, cũng ghi bằng cm. Chọn Range=18 cm thì mép vòng là Rxy=9 cm.
- Ví dụ ảnh của bạn: d=16,5 cm, D9=30° → r=8,25 cm. Khi chọn Range=18 cm, điểm nằm khoảng 91,7% bán kính vòng, nên không còn dồn sát tâm như khi chọn 50 m.
- D9=0° vẫn chiếu tại tâm O; muốn điểm ngoài tâm thì dùng ±10°/±20°/±30° theo hướng đầu dò.

Số trên vòng, HUD, khoảng cách con trỏ, dấu đo, ảnh lưu và phép đo chiếu ngang xuất báo cáo dùng cm. Phép tính nội bộ giữ đơn vị nhất quán, không đổi giá trị cảm biến hay hệ số góc để phóng giả điểm.

## d và các số đo

`d` là khoảng cách đầu dò tới vật theo tia đo, tính bằng cm. X/Y là tọa độ chiếu ngang theo góc D9/D10 lúc lấy mẫu; r là khoảng cách chấm tới tâm. Ø quét=2r là đường kính vòng quét hình học, không phải đường kính vật.

Terminal tự in `SONAR d=... cm` khi có mẫu hợp lệ, không cần bật quét. Nếu d lớn hơn 18 cm, vẫn có số trên Terminal nhưng không hiện chấm trong thang đang chọn.

## Chân giữ nguyên

| Thiết bị | Nano |
|---|---|
| Trắng TX cảm biến | D3 = RX mềm |
| Vàng RX cảm biến | D2 = TX mềm |
| HOME NO về GND | D4 |
| STEP / DIR | D5 / D6 |
| Servo nghiêng / quét | D9 / D10 |

HOME tự động khi kết nối hoặc bấm nút: trục nâng tìm D4, D10=1400 µs về +OY, D9=900 µs về 0°. D4 LOW liên tục 2 giây mới HOME OK; sau đó đứng chờ, không tự quét. Giữ W/S nâng/hạ; thả để dừng; DỪNG dừng cả quét/motor.

Kiểm tra phần mềm: 26 kiểm tra Python, 11 kiểm tra JavaScript lõi/hiệu chỉnh và kịch bản DOM/canvas cho các mức cm, Q/E, dữ liệu 16,5 cm, nhãn HUD, con trỏ và cài đặt cũ. Chưa thử trên máy Windows/Nano thật ở lượt này.
