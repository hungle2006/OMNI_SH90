@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 main.py %*
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Hay cai Python 3.9 tro len tu python.org va chon Add Python to PATH.
    pause
    exit /b 1
  )
  python main.py %*
)
if errorlevel 1 pause
