@echo off
setlocal
cd /d "%~dp0"
title OMNI Sonar - Khoang cach cam bien
echo Giu cua so nay mo de xem d=... cm. Ctrl+C de dung.
call START_WINDOWS.bat %*
pause
