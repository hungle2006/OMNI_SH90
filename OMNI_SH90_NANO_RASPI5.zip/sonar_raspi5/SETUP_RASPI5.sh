#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if (( EUID == 0 )); then
  echo 'Chay bang tai khoan desktop: bash SETUP_RASPI5.sh (khong them sudo o dau).'
  exit 1
fi
if ! command -v apt-get >/dev/null; then
  echo 'Can Raspberry Pi OS / Debian co apt-get.'
  exit 1
fi
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip python3-serial chromium
if [[ " $(id -nG) " != *" dialout "* ]]; then
  sudo usermod -aG dialout "$(id -un)"
  echo 'Da them quyen serial. Can dang xuat/dang nhap lai hoac khoi dong lai Pi.'
fi
chmod +x RUN_RASPI5.sh SETUP_RASPI5.sh
/usr/bin/python3 pi_desktop.py
printf '\nCai dat xong. Sau khi cap nhat quyen serial, chay: bash RUN_RASPI5.sh\n'
