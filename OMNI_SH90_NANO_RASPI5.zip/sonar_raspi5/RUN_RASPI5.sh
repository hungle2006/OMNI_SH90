#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if (( EUID == 0 )); then
  echo 'Khong chay Chromium bang sudo. Dung tai khoan desktop cua ban.'
  exit 1
fi
headless=false
for argument in "$@"; do
  if [[ "$argument" == '--no-browser' ]]; then headless=true; fi
done
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" && "$headless" == false ]]; then
  echo 'Chay trong Terminal tren desktop Pi de mo man hinh.'
  echo 'Neu dung SSH de chi chay server: bash RUN_RASPI5.sh --no-browser'
  exit 1
fi
printf 'OMNI SONAR RASPI 5 | Nano USB | RX D3 - TX D2\n'
printf 'Giu Terminal de xem SONAR d=... cm. Ctrl+C de dung server/motor/quet.\n'
exec /usr/bin/python3 -u main.py --kiosk "$@"
