"""Local, allow-listed Python <-> RF-Nano USB serial bridge.

No internet, no remote control endpoint, no arbitrary serial command execution.
USB discovery verifies OMNI_NANO protocol 3 before automatic HOME.
"""
from __future__ import annotations

import json
import math
import re
import threading
import time
import uuid
from collections import deque
from typing import Any

try:
    import serial
    from serial.tools import list_ports
except ImportError:  # UI demo remains available without pyserial
    serial = None
    list_ports = None

_ALLOWED_EXACT = {"HOME", "ARM", "DISARM", "STOP", "STATUS", "LIMIT", "SCAN START", "SCAN STOP", "MOVE UP", "MOVE DOWN", "MOVE STOP"}


def check_command(command: str) -> str:
    if not isinstance(command, str):
        raise ValueError("Invalid command")
    s = command.strip().upper()
    if s in _ALLOWED_EXACT:
        return s
    patterns = (
        (r"JOG ([+-])([0-9]{1,5})", lambda m: 1 <= int(m[2]) <= 5000),
        (r"TRAVEL ([0-9]{1,5})", lambda m: 0 <= int(m[1]) <= 12000),
        (r"PAN (-?\d{1,3})", lambda m: -30 <= int(m[1]) <= 30),
        (r"SERVO1 ([0-9]{3,4})", lambda m: 500 <= int(m[1]) <= 2500),
        (r"RATE ([0-9]{1,2})", lambda m: 1 <= int(m[1]) <= 30),
    )
    for pattern, valid in patterns:
        match = re.fullmatch(pattern, s)
        if match and valid(match):
            return s
    raise ValueError("Unsupported or out-of-range command")


class NanoBridge:
    def __init__(self) -> None:
        self._serial: Any = None
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._auto_home_pending = False
        self._home_started = False
        self._firmware_seen = False
        self._opened_at = 0.0
        self._last_ping = 0.0
        self._generation = 0
        self._home_cycle = 0
        self._session_id = uuid.uuid4().hex
        self._seq = 0
        self._events: deque[dict[str, Any]] = deque(maxlen=50)
        self._echoes: deque[dict[str, Any]] = deque(maxlen=280)
        self._status: dict[str, Any] = {}
        self._last_rx = 0.0
        self._rx_buffer = bytearray()
        self._log_signature = None
        self._log_at = 0.0
        self._sensor_log_at = None
        self._sensor_log_state = ""
        self._error = ""
        self._port = ""
        self._auto_enabled = False
        self._auto_shutdown = threading.Event()
        self._auto_thread = None
        self._preferred_port = ""
        self._client_motion_until = 0.0
        self._client_sequences: dict[str, int] = {}

    @staticmethod
    def ports() -> list[dict[str, Any]]:
        if list_ports is None:
            return []
        return [{"device": p.device, "description": p.description or "Serial port", "usb": bool(p.vid), "vid": p.vid}
                for p in list_ports.comports()]

    def start_auto(self, preferred_port: str = "") -> None:
        self._preferred_port = preferred_port
        self._auto_enabled = True
        if self._auto_thread is None:
            self._auto_thread = threading.Thread(target=self._auto_loop, daemon=True, name="nano-discovery")
            self._auto_thread.start()

    def _auto_loop(self) -> None:
        while not self._auto_shutdown.wait(0.6):
            if not self._auto_enabled or self._serial is not None:
                continue
            candidates = self.ports()
            candidates = [p for p in candidates if p['device'] == self._preferred_port or p.get('usb') or
                          re.search(r'nano|arduino|ch340|ch341|cp210|ftdi|usb.serial|usb serial', p['description'], re.I)]
            candidates.sort(key=lambda p: p['device'] != self._preferred_port)
            for p in candidates:
                if not self._auto_enabled or self._auto_shutdown.is_set(): break
                try:
                    self.connect(p['device'], auto_home=True)
                    deadline = time.monotonic() + 8
                    while time.monotonic() < deadline and not self._auto_shutdown.wait(.15):
                        if not self._auto_enabled or self._firmware_seen or self._serial is None: break
                    if self._firmware_seen: break
                    self.disconnect(pause_auto=False)
                except (RuntimeError, ValueError):
                    continue
            self._auto_shutdown.wait(2)

    def shutdown(self) -> None:
        self._auto_enabled = False
        self._auto_shutdown.set()
        self.disconnect()
        if self._auto_thread: self._auto_thread.join(timeout=2)

    def connect(self, port: str, auto_home: bool = True) -> None:
        if serial is None:
            raise RuntimeError("Thiếu thư viện pyserial. Chạy: python -m pip install -r requirements.txt")
        if not isinstance(port, str) or len(port) > 80 or not re.fullmatch(r"[\w./:\\-]+", port):
            raise ValueError("Invalid serial port")
        # Strictly accept ports discovered on this machine, not arbitrary device paths.
        if port not in {p["device"] for p in self.ports()}:
            raise ValueError("Cổng COM không có trong danh sách phát hiện")
        with self._lock:
            if self._serial is not None:
                raise RuntimeError("Đang kết nối; ngắt kết nối cũ trước")
            try:
                dev = serial.Serial(port, 115200, timeout=0.12, write_timeout=0.4)
            except (OSError, serial.SerialException) as exc:
                raise RuntimeError(f"Không mở được {port}: {exc}") from exc
            self._serial = dev
            self._port = port
            self._opened_at = time.monotonic()
            self._last_rx = 0
            self._rx_buffer.clear()
            self._log_signature = None
            self._log_at = 0.0
            self._sensor_log_at = None
            self._sensor_log_state = ""
            self._client_motion_until = 0
            self._last_ping = 0
            self._error = ""
            self._status = {}
            self._echoes.clear()
            self._events.clear()
            self._auto_home_pending = auto_home
            self._home_started = False
            self._firmware_seen = False
            self._stop.clear()
            self._generation += 1
            generation = self._generation
            self._thread = threading.Thread(target=self._reader, args=(generation,), daemon=True, name="nano-serial")
            print(f"[{time.strftime('%H:%M:%S')}] USB {port} DA MO | dang xac minh Nano, chua phai du lieu cam bien", flush=True)
            self._thread.start()

    def _send(self, cmd: str) -> None:
        with self._lock:
            if self._serial is None:
                raise RuntimeError("RF-Nano chưa kết nối")
            try:
                self._serial.write((cmd + "\n").encode("ascii"))
                if cmd in ("HOME", "STOP"):
                    print(f"[{time.strftime('%H:%M:%S')}] NANO {self._port} -> {cmd}", flush=True)
            except (OSError, serial.SerialException) as exc:
                self._error = str(exc)
                raise RuntimeError(f"Lỗi Serial: {exc}") from exc

    def command(self, cmd: str, client_id: str = "", sequence: int = 0) -> str:
        safe = check_command(cmd)
        with self._lock:
            if not self._firmware_seen:
                raise RuntimeError("Chưa xác minh firmware OMNI_NANO v3; hãy nạp .ino mới")
            if client_id:
                if len(client_id)>80 or type(sequence) is not int or sequence<1:
                    raise ValueError("Invalid command sequence")
                if sequence <= self._client_sequences.get(client_id, 0):
                    return safe  # Ignore an older HTTP request arriving after STOP.
                if len(self._client_sequences)>30: self._client_sequences.clear()
                self._client_sequences[client_id] = sequence
            if safe in ("STOP", "DISARM"):
                self._auto_home_pending = False
            elif safe == "MOVE STOP" and self._auto_home_pending:
                return safe  # Releasing/reloading the UI must not cancel automatic HOME.
            elif self._auto_home_pending:
                raise RuntimeError("Đang chờ Nano khởi động và tự HOME")
            self._send(safe)
            if safe in ("MOVE UP", "MOVE DOWN"):
                self._client_motion_until = time.monotonic() + .5
            elif safe in ("MOVE STOP", "STOP", "HOME", "DISARM"):
                self._client_motion_until = 0
        return safe

    def _reader(self, generation: int) -> None:
        while not self._stop.is_set() and generation == self._generation:
            with self._lock:
                dev = self._serial
            if dev is None:
                break
            now = time.monotonic()
            try:
                if self._client_motion_until and now > self._client_motion_until:
                    self._send("MOVE STOP")
                    self._client_motion_until = 0
                if not self._firmware_seen and now-self._opened_at > 7.0:
                    raise RuntimeError("Không nhận diện OMNI_NANO v3; kiểm tra firmware và cổng USB")
                if self._last_rx and now - self._last_rx > 3.0:
                    raise RuntimeError("Mất dữ liệu Nano; đang tìm lại USB")
                if now - self._last_ping > 0.65:
                    self._send("PING")
                    self._last_ping = now
                # Never send motor commands to an unverified COM device. Verify firmware JSON first.
                with self._lock:
                    if self._auto_home_pending and now - self._opened_at >= 2.2:
                        if self._firmware_seen:
                            self._send("HOME")
                            with self._lock:
                                self._auto_home_pending = False
                                self._home_started = True
                        elif now - self._opened_at > 7.0:
                            with self._lock:
                                self._auto_home_pending = False
                                self._error = "Không nhận diện OMNI_NANO v3. Nạp file .ino mới trong ZIP và đóng Serial Monitor."
                        elif now - self._opened_at < 7.0:
                            self._send("HELLO")
                raw = dev.readline(384)
                if raw:
                    self._consume(raw)
            except Exception as exc:
                with self._lock:
                    self._error = str(exc)[:220]
                    if not self._stop.is_set():
                        print(f"[{time.strftime('%H:%M:%S')}] USB ERROR: {self._error}", flush=True)
                break
        # Hardware heartbeat stops motor if USB communication is lost.
        with self._lock:
            if generation == self._generation and self._serial is not None:
                try:
                    self._serial.close()
                except Exception:
                    pass
                self._serial = None

    def _consume(self, chunk: bytes) -> None:
        # readline can return a fragment on timeout. Retain it until newline.
        self._rx_buffer.extend(chunk)
        while b"\n" in self._rx_buffer:
            line, _, rest = self._rx_buffer.partition(b"\n")
            self._rx_buffer = bytearray(rest)
            if len(line) <= 380:
                self._on_line(bytes(line))
        if len(self._rx_buffer) > 4096:
            self._rx_buffer.clear()

    def _log_sensor(self, data: dict[str, Any], echo: bool = False) -> None:
        """Console acquisition trace, independent of UI TX, range and scan pause."""
        now = time.monotonic()
        if echo:
            state = "valid"
            if self._sensor_log_state == state and self._sensor_log_at is not None and now-self._sensor_log_at < .25:
                return
            distance_cm = data["distance_mm"]/10.0
            alpha = math.radians((data["servo1_us"]-1400)*.18)
            radius = distance_cm*math.sin(math.radians(data["servo2_deg"]))
            x, y = -radius*math.sin(alpha), radius*math.cos(alpha)
            x, y = round(x, 1) or 0.0, round(y, 1) or 0.0
            message = (f"SONAR d={distance_cm:.1f} cm | D10={data['servo1_us']} us | "
                       f"D9={data['servo2_deg']} deg | X={x:.1f} Y={y:.1f} cm | "
                       f"r={abs(radius):.1f} cm | scan_diameter={2*abs(radius):.1f} cm")
        elif data.get("motor") == "home":
            state = "home"
            message = "SONAR DANG HOME - cho D4 LOW du 2 giay; se do sau HOME"
        elif data.get("sonar_ok") is False:
            state = "waiting"
            message = ("SONAR CHUA CO MAU DO HOP LE | USB Nano OK | "
                       "kiem tra nguon, GND va UART cam bien RX=D3 TX=D2; khong phai ket luan khong co vat")
        else:
            return
        interval = 2.0
        if not echo and self._sensor_log_state == state and self._sensor_log_at is not None and now-self._sensor_log_at < interval:
            return
        print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)
        self._sensor_log_state, self._sensor_log_at = state, now

    def _on_line(self, raw: bytes) -> None:
        if len(raw) > 380:
            return
        try:
            data = json.loads(raw.decode("utf-8", errors="replace"))
        except (ValueError, UnicodeError):
            return
        if not isinstance(data, dict):
            return
        with self._lock:
            kind = data.get("type")
            if kind == "status":
                valid = (data.get("device") == "OMNI_NANO" and data.get("protocol") == 3
                         and type(data.get("homed")) is bool and type(data.get("limit_pressed")) is bool
                         and type(data.get("servo1_us")) is int and 500 <= data["servo1_us"] <= 2500
                         and type(data.get("servo2_deg")) is int and -30 <= data["servo2_deg"] <= 30)
                if not valid:
                    return
                phase = data.get("scan_phase_deg", 0)
                if type(phase) not in (int, float) or not math.isfinite(phase) or not 0 <= phase <= 360:
                    return
                self._firmware_seen = True
                self._last_rx = time.monotonic()
                self._status = {k: data[k] for k in (
                    "device", "protocol", "home_confirming", "home_confirm_ms", "scan_phase_deg", "homed", "armed", "motor", "limit_pressed", "pos", "down_limit",
                    "servo1_us", "servo2_deg", "servo2_us", "orientation_ready", "scanning", "distance_mm", "sonar_ok") if k in data}
                signature=(data.get("limit_pressed"),data.get("motor"),data.get("homed"),data.get("home_confirming",False))
                now=time.monotonic()
                if signature!=self._log_signature or (data.get("motor")=="home" and now-self._log_at>=.5):
                    pin="LOW / NHAN" if data["limit_pressed"] else "HIGH / THA"
                    progress=data.get("home_confirm_ms",0)
                    result="HOME OK" if data["homed"] else "CHO XAC NHAN 2000 ms" if data.get("home_confirming") else "DANG TIM HOME" if data.get("motor")=="home" else "CHUA HOME"
                    print(f"[{time.strftime('%H:%M:%S')}] D4={pin} | {result} | LOW={progress}/2000 ms | motor={data.get('motor','?')}",flush=True)
                    self._log_signature=signature;self._log_at=now
                self._log_sensor(data)
            elif kind == "echo":
                if self._firmware_seen and all(type(data.get(k)) is int for k in ("distance_mm", "servo1_us", "servo2_deg")):
                    if 50 <= data["distance_mm"] <= 6000 and 500 <= data["servo1_us"] <= 2500 and -30 <= data["servo2_deg"] <= 30:
                        phase = data.get("scan_phase_deg", ((data["servo1_us"]-1400)*.18)%360)
                        if type(phase) not in (int, float) or not math.isfinite(phase) or not 0 <= phase <= 360:
                            return
                        self._seq += 1
                        self._echoes.append({"id": self._seq, "time": time.time(),
                                             "distance_mm": data["distance_mm"],
                                             "servo1_us": data["servo1_us"],
                                             "servo2_deg": data["servo2_deg"],
                                             "servo2_us": data.get("servo2_us",900),
                                             "scan_phase_deg": phase})
                        self._log_sensor(data, echo=True)
            elif kind in ("event", "error"):
                message=str(data.get("event") or data.get("message") or "")
                if kind == "event" and message == "homing_up" and self._firmware_seen:
                    self._home_cycle += 1
                    self._echoes.clear()
                    self._client_motion_until = 0
                if message.startswith("home_") or message.startswith("homing") or kind=="error":
                    print(f"[{time.strftime('%H:%M:%S')}] NANO {kind.upper()}: {message}",flush=True)
                self._events.append({"time": time.time(), "type": kind,
                                     "message": str(data.get("event") or data.get("message") or "")[:110]})

    def snapshot(self, since: int = 0) -> dict[str, Any]:
        with self._lock:
            return {"session_id": f"{self._session_id}:{self._generation}",
                    "home_cycle": self._home_cycle,
                    "latest_echo": self._echoes[-1].copy() if self._echoes else None,
                    "connected": self._serial is not None and not self._stop.is_set() and self._firmware_seen,
                    "port_open": self._serial is not None and not self._stop.is_set(),
                    "firmware_ready": self._firmware_seen,
                    "port": self._port, "status": self._status.copy(),
                    "last_rx_age_sec": round(time.monotonic()-self._last_rx, 2) if self._last_rx else None,
                    "auto_home_pending": self._auto_home_pending,
                    "events": list(self._events)[-8:],
                    "echoes": [s.copy() for s in self._echoes if s["id"] > since][-150:],
                    "last_id": self._seq, "auto_connect": self._auto_enabled, "error": self._error}

    def disconnect(self, pause_auto: bool = True) -> None:
        if pause_auto: self._auto_enabled = False
        self._client_motion_until = 0
        with self._lock:
            self._stop.set()
            if self._serial is not None:
                for cmd in ("STOP", "DISARM"):
                    try:
                        self._serial.write((cmd + "\n").encode("ascii"))
                    except Exception:
                        pass
                try:
                    self._serial.close()
                except Exception:
                    pass
                self._serial = None
            self._auto_home_pending = False
            self._home_started = False
            self._firmware_seen = False
        if self._thread and self._thread.is_alive() and threading.current_thread() is not self._thread:
            self._thread.join(timeout=0.5)
