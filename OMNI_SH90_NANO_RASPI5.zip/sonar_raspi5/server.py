#!/usr/bin/env python3
"""Loopback-only HTTP server with a pyserial Nano bridge."""
from __future__ import annotations

import argparse
import functools
import json
from hardware_bridge import NanoBridge
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.error
import urllib.request
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

APP_ID = "sh90-raspi5-autodeps-2.8"
ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map,
                      ".js": "text/javascript", ".css": "text/css", ".json": "application/json"}

    def do_GET(self):
        route = self.path.split('?', 1)[0]
        if route == "/__sonar_health__":
            self._json(200, {"app": APP_ID})
        elif route == "/api/ports":
            self._json(200, {"ports": self.server.bridge.ports()})
        elif route == "/api/state":
            from urllib.parse import parse_qs, urlsplit
            try:
                since = max(0, int(parse_qs(urlsplit(self.path).query).get('since', ['0'])[0]))
            except ValueError:
                since = 0
            self._json(200, self.server.bridge.snapshot(since))
        else:
            super().do_GET()

    def _json(self, code, obj):
        payload = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        if self.path not in ('/api/connect', '/api/disconnect', '/api/command', '/api/auto'):
            self.send_error(404, 'Not found')
            return
        try:
            origin = self.headers.get('Origin', '')
            expected_origin = f'http://127.0.0.1:{self.server.server_port}'
            if origin and origin != expected_origin:
                self._json(403, {'error': 'Cross-origin requests are not allowed'})
                return
            if not self.headers.get('Content-Type', '').lower().startswith('application/json'):
                self._json(415, {'error': 'Use application/json'})
                return
            n = int(self.headers.get('Content-Length', '-1'))
            if n < 0 or n > 512:
                self._json(413, {'error': 'Invalid payload size'})
                return
            data = json.loads(self.rfile.read(n))
            if not isinstance(data, dict):
                raise ValueError('Expected object')
            bridge = self.server.bridge
            if self.path == '/api/connect':
                bridge.connect(data.get('port', ''), auto_home=True)
                bridge.start_auto(data.get('port', ''))
            elif self.path == '/api/auto':
                bridge.start_auto()
            elif self.path == '/api/disconnect':
                bridge.disconnect()
            else:
                bridge.command(data.get('command', ''), data.get('client_id', ''), data.get('sequence', 0))
            self._json(200, {'ok': True})
        except (ValueError, RuntimeError, TypeError) as exc:
            self._json(400, {'error': str(exc)[:220]})

    def list_directory(self, path):
        self.send_error(404, "Not found")

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                         "img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; "
                         "base-uri 'self'; frame-ancestors 'none'")
        super().end_headers()

    def log_message(self, fmt, *args):
        if self.server.verbose:
            super().log_message(fmt, *args)


def is_our_server(port: int) -> bool:
    try:
        # Ignore proxy environment variables for loopback.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f"http://127.0.0.1:{port}/__sonar_health__", timeout=1) as response:
            return json.loads(response.read(1024)).get("app") == APP_ID
    except (OSError, ValueError, urllib.error.URLError):
        return False


def chromium_path() -> str | None:
    names = ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "msedge"]
    for name in names:
        found = shutil.which(name)
        if found:
            return found
    candidates = [
        Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    ]
    for key in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        base = os.environ.get(key)
        if base:
            candidates.extend([Path(base) / "Google/Chrome/Application/chrome.exe",
                               Path(base) / "Microsoft/Edge/Application/msedge.exe"])
    return next((str(p) for p in candidates if p.is_file()), None)


def open_browser(url: str, kiosk: bool = False) -> None:
    if kiosk:
        browser = chromium_path()
        if browser:
            # Separate profile keeps kiosk flags independent from the normal browser.
            profile = Path(tempfile.gettempdir()) / "omni-sonar-kiosk-profile"
            try:
                subprocess.Popen([browser, f"--user-data-dir={profile}", "--kiosk", "--no-first-run",
                                  "--no-default-browser-check", "--disable-session-crashed-bubble", url],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except OSError as error:
                print(f"Cannot start kiosk: {error}")
        print("Chrome/Edge/Chromium not found. Opening default browser; press F for fullscreen.")
    try:
        webbrowser.open(url)
    except webbrowser.Error:
        print("Open this address manually:", url)


def main() -> int:
    parser = argparse.ArgumentParser(description="OMNI Sonar Trainer - local laptop edition")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true", help="Start server only")
    parser.add_argument("--kiosk", action="store_true", help="Open Chromium/Chrome/Edge kiosk")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--serial-port", default="", help="Auto-connect RF-Nano COM port and start HOME")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("--port must be from 1024 to 65535")
    if not (WEB / "index.html").is_file():
        print("Missing web/index.html. Extract the entire ZIP before launching.")
        return 1
    url = f"http://127.0.0.1:{args.port}"
    handler = functools.partial(Handler, directory=str(WEB))
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    except OSError as error:
        if is_our_server(args.port):
            print(f"Sonar Trainer is already running: {url}")
            if not args.no_browser:
                open_browser(url, args.kiosk)
            return 0
        print(f"Cannot open port {args.port}: {error}")
        print("Try: python server.py --port 8766")
        return 1
    server.verbose = args.verbose
    server.bridge = NanoBridge()
    server.bridge.start_auto(args.serial_port)
    print("\nSH90 ORIGINAL UI | NANO USB")
    print("USB auto-connect | Arduino Nano protocol 3 | automatic HOME")
    print("SONAR LOG: khoang cach d=... cm se hien tu dong sau HOME, toi da 4 dong/giay.")
    print("Neu chua nhan du lieu: SONAR CHUA CO MAU DO HOP LE. Khong can bam quet de xem so cm.")
    print(f"\nOpen: {url}")
    print("Keep this window open. Ctrl+C stops the server.")
    if args.kiosk:
        print("Kiosk exit: Alt+F4 (Windows/Linux) or Cmd+Q (macOS).")
    print("Open main.py for automatic dependency setup.\n", flush=True)
    if not args.no_browser:
        threading.Timer(.4, open_browser, args=(url, args.kiosk)).start()
    try:
        server.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.bridge.shutdown()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
