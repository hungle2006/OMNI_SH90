# Đối chiếu chức năng demo v3 — 25/10/2026

Nguồn chính là **Simrad SH90 Operator Manual**, mã 323773/F, phần Operating Panel, Echo presentations, Store/Recall; đây là tài liệu của Simrad/Kongsberg, không phải hướng dẫn suy ra từ ứng dụng khác.

- Operator Manual: https://www.simrad.online/sh90/opm/sh90_opm_en_a4.pdf
- Bản tương tác, nêu software 2.1.8: https://www.simrad.online/sh90/opm_english/sect1.html
- SH90 Reference Manual tiếng Hàn, phần Various, trang in 191–192: https://www.simrad.online/sh90/ref/sh90_ref_korean.pdf

Bản v2 chủ yếu dựng các hàng menu trong ảnh. Bản v3 mở rộng những thao tác có thể luyện độc lập bằng dữ liệu tổng hợp:

| Phần còn thiếu ở v2 | Bản v3 |
| --- | --- |
| Main switch / đầu dò | Power, Lower, Hoist và trạng thái chặn phát |
| Chỉnh V riêng | Range V, Gain V và mặt cắt đơn giản |
| Các nút Mode | Bốn cấu hình trình bày cố định cho demo |
| Cursor / menu | Phím điều hướng con trỏ, Select, View, Object, Menu |
| Tự đổi góc | Auto/Manual cho Tilt và Bearing |
| Quan sát chi tiết | Zoom, Off Centre, Mute |
| Lưu ảnh | Record đơn/chuỗi, danh sách ảnh, Recall, Download, Delete |
| Symbol | Dấu đo, dấu tàu, vòng tròn và biểu tượng ngư cụ |
| Cấu hình cá nhân | Bốn ô Save/Recall |

Cách chọn phím, chu kỳ Auto, thời gian cơ cấu 3 giây, chuỗi ảnh 2 giây, cung mặt cắt ±15° và giới hạn 12 ảnh là **quy ước của phần mềm này**. Không xem chúng là thông số SH90 thật. Sweep Line là hiệu ứng minh họa dễ bật; không dùng nó để mô tả cơ chế thu phát của Omni Sonar.

Circle/Gear chỉ vẽ biểu tượng; không tính kích thước lưới. Trackball demo điều khiển dấu đo, không thay con trỏ hệ điều hành. Select đưa focus vào trình chỉnh thông số hoặc đóng menu. Ảnh xuất chứa phần sonar/mặt cắt và thông số, không chụp các hộp thoại hay toàn desktop.

Chưa tái tạo: xử lý tín hiệu OEM, Position/Target Tracking, True Motion theo tọa độ địa lý, dữ liệu catch, chu trình ngư cụ, dữ liệu NMEA/GPS/MRU thật, installation/calibration, mạng nhiều máy, máy in/USB tự động hoặc điều khiển cơ cấu thật. Không có nút giả chỉ để báo “đã bấm” cho các phần chưa triển khai.

Phần mềm giữ mục tiêu luyện cách dùng giao diện dân dụng với dữ liệu giả lập; kết quả chấm bài phản ánh thao tác trong chương trình.
