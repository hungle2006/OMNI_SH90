# Kiểm tra V16 PC — Range cm

Kết quả đã chạy:

Bổ sung V13: kiểm tra log khoảng cách cm và tọa độ lúc servo dừng; loại mẫu ngoài dải không in thành số đo; thông báo chưa có mẫu hợp lệ và giới hạn tốc độ log (4 dòng/giây cho phép đo, 1 dòng/2 giây khi đang chờ). Kiểm tra DOM dòng đo không ẩn khi chưa nối/mất Nano và ô khoảng cách trong CONNECT hiển thị số cm khi có mẫu. Chưa kiểm tra cửa sổ .bat/Chromium trên Windows thật.

Bổ sung V12: mô phỏng HOME nhiều lần từ góc D10=2200/D9=−30°, kiểm tra đặt lại 1400/900 µs, không tự quét, khóa lệnh góc khi HOME, tiếp tục tìm lên khi D4 HIGH, xác nhận LOW 2 giây, xóa mẫu đang chờ và ngừng lấy tọa độ trong HOME. Kiểm tra bridge tăng chu kỳ HOME và xóa mẫu cũ; DOM nhận kim +OY, góc 0°, con trỏ tâm và xóa vết cũ sau nút HOME. Luồng tự nối lại vẫn gửi đúng một HOME mỗi kết nối và dùng chung quy trình firmware.

- 26 kiểm tra Python: HTTP local, xác minh firmware, tự kết nối/HOME và nối lại USB, chống lệnh cũ đến sau DỪNG, lease motor, khung serial bị chia nhỏ, khoảng cách tới 6000 mm, mã phiên và mẫu đo mới nhất giữ góc lúc thu.
- 11 kiểm tra JavaScript lõi/hiệu chỉnh: mốc D9, phương vị D10, tâm và dấu X/Y, phép chiếu và đường kính quét, đổi tọa độ màn hình trong các chế độ gốc.
- 1 kịch bản tích hợp DOM + canvas chạy chung mã web thật: giữ 14 hàng thông số và aspect/Range khi CONNECT; W/S và thả phím/mất focus; bỏ A/D/U/B/Esc/Home; nút HOME/DỪNG; ±10° kẹp ±30°; phản hồi góc chậm hơn 400 ms; dừng kim lúc chờ và nhận xung cuối sau xác nhận; khôi phục sau START bị từ chối; nhận chấm sau Python khởi động lại; không dùng dữ liệu cũ làm tọa độ mới, không vẽ vật demo khi mất USB.
- Firmware .ino biên dịch/chạy với Arduino/Servo/Serial giả lập trên máy tính: hạ hơn 12000 xung, lease/watchdog, công tắc rung, HOME LOW liên tục 2 giây và không phát xung khi xác nhận, không attach servo lúc boot, HOME không tự quét; xung mô hình HIGH 500 µs / LOW 500 µs; mẫu đo không có hướng trước khi bật đủ hai servo; SCAN khởi tạo D9 sau SERVO1; DISARM dừng quét; watchdog dừng quét khi motor đang idle; dòng status vừa giới hạn bridge kể cả bộ đếm lớn.

Chưa biên dịch với toolchain AVR và chưa có Nano/cảm biến/cơ cấu thật để đo thời gian xung, độ trễ servo hay độ chính xác góc. Kiểm tra giao diện ở mức DOM/canvas; không phải xác nhận bố cục bằng trình duyệt thật.

Các lệnh kiểm tra phát triển (không cần để chạy ứng dụng):

```sh
python3 -m unittest discover -s tests -p 'test*.py' -q
node --test tests/core.test.cjs tests/calibration.test.cjs
node --test tests/original-nano.test.cjs
g++ -std=c++17 -Itests/firmware_stubs tests/test_firmware.cpp -o /tmp/sonar-test
/tmp/sonar-test
```

Kiểm tra DOM cần jsdom và @napi-rs/canvas. Có thể đặt SONAR_TEST_NODE_MODULES và CODEX_PRIMARY_RUNTIME_NODE_MODULES nếu chúng nằm ngoài dự án. Các tệp browser.test.cjs/demo.test.cjs là bộ kiểm tra trình duyệt của giao diện gốc, chưa được chạy lại ở lượt V11 do môi trường Chromium bị hạn chế.

Đối chiếu nhanh trên bộ thật: nạp .ino V12, đóng Serial Monitor và mở main.py; kiểm tra terminal chỉ HOME OK sau D4 LOW đủ 2 giây, servo chờ đến khi bấm quét. Với vật d=100 cm, D10=1400 và D9=+30°, mẫu phải cho X≈0, Y≈+50 cm, Ø quét≈100 cm; D9=−30° đổi Y thành âm. Sai lệch cơ khí cần hiệu chuẩn thực tế, vì Nano chỉ báo góc lệnh chứ không đo góc trục bằng encoder.

V14: kiểm tra biên dịch logic firmware với hằng SONAR_RX=3/SONAR_TX=2; mã test riêng cũng cấu hình RX D3/TX D2 và vẫn phân biệt các khung UART mẫu. Chưa kiểm tra cảm biến thật.

V16: kiểm tra Range 7..18 cm mặc định 18 cm; Q/E và kẹp biên; CONNECT không thêm mức mét; phục hồi cài đặt cũ 50 m/Zoom/Off Centre; HUD Rxy=9 cm và con trỏ=5,0 cm; nhãn vòng cm; phép chiếu d=16,5 cm/D9=30° ở 11/12 bán kính vòng khi Range=18 cm.

V17: ghép bản cm vào Raspberry Pi 5, cập nhật tên tệp chạy trong thông báo giao diện. Kiểm tra cú pháp launcher, Python và các bộ kiểm tra bridge/HTTP, core/calibration, DOM/canvas. Chưa thử trên Pi 5 hoặc đo tốc độ khung hình thực.

V18: 36 kiểm tra Python qua, bổ sung bootstrap main.py, .venv và cài thư viện khai báo còn thiếu. Lệnh pip/apt được mô phỏng trong kiểm tra, không tự chạy trình cài hệ điều hành trên máy kiểm tra. GUI/Nano không đổi; chưa xác nhận cài gói trên Raspberry Pi OS thật.
