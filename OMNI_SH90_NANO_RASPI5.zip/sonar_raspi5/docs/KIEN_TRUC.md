# V10

main.py → server local → NanoBridge protocol 3 → Nano D9/D10.

Firmware gửi khoảng cách và xung D10/góc D9 được ghi tại lúc yêu cầu đo. Không dùng chiều chuyển động servo để tạo pha vòng giả. calibration.js quy đổi D10 1400=0°, 360°/2000µs; D9 500/900/1200=−30°/0°/+30°; chiếu r=d sinθ rồi tính X,Y và Ø quét=2|r|. Renderer vẫn giữ giao diện SH90 và vòng đo thật theo thang Rxy=Range/2.

PAN command chỉ chấp nhận −30…+30, hai nút ±10° là nguồn điều khiển D9. A/D và tự lia bị bỏ. Firmware protocol 3 ngăn Python mới điều khiển nhầm firmware cũ có mốc D9 khác.

V11: bridge cung cấp session_id và latest_echo có timestamp/góc thu mẫu; lớp giao diện không ghép distance_mm trong status với góc tức thời để tính X/Y. Khi đổi phiên, reset chỉ số nhận mẫu. Echo chỉ được nhận từ bo đã xác minh; firmware không phát echo tọa độ khi chưa đặt đủ hai servo. orientation_ready báo tính sẵn sàng của đầu ra servo, không phải phản hồi encoder.

V12: startHome() là đường setup chung cho tự kết nối và nút HOME: dừng scan, ghi D10=1400/D9=900, nâng lên và xác nhận D4 LOW 2 giây. Trong HOMING khóa đổi góc và tạm ngừng lấy mẫu tọa độ. Sự kiện homing_up tăng home_cycle trên bridge, xóa phản hồi cũ; UI nhận chu kỳ mới và đặt con trỏ về O.

V14: đổi UART mềm cảm biến: Nano RX D3 nhận trắng TX; Nano TX D2 nối vàng RX. Không thay đổi STEP D5, DIR D6, HOME D4, servo D9/D10 hoặc phép chiếu.
