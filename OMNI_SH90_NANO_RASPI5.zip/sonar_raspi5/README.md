# OMNI SH90 V18 — Pi 5, main.py tự cài thư viện còn thiếu

Dùng Raspberry Pi OS 64-bit có Desktop và Chromium. Pi chạy Python/giao diện; Nano vẫn điều khiển motor, servo và đọc cảm biến. Không chuyển các dây thiết bị sang GPIO Pi.

## Chạy trực tiếp main.py

Giải nén toàn bộ ZIP, mở Terminal trong thư mục chứa main.py và chạy:

```bash
python3 main.py
```

Toàn màn hình:

```bash
python3 main.py --kiosk
```

main.py tự kiểm tra thư viện trước khi mở server và kết nối Nano. Hiện dự án cần pyserial (module Python tên serial). Nếu thiếu hoặc cài nhầm module serial, chương trình tạo môi trường riêng `.venv`, cài đúng thư viện từ requirements.txt, kiểm tra lại rồi tự chạy tiếp. Không cài pip vào Python hệ thống, không dùng --break-system-packages.

Nếu máy đã đủ thư viện, chạy không cần Internet; không tải lại mỗi lần và không tự nâng mọi gói lên phiên bản mới nhất. Khi đã có .venv hợp lệ, ứng dụng ưu tiên dùng lại. Lần cần cài thư viện mới cần Internet. Nếu cài lỗi, chương trình dừng, báo lý do và ghi startup_error.log; không khởi động HOME khi bootstrap chưa xong.

Có thêm tệp **CAI_THU_VIEN.py** để chỉ kiểm tra/cài thư viện, không kết nối Nano hoặc chạy motor:

```bash
python3 CAI_THU_VIEN.py
```

Nếu Raspberry Pi OS chưa có hỗ trợ tạo venv, chương trình báo lệnh cài một lần:

```bash
sudo apt install python3-venv python3-pip
```

Sau đó chạy lại `python3 main.py`. Chromium và quyền USB dialout là thành phần hệ điều hành, dùng script cài đặt bên dưới nếu Pi chưa có. Không chạy main.py với sudo.

Không tải tự động các tệp mã nguồn bị thiếu như server.py/hardware_bridge.py từ Internet; hãy giải nén toàn bộ ZIP. Thư viện bên thứ ba được cài theo danh sách requirements.txt của dự án.

## Cài lần đầu

Giải nén ZIP, mở Terminal trong thư mục `sonar_raspi5` chứa main.py:

```bash
bash SETUP_RASPI5.sh
```

Tệp này cài Python, hỗ trợ venv/pip, pyserial và Chromium bằng apt, thêm người dùng hiện tại vào nhóm dialout nếu cần và tạo shortcut OMNI Sonar Nano trong menu ứng dụng/desktop. Cần Internet và quyền sudo lúc cài. Không chạy toàn bộ script với sudo. Không cần Node.js/npm hoặc pip vào Python hệ thống.

Nếu được thêm nhóm dialout, đăng xuất/đăng nhập lại hoặc khởi động lại Pi trước khi chạy.

## Chạy

1. Nano cần firmware hệ thống `firmware/RF_Nano_Omni_Controller/RF_Nano_Omni_Controller.ino` trong gói. Nếu đã nạp firmware hệ thống V14/V15/V16 thì giữ nguyên; lượt này không đổi mã điều khiển Nano. Nếu đang chạy mã test UART thì nạp lại firmware hệ thống; mã test không kết nối được với giao diện Python.
2. Cắm Nano vào USB Pi, đóng Serial Monitor và chương trình khác đang giữ cổng.
3. Từ Terminal trên desktop Pi chạy:

```bash
bash RUN_RASPI5.sh
```

Hoặc mở shortcut OMNI Sonar Nano, cho phép khởi chạy nếu desktop yêu cầu. Shortcut mở Terminal để giữ log và Chromium toàn màn hình. Nếu di chuyển thư mục, chạy `python3 pi_desktop.py` để cập nhật shortcut.

- Tự tìm USB và xác minh Nano rồi HOME: nâng trục tìm D4, D10=1400 µs (+OY), D9=900 µs (0°, tâm O), xác nhận D4 LOW đủ 2 giây.
- Sau HOME đứng chờ. Space/Quét servo 1 bắt đầu quét; W/S giữ nâng/hạ, thả để dừng. ±10° đổi D9 trong ±30°.
- Terminal hiện `SONAR d=... cm` khi có mẫu hợp lệ, kể cả khi servo đang dừng.
- DỪNG trên giao diện hoặc Ctrl+C tại Terminal để dừng. Alt+F4 chỉ đóng trình duyệt kiosk; server trong Terminal vẫn còn chạy.
- Mở bằng trình duyệt thường: `python3 main.py`. Địa chỉ local: `http://127.0.0.1:8765`.
- Chỉ chạy server qua SSH: `bash RUN_RASPI5.sh --no-browser`. Server lắng nghe loopback; giao diện mở trên chính Pi.

Tệp này không tự sửa autostart của hệ điều hành. Kiosk mở trong phiên desktop đang đăng nhập, dùng Chromium trên Wayland/X11.

## Range bằng cm

- Chọn **7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 cm**; mặc định **18 cm**.
- Q giảm / E tăng 1 cm, hoặc chọn menu Range. CONNECT không chèn lại mức mét.
- HUD, vòng đo, con trỏ, dấu đo và ảnh lưu đều dùng cm. Dữ liệu cự ly/Zoom cũ không phù hợp được chuyển về thang mới khi tải lại.
- Range là khoảng cách nghiêng tối đa d; Rxy là bán kính chiếu ngang tối đa, bằng Range/2 do D9 giới hạn ±30°.
- Ví dụ Range=18 cm → Rxy=9 cm. Vật d=16,5 cm, D9=30° nằm cách tâm 8,25 cm, khoảng 91,7% bán kính vòng. D9=0° thì điểm vẫn ở tâm O.
- Vật xa hơn Range không được vẽ; Terminal vẫn hiện d đo được, kể cả lớn hơn 18 cm.

## Chân Nano hiện tại

| Thiết bị | Chân |
|---|---|
| **Trắng TX cảm biến** | **D3 = RX Nano** |
| **Vàng RX cảm biến** | **D2 = TX Nano** |
| HOME NO về GND | D4 |
| STEP / PUL | D5 |
| DIR | D6 |
| Servo nghiêng | D9 |
| Servo quét | D10 |

Giữ nguồn phù hợp và GND chung của hệ thống hiện có. Dùng cáp USB dữ liệu nối Pi với Nano.

## Khi chưa có phép đo

Log `RX_BYTES=0` bạn đã gặp nghĩa là Nano chưa nhận byte từ cảm biến. Chuyển sang Pi không tự sửa được đường UART đó; tiếp tục kiểm tra nguồn/GND, TX/RX và đúng model.

Mã test riêng RX D3/TX D2 nằm ở `firmware/NANO_SONAR_UART_TEST`. Khi test, đóng Python, nạp mã test và mở Serial Monitor 115200. Sau test cần nạp lại firmware hệ thống.

Nếu Pi báo Permission denied ở cổng USB, kiểm tra `id -nG` có dialout; đăng nhập lại sau khi script cài thêm nhóm. Không chạy Chromium/main.py bằng sudo để né lỗi quyền.

Đã kiểm tra 36 tình huống Python, gồm main.py khởi động server, giữ tham số khi chuyển sang .venv, cài thiếu, dùng lại khi offline, lỗi pip/venv và không lặp cài vô hạn; kiểm tra cú pháp launcher. Phần giao diện cm/firmware giữ nguyên bản đã kiểm tra trước. Không chạy trình cài apt lên máy kiểm tra. Chưa thử trên Pi 5/Nano/cảm biến thật. Chi tiết hiệu chỉnh tọa độ và phím có trong README_PC.md/PHIM_CHUC_NANG.md.

Tham khảo nền tảng:
https://www.raspberrypi.com/documentation/computers/os.html
https://www.raspberrypi.com/tutorials/how-to-use-a-raspberry-pi-in-kiosk-mode/
https://support.arduino.cc/hc/en-us/articles/360016495679-Fix-port-access-on-Linux
