@echo off
cd /d "%~dp0"
call START_WINDOWS.bat --kiosk %*
