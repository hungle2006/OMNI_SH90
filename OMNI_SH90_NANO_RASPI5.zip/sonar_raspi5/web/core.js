/* Offline, deterministic display trainer. Angles: true north, clockwise. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.SonarCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = '3.0.0';
  const RAD = Math.PI / 180;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const wrap = v => ((v % 360) + 360) % 360;
  const angleDiff = (a, b) => ((a - b + 540) % 360) - 180;
  function random(seed) {
    let a = seed >>> 0;
    return function () {
      a += 0x6D2B79F5;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const PARAMS = {
    range: {label:'Range', vn:'Cự ly', values:Array.from({length:12},(_,i)=>(i+7)/100), unit:'cm'},
    tilt: {label:'Tilt', vn:'Góc nghiêng', min:-90, max:0, step:1, unit:'°'},
    bearing: {label:'Bearing', vn:'Hướng đường chọn, tương đối với mũi tàu', min:0, max:359, step:1, wrap:true, unit:'°'},
    gain: {label:'Gain', vn:'Độ khuếch đại', min:0, max:40, step:1},
    pulse: {label:'Pulse Form', vn:'Dạng xung', values:['FM AUTO','SHORT','LONG']},
    tx: {label:'TX Power', vn:'Công suất phát', values:['OFF','LOW','MEDIUM','FULL']},
    beam: {label:'Beam', vn:'Độ rộng chùm', values:['AUTO','NARROW','WIDE']},
    frequency: {label:'Frequency', vn:'Tần số mô phỏng', values:[85,114,120], unit:'kHz'},
    tvg: {label:'TVG', vn:'Bù suy hao cự ly', values:[10,20,30,40], unit:'LOG R'},
    agc: {label:'AGC', vn:'Tự động điều chỉnh', values:['OFF','LOW','MEDIUM','HIGH']},
    rcg: {label:'RCG', vn:'Giảm nhiễu gần', min:0, max:5, step:1},
    noise: {label:'Noise Filter', vn:'Lọc nhiễu', values:['OFF','LOW','MEDIUM','HIGH']},
    bottom: {label:'Bottom Filter', vn:'Lọc phản hồi đáy', min:0, max:5, step:1},
    pp: {label:'PP Filter', vn:'Lưu ảnh phản hồi', values:['OFF','LOW','MEDIUM','HIGH']},
  };
  const DEFAULTS = Object.freeze({
    range:.18, tilt:-2, bearing:60, gain:19, pulse:'FM AUTO', tx:'LOW', beam:'AUTO',
    frequency:114, tvg:20, agc:'MEDIUM', rcg:2, noise:'MEDIUM', bottom:0, pp:'MEDIUM',
    heading:250, speed:0, orientation:'bow', palette:'classic', rings:true, sweep:false,
    trails:true, sound:false, simSpeed:1, sweepSeconds:8, quality:'balanced',
    aspect:'wide',ship:true,labels:true,cursorVisible:true,sector:360,
    power:true,hull:'DOWN',presentation:'horizontal',rangeV:.18,gainV:19,
    autoTilt:false,autoTrain:false,tiltCenter:-2,tiltSpan:10,trainCenter:60,trainSpan:60,
    zoom:false,zoomBearing:158,zoomRange:.045,offCentre:false,offX:.51,offY:.51,menuHidden:false,
    latitude:-.0002166667,longitude:-.0002333333,
  });
  function normalize(key, value) {
    const p = PARAMS[key];
    if (!p) return undefined;
    if (p.values) return p.values.includes(value) ? value : undefined;
    if (typeof value !== 'number' || !Number.isFinite(value)) return undefined;
    return p.wrap ? wrap(Math.round(value)) : clamp(Math.round(value), p.min, p.max);
  }
  function adjust(state, key, delta) {
    const p = PARAMS[key];
    if (!p) return false;
    if (p.values) {
      const index = p.values.indexOf(state[key]);
      state[key] = p.values[clamp(index + delta, 0, p.values.length - 1)];
    } else state[key] = normalize(key, state[key] + delta * p.step);
    return true;
  }
  const contact = (id, range, bearing, strength, width, depth = 1, extra = {}) =>
    ({id, range, bearing, strength, width, depth, radial:0, angular:0, kind:'echo', ...extra});
  const SCENARIOS = [
    {
      id:'reference', name:'01 · Làm quen bảng máy', subtitle:'Tín hiệu rõ · bố cục theo ảnh tham chiếu',
      description:'Thực hành chỉnh cự ly, độ khuếch đại và đặt dấu đo trên các cụm phản hồi giả lập.',
      seed:90268, noise:0.24, duration:0,
      contacts:[
        contact('E01',34,227,1,16), contact('E02',29.7,222,1,14),
        contact('E03',25.7,218,.98,13), contact('E04',21.8,209,.72,9),
        contact('E05',19.6,193,.97,17), contact('E06',15.5,177,.99,12),
        contact('E07',11.7,158,1,15), contact('E08',16.2,134,.98,13),
        contact('E09',23.8,111,1,17), contact('E10',28.2,96,1,19),
        contact('E11',39.4,91,.45,13), contact('E12',45.5,186,.97,13),
        contact('E13',43.2,150,.82,13), contact('E14',43.8,139,.99,13),
        contact('E15',31.2,252,.98,18), contact('E16',34.8,277,.86,14),
        contact('E17',43.2,296,.90,16), contact('E18',8.5,121,1,15),
        contact('E19',4,11,.96,12),
        contact('E20',16,181,.98,8), contact('E21',12.6,162,.94,8),
        contact('E22',18.1,199,.62,7), contact('E23',37.5,221,.38,19),
        contact('E24',40.5,213,.32,13), contact('E25',33.9,272,.30,15),
        contact('E26',31.8,191,.25,10),
        contact('E27',8.1,126,.98,10),contact('E28',9.1,116,1,10),contact('E29',7.4,122,.98,11),
        contact('B01',45,294,.38,22,2,{kind:'bottom'}),
      ],
      lesson:'basic',
    },
    {
      id:'clutter', name:'02 · Điều chỉnh tín hiệu', subtitle:'Nhiễu nền cao · phản hồi gần và xa',
      description:'Thực hành giảm nhiễu, bù cự ly và đọc đường đo khi có phản hồi đáy.',
      seed:1941, noise:.85, duration:360,
      contacts:[
        contact('E01',34,316,.86,14,2), contact('E02',66,33,.92,13,4),
        contact('E03',81,83,.75,18,3), contact('E04',47,203,.89,12,2),
        contact('B01',72,220,.9,58,5,{kind:'bottom'}),
        contact('B02',84,155,.8,40,6,{kind:'bottom'}),
      ], lesson:'clutter', preset:{range:100,gain:30,noise:'OFF',bottom:0,tilt:-2},
    },
    {
      id:'movement', name:'03 · Đọc tín hiệu biến đổi', subtitle:'Phản hồi dịch chuyển · dấu đo thủ công',
      description:'Đặt nhiều dấu tại các thời điểm khác nhau và quan sát thay đổi cự ly, hướng.',
      seed:8012, noise:.34, duration:300,
      contacts:[
        contact('E01',35,285,.98,16,1,{radial:.045,angular:.045}),
        contact('E02',43,135,.85,12,2,{radial:-.025,angular:-.035}),
        contact('E03',23,33,.7,9,1,{radial:.02,angular:.02}),
      ], lesson:'movement', preset:{range:75,gain:22,tilt:-2},
    },
    {
      id:'depth', name:'04 · Thử góc nghiêng', subtitle:'Phản hồi tại các lớp sâu giả lập',
      description:'Thay đổi Tilt để thấy tác động đến độ sáng của phản hồi ở các lớp sâu khác nhau.',
      seed:7102, noise:.3, duration:360,
      contacts:[contact('E01',42,310,.96,17,3), contact('E02',53,35,.95,16,17),
        contact('E03',66,110,.94,20,37),contact('B01',82,175,.8,55,48,{kind:'bottom'})],
      lesson:'depth', preset:{range:100,gain:23,tilt:-2},
    },
    {
      id:'blank', name:'05 · Quan sát tự do', subtitle:'Không chấm điểm · tự thay đổi cấu hình',
      description:'Dùng bảng giảng viên để chỉnh số cụm phản hồi, nhiễu và hạt giống ngẫu nhiên.',
      seed:5432, noise:.35, duration:0,
      contacts:[contact('E01',23,300,.9,15),contact('E02',35,75,.85,18),contact('E03',18,165,.8,12)],
      lesson:null,
    },
  ];
  function getScenario(id) {
    return JSON.parse(JSON.stringify(SCENARIOS.find(s => s.id === id) || SCENARIOS[0]));
  }
  function contactAt(c, time) {
    return {...c, bearing:wrap(c.bearing + c.angular * time),
      range:Math.max(1, c.range + c.radial * time)};
  }
  function screenPoint(bearing, distance, state, radius, cx = 0, cy = 0) {
    const rotation = state.orientation === 'bow' ? state.heading : 0;
    const a = (bearing - rotation) * RAD;
    return {x:cx + Math.sin(a) * distance / state.range * radius,
      y:cy - Math.cos(a) * distance / state.range * radius};
  }
  function screenToPolar(x, y, state, radius) {
    const range = Math.hypot(x,y) / radius * state.range;
    const rotation = state.orientation === 'bow' ? state.heading : 0;
    return {range, bearing:wrap(Math.atan2(x, -y) / RAD + rotation)};
  }
  function signalStrength(c, s) {
    if (s.tx === 'OFF') return 0;
    const tx = {LOW:.85,MEDIUM:1,FULL:1.18}[s.tx];
    const depression = -s.tilt * RAD;
    const slant = Math.hypot(c.range, c.depth);
    const verticalAngle = Math.atan2(c.depth, c.range);
    const beam = {NARROW:6,AUTO:12,WIDE:22}[s.beam] * RAD;
    const tiltFactor = Math.exp(-Math.pow((verticalAngle-depression)/beam,2)/2);
    const attenuation = Math.exp(-slant / 240 * (s.frequency / 114));
    const tvg = Math.pow(Math.max(c.range,5)/30, (s.tvg-20)/55);
    const gain = .30 + s.gain / 18;
    const bottom = c.kind === 'bottom' ? Math.max(.02, 1-s.bottom*.19) : 1;
    const near = 1 - s.rcg / 7 * Math.exp(-c.range / 7);
    let value = c.strength * tx * gain * attenuation * tvg * tiltFactor * bottom * near;
    const agc = {OFF:0,LOW:.12,MEDIUM:.22,HIGH:.35}[s.agc];
    value /= 1 + Math.max(0,value-.7)*agc;
    return clamp(value,0,1.3);
  }
  function noiseLevel(s, scenario) {
    if (s.tx === 'OFF') return 0;
    const filter = {OFF:1,LOW:.70,MEDIUM:.44,HIGH:.19}[s.noise];
    return clamp(scenario.noise * filter * (.28+s.gain/25),0,1);
  }
  function findEcho(point, scenario, state, time) {
    let best = null;
    for (const initial of scenario.contacts) {
      const c = contactAt(initial,time);
      if (c.range > state.range || signalStrength(c,state) < .22) continue;
      if(state.sector<360&&Math.abs(angleDiff(c.bearing,wrap(state.heading+state.bearing)))>state.sector/2)continue;
      const angular = Math.abs(angleDiff(point.bearing,c.bearing));
      const distance = Math.abs(point.range-c.range);
      const score = Math.hypot(distance / Math.max(1.8,state.range*.04), angular / Math.max(6,c.width*.7));
      if (score <= 1 && (!best || score < best.score)) best = {contact:c,score};
    }
    return best ? best.contact : null;
  }
  function validateScenario(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Kịch bản phải là một đối tượng JSON.');
    if (!Array.isArray(raw.contacts) || raw.contacts.length > 60) throw new Error('contacts phải là mảng có tối đa 60 phản hồi.');
    const finite = (value, min, max, name) => {
      if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max)
        throw new Error(name + ': giá trị hợp lệ từ ' + min + ' đến ' + max + '.');
      return value;
    };
    const ids = new Set();
    const contacts = raw.contacts.map((c,i) => {
      if (!c || typeof c !== 'object') throw new Error('Phản hồi ' + (i+1) + ' không hợp lệ.');
      const id = String(c.id || 'E'+String(i+1).padStart(2,'0')).slice(0,24);
      if (ids.has(id)) throw new Error('Mã phản hồi không được trùng: ' + id);
      ids.add(id);
      return contact(id,finite(c.range,1,2000,'range'),finite(c.bearing,0,359.999,'bearing'),
        finite(c.strength,.05,1,'strength'),finite(c.width,2,80,'width'),
        finite(c.depth ?? 1,0,1000,'depth'),{
          radial:finite(c.radial ?? 0,-.5,.5,'radial'), angular:finite(c.angular ?? 0,-.5,.5,'angular'),
          kind:c.kind === 'bottom' ? 'bottom' : 'echo',
        });
    });
    return {id:'custom',name:String(raw.name || 'Kịch bản tùy chỉnh').slice(0,80),
      subtitle:'Kịch bản do giảng viên tạo', description:String(raw.description || '').slice(0,500),
      seed:Math.round(finite(raw.seed ?? 1,0,4294967295,'seed')),
      noise:finite(raw.noise ?? .3,0,1,'noise'),
      duration:Math.round(finite(raw.duration ?? 300,0,3600,'duration')),
      lesson:null, contacts};
  }
  function generateScenario(seed, count, noise) {
    const rng = random(seed);
    return validateScenario({name:'Bài tự tạo · '+seed,seed,noise,duration:300,
      contacts:Array.from({length:count},(_,i)=>contact('E'+String(i+1).padStart(2,'0'),
        7+rng()*38,rng()*360,.55+rng()*.45,7+rng()*17,rng()*3))});
  }
  const LESSONS = {
    basic:[
      {text:'Đổi Range sang 75 m, sau đó trở lại 50 m.',check:c=>c.visited.range?.has(75)&&c.s.range===50},
      {text:'Điều chỉnh Gain trong khoảng 17–25.',check:c=>c.actions.has('gain')&&c.s.gain>=17&&c.s.gain<=25},
      {text:'Đặt ít nhất 2 dấu trúng cụm phản hồi.',check:c=>c.hits>=2},
      {text:'Chuyển North Up rồi trở về Bow Up.',check:c=>c.actions.has('north')&&c.s.orientation==='bow'},
    ],
    clutter:[
      {text:'Đặt Noise Filter ở MEDIUM hoặc HIGH.',check:c=>['MEDIUM','HIGH'].includes(c.s.noise)},
      {text:'Điều chỉnh Gain về 18–25.',check:c=>c.s.gain>=18&&c.s.gain<=25},
      {text:'Tăng Bottom Filter ít nhất đến 2.',check:c=>c.s.bottom>=2},
      {text:'Đặt 2 dấu trúng cụm phản hồi hiển thị.',check:c=>c.hits>=2},
    ],
    movement:[
      {text:'Đặt một dấu trúng phản hồi.',check:c=>c.hits>=1},
      {text:'Đọc số đo khi dùng North Up.',check:c=>c.actions.has('north')},
      {text:'Đặt thêm dấu trúng phản hồi sau 20 giây mô phỏng.',check:c=>c.hitTimes.some(t=>t>=20)&&c.hits>=2},
      {text:'Tạm dừng, sau đó tiếp tục mô phỏng.',check:c=>c.actions.has('paused')&&c.actions.has('resumed')},
    ],
    depth:[
      {text:'Thử Tilt trong khoảng −15° đến −25°.',check:c=>c.visited.tilt&&[...c.visited.tilt].some(t=>t<=-15&&t>=-25)},
      {text:'Thử Tilt trong khoảng −30° đến −40°.',check:c=>c.visited.tilt&&[...c.visited.tilt].some(t=>t<=-30&&t>=-40)},
      {text:'Đặt ít nhất 2 dấu trúng cụm phản hồi.',check:c=>c.hits>=2},
      {text:'Trả Tilt về −2°.',check:c=>c.actions.has('tilt')&&c.s.tilt===-2},
    ],
  };
  class Training {
    constructor(scenario, trainee = '') {
      this.scenario = scenario.id; this.trainee=trainee; this.startedAt = new Date().toISOString();
      this.events=[];this.actions=new Set();this.visited={};this.hits=0;this.attempts=0;this.hitTimes=[];
      this.steps=(LESSONS[scenario.lesson]||[]).map(l=>({...l,done:false}));
      this.elapsed=0;this.endedAt=null;this.completedAt=null;
    }
    record(action,value,time) {
      if (this.endedAt) return;
      this.actions.add(action);
      (this.visited[action] ||= new Set()).add(value);
      this.events.push({at:Math.round(time*10)/10,action,value});
      if(this.events.length>2000)this.events.shift();
    }
    mark(hit,time) {if(this.endedAt)return; this.attempts++;if(hit){this.hits++;this.hitTimes.push(time);}this.record('mark',Boolean(hit),time);}
    update(s,time) {
      if(this.endedAt)return;
      this.elapsed=time;
      const c={s,actions:this.actions,visited:this.visited,hits:this.hits,hitTimes:this.hitTimes};
      for(const step of this.steps)if(!step.done&&step.check(c))step.done=true;
      if(this.steps.length&&this.steps.every(st=>st.done)&&!this.completedAt)this.completedAt=time;
    }
    finish(s,marks,time) {
      if(this.endedAt)return;
      this.update(s,time);this.record('finish',true,time);this.endedAt=new Date().toISOString();
      this.finalSnapshot={settings:{...s},marks:marks.map(m=>({...m}))};
    }
    report(s,marks,scenario) {
      const done=this.steps.filter(st=>st.done).length;
      return {format:'omni-sonar-session',version:VERSION,trainingOnly:true,
        trainee:this.trainee,startedAt:this.startedAt,endedAt:this.endedAt,
        exportedAt:new Date().toISOString(),scenario:scenario.name,scenarioId:scenario.id,
        elapsedSeconds:Math.round(this.elapsed),completedAt:this.completedAt,
        progress:this.steps.length?{completed:done,total:this.steps.length,score:Math.round(done/this.steps.length*100)}:null,
        marksAttempted:this.attempts,marksOnEcho:this.hits,
        accuracy:this.attempts?Math.round(this.hits/this.attempts*100):null,
        tasks:this.steps.map(st=>({text:st.text,done:st.done})),
        settings:{...(this.finalSnapshot?.settings||s)},
        marks:(this.finalSnapshot?.marks||marks).map(m=>({...m})),events:this.events.slice()};
    }
  }
  // Bounded triangular scans for interface practice; these are not OEM search algorithms.
  function scanValue(center,span,seconds,period,min,max) {
    const phase=((seconds/period)%1+1)%1;
    const triangle=phase<.25?phase*4:phase<.75?2-phase*4:phase*4-4;
    return clamp(Math.round(center+span/2*triangle),min,max);
  }
  return {VERSION,RAD,clamp,wrap,angleDiff,random,PARAMS,DEFAULTS,SCENARIOS,normalize,adjust,scanValue,
    getScenario,contactAt,screenPoint,screenToPolar,signalStrength,noiseLevel,findEcho,
    validateScenario,generateScenario,Training};
});
