(function(root){
  'use strict';
  const C=root.SonarCore,TAU=Math.PI*2,SIZE=640,ANGLES=1440,RANGES=320;
  const palettes={
    classic:{background:'#00009b',grid:'#eee9ac',ship:'#fff4c8',cursor:'#ffd329',stops:[
      [0,[0,0,155]],[.07,[0,0,171]],[.18,[0,26,212]],[.30,[0,153,254]],
      [.41,[0,237,238]],[.51,[9,248,22]],[.63,[229,254,0]],[.75,[255,209,0]],
      [.86,[255,66,0]],[1,[252,0,0]]]},
    night:{background:'#03121b',grid:'#a2b3a4',ship:'#e6e8d0',cursor:'#f4d679',stops:[
      [0,[3,18,27]],[.14,[4,30,44]],[.35,[0,147,169]],[.53,[31,222,145]],
      [.72,[242,221,50]],[1,[255,55,18]]]},
    green:{background:'#021812',grid:'#9abb9d',ship:'#e1f3d8',cursor:'#ffffae',stops:[
      [0,[2,24,18]],[.12,[3,37,22]],[.4,[7,106,39]],[.7,[45,214,82]],[1,[217,255,190]]]},
  };
  class Renderer{
    constructor(canvas){
      this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:false});
      this.heat=document.createElement('canvas');this.heat.width=SIZE;this.heat.height=SIZE;
      this.hctx=this.heat.getContext('2d');this.image=this.hctx.createImageData(SIZE,SIZE);
      this.polar=new Float32Array(ANGLES*RANGES);this.ri=new Int16Array(SIZE*SIZE);this.ai=new Int16Array(SIZE*SIZE);
      this.texture=new Float32Array(SIZE*SIZE);this.lastHeat=-Infinity;this.lastState='';this.dirty=true;
      this.width=0;this.height=0;this.radius=0;this.cx=0;this.cy=0;this.dpr=1;this.luts={};this.patterns={};
      const rng=C.random(90618),half=SIZE/2;
      for(let y=0;y<SIZE;y++)for(let x=0;x<SIZE;x++){
        const i=y*SIZE+x,dx=(x+.5-half)/half,dy=(y+.5-half)/half,r=Math.hypot(dx,dy);
        this.ri[i]=r<=1?Math.min(RANGES-1,Math.floor(r*RANGES)):-1;
        this.ai[i]=Math.floor(C.wrap(Math.atan2(dx,-dy)/C.RAD)/360*ANGLES)%ANGLES;
        this.texture[i]=rng()*.028+.007*Math.sin(r*300+Math.atan2(dy,dx)*6);
      }
      this.observer=new ResizeObserver(()=>{this.dirty=true;});this.observer.observe(canvas);
    }
    resize(s){
      const rect=this.canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,s.quality==='high'?2:1.5);
      const w=Math.round(rect.width*dpr),h=Math.round(rect.height*dpr);
      if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;this.dirty=true;}
      this.dpr=dpr;this.width=rect.width;this.height=rect.height;this.cx=this.width*.51;this.cy=this.height*.51;
      this.radius=Math.max(25,Math.min(this.cx-4,this.width-this.cx-4,this.cy-4,this.height-this.cy-4));
      if(s.offCentre){this.cx=this.width*s.offX;this.cy=this.height*s.offY;}
      if(s.zoom){const anchor=C.screenPoint(s.zoomBearing,s.zoomRange,s,this.radius,0,0);this.cx-=anchor.x;this.cy-=anchor.y;this.radius*=2;}
      this.canvas.dataset.cx=this.cx;this.canvas.dataset.cy=this.cy;this.canvas.dataset.radius=this.radius;
    }
    lut(name){
      if(this.luts[name])return this.luts[name];const stops=(palettes[name]||palettes.classic).stops,out=new Uint8Array(768);
      for(let i=0;i<256;i++){const n=i/255;let a=stops[0],b=stops[1];
        for(let j=1;j<stops.length;j++){a=stops[j-1];b=stops[j];if(n<=b[0])break;}
        const t=C.clamp((n-a[0])/(b[0]-a[0]),0,1);for(let k=0;k<3;k++)out[i*3+k]=a[1][k]*(1-t)+b[1][k]*t;
      }return this.luts[name]=out;
    }
    pattern(name){
      if(this.patterns[name])return this.patterns[name];
      const c=document.createElement('canvas');c.width=192;c.height=192;const ctx=c.getContext('2d'),im=ctx.createImageData(192,192),rng=C.random(77),base=(palettes[name]||palettes.classic).stops[0][1];
      for(let i=0;i<192*192;i++){const n=rng()*7-2;for(let k=0;k<3;k++)im.data[i*4+k]=Math.max(0,base[k]+n);im.data[i*4+3]=255;}
      ctx.putImageData(im,0,0);return this.patterns[name]=this.ctx.createPattern(c,'repeat');
    }
    relativeContact(initial,time,offset={x:0,y:0}){
      const c=C.contactAt(initial,time),x=Math.sin(c.bearing*C.RAD)*c.range-offset.x,y=Math.cos(c.bearing*C.RAD)*c.range-offset.y;
      return{...c,range:Math.hypot(x,y),bearing:C.wrap(Math.atan2(x,y)/C.RAD)};
    }
    point(bearing,range,s){return C.screenPoint(bearing,range,s,this.radius,this.cx,this.cy);}
    polarFromEvent(event,s){const r=this.canvas.getBoundingClientRect();return C.screenToPolar(event.clientX-r.x-this.cx,event.clientY-r.y-this.cy,s,this.radius);}
    makeHeat(s,scenario,time,offset){
      const p=this.polar;p.fill(0);const rotation=s.orientation==='bow'?s.heading:0,frame=Math.floor(time*3),rng=C.random(scenario.seed+frame*2333),noise=C.noiseLevel(s,scenario);
      for(let i=0;i<Math.round(100000*noise);i++){
        const a=Math.floor(rng()*ANGLES),r=Math.floor(Math.sqrt(rng())*RANGES),near=1-s.rcg/6*Math.exp(-r/40);
        p[a*RANGES+r]+=rng()*noise*.5*near;
      }
      const persistence={OFF:0,LOW:.25,MEDIUM:.45,HIGH:.7}[s.pp];
      for(let index=0;index<scenario.contacts.length;index++){
        const c=this.relativeContact(scenario.contacts[index],time,offset);if(c.range>s.range*1.08)continue;
        const strength=C.signalStrength(c,s)*1.34;if(strength<.018)continue;
        const a=C.wrap(c.bearing-rotation)/360*ANGLES,r=c.range/s.range*RANGES;
        const aw=Math.max(4,c.width*ANGLES/360*({NARROW:.75,AUTO:1,WIDE:1.45}[s.beam]));
        const rw=Math.max(.9,(.32+c.range*.005)/s.range*RANGES)*({SHORT:.72,'FM AUTO':1,LONG:1.65}[s.pulse]);
        for(let j=Math.floor(a-aw*1.35);j<=Math.ceil(a+aw*1.35);j++){
          const ang=(j-a)/aw,ragged=.91+.055*Math.sin(j*.23+index*2.2)+.035*Math.sin(j*1.9+time*.35);
          const center=r+Math.sin(j*.10+index)*.43,amp=Math.exp(-ang*ang*3.7)*strength*ragged,wrapped=((j%ANGLES)+ANGLES)%ANGLES;
          for(let k=Math.max(0,Math.floor(center-rw*6));k<=Math.min(RANGES-1,Math.ceil(center+rw*6));k++){
            const dr=(k-center)/rw,primary=Math.exp(-dr*dr*1.7);
            const lobes=.24*Math.exp(-Math.pow(dr-3.4,2)*1.9)+.13*Math.exp(-Math.pow(dr+3.0,2)*2.4);
            const trail=s.trails?persistence*.30*Math.exp(-Math.pow(dr-5.2,2)/3.1):0;
            p[wrapped*RANGES+k]=Math.min(1.2,p[wrapped*RANGES+k]+amp*(primary+lobes+trail));
          }
        }
      }
      const data=this.image.data,lut=this.lut(s.palette),sectorCenter=C.wrap(s.heading+s.bearing);
      for(let i=0;i<this.ri.length;i++){
        const ri=this.ri[i],o=i*4;if(ri<0){data[o+3]=0;continue;}
        const ai=this.ai[i],outside=s.sector<360&&Math.abs(C.angleDiff(ai/ANGLES*360+rotation,sectorCenter))>s.sector/2;
        const value=s.tx==='OFF'?0:C.clamp((p[ai*RANGES+ri]+this.texture[i])*(outside?.065:1),0,1);
        const color=Math.floor(value*255)*3;data[o]=lut[color];data[o+1]=lut[color+1];data[o+2]=lut[color+2];data[o+3]=255;
      }
      this.hctx.putImageData(this.image,0,0);this.lastHeat=time;
    }
    draw(s,scenario,time,cursor,marks,options={}){
      this.resize(s);const key=Object.keys(C.PARAMS).map(k=>s[k]).join('|')+'|'+[s.palette,s.orientation,s.heading,s.trails,s.sector].join('|');
      const live=root.NanoLink?.liveMode;
      const ctx=this.ctx,palette=palettes[s.palette]||palettes.classic;
      ctx.setTransform(this.dpr,0,0,this.dpr,0,0);ctx.fillStyle=this.pattern(s.palette);ctx.fillRect(0,0,this.width,this.height);
      if(!live){
        if(this.dirty||key!==this.lastState||time<this.lastHeat||time-this.lastHeat>=.18){this.makeHeat(s,scenario,time,options.boatOffset);this.lastState=key;this.dirty=false;}
        ctx.imageSmoothingEnabled=true;ctx.drawImage(this.heat,this.cx-this.radius,this.cy-this.radius,this.radius*2,this.radius*2);
        if(s.sweep&&s.tx!=='OFF')this.drawSweep(ctx,s,time);
      }
      this.drawGrid(ctx,s,palette);if(s.ship)this.drawShip(ctx,s,palette);if(live)root.NanoLink.draw(this,s);
      this.drawCursor(ctx,live?{...s,bearing:root.NanoLink.bearing()}:s,cursor,palette);
      this.drawMarks(ctx,s,marks,palette,options.selectedMark);if(options.truth&&!live)this.drawTruth(ctx,s,scenario,time,options.boatOffset);
      this.drawSymbols(ctx,s,options.symbols||[],options.boatOffset);
      this.drawHUD(ctx,s,cursor,options.boatOffset);this.drawVertical(s,scenario,time,options.boatOffset);
      if(s.tx==='OFF'||!s.power){ctx.fillStyle=palette.ship;ctx.font='bold '+Math.max(12,this.radius*.035)+'px Arial';ctx.textAlign='center';ctx.fillText(!s.power?'POWER OFF · F3 để bật':'TX OFF · STANDBY',this.width/2,this.height-56);}
    }
    drawGrid(ctx,s,palette){
      const r=this.radius,cx=this.cx,cy=this.cy;ctx.save();ctx.strokeStyle=palette.grid;ctx.fillStyle=palette.grid;
      if(s.rings){ctx.lineWidth=1.1;ctx.globalAlpha=.66;ctx.setLineDash([1,Math.max(7,r*.018)]);
        for(let i=1;i<5;i++){ctx.beginPath();ctx.arc(cx,cy,r*i/5,0,TAU);ctx.stroke();}ctx.setLineDash([]);
        ctx.globalAlpha=1;ctx.font='bold '+Math.max(10,r*.026)+'px Arial';ctx.textAlign='center';ctx.fillStyle='#fffcdb';
        for(let i=1;i<5;i++)ctx.fillText(String(Number((s.range*(root.NanoLink?.liveMode ? 50 : 100)*i/5).toFixed(2))),cx-r*i/5,cy-5);
      }
      ctx.globalAlpha=1;ctx.strokeStyle=palette.grid;ctx.lineWidth=2.0;ctx.beginPath();ctx.arc(cx,cy,r,0,TAU);ctx.stroke();
      for(let a=0;a<360;a+=5){const angle=a*C.RAD,len=a%30===0?r*.038:a%10===0?r*.024:r*.015;
        ctx.lineWidth=a%30===0?2:1.25;ctx.beginPath();ctx.moveTo(cx+Math.sin(angle)*r,cy-Math.cos(angle)*r);ctx.lineTo(cx+Math.sin(angle)*(r-len),cy-Math.cos(angle)*(r-len));ctx.stroke();}
      const rotation=s.orientation==='bow'?s.heading:0;
      for(const[bearing,label]of [[0,'N'],[90,'E'],[180,'S'],[270,'W']]){
        const a=(bearing-rotation)*C.RAD;ctx.fillStyle=palette.grid;ctx.font='bold '+Math.max(13,r*.033)+'px Arial';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillText(label,cx+Math.sin(a)*(r-r*.055),cy-Math.cos(a)*(r-r*.055));
        ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(cx+Math.sin(a)*r,cy-Math.cos(a)*r);
        ctx.lineTo(cx+Math.sin(a-.017)*(r-r*.028),cy-Math.cos(a-.017)*(r-r*.028));ctx.lineTo(cx+Math.sin(a+.017)*(r-r*.028),cy-Math.cos(a+.017)*(r-r*.028));ctx.closePath();ctx.stroke();
      }
      const bow=(s.heading-rotation)*C.RAD;ctx.save();ctx.translate(cx,cy);ctx.rotate(bow);ctx.strokeStyle=palette.ship;ctx.lineWidth=1.6;
      ctx.beginPath();ctx.moveTo(-r*.012,-r+r*.062);ctx.lineTo(0,-r+r*.095);ctx.lineTo(r*.012,-r+r*.062);ctx.stroke();ctx.restore();
      if(s.sector<360){ctx.globalAlpha=.7;ctx.lineWidth=1;ctx.setLineDash([6,5]);for(const b of [s.heading+s.bearing-s.sector/2,s.heading+s.bearing+s.sector/2]){const p=this.point(b,s.range,s);ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(p.x,p.y);ctx.stroke();}}
      ctx.restore();
    }
    drawShip(ctx,s,palette){
      const r=this.radius;ctx.save();ctx.translate(this.cx,this.cy);ctx.rotate((s.orientation==='bow'?0:s.heading)*C.RAD);
      ctx.strokeStyle=palette.ship;ctx.lineWidth=Math.max(1.3,r*.0027);ctx.beginPath();ctx.moveTo(0,-r*.37);ctx.lineTo(r*.086,-r*.075);
      ctx.lineTo(r*.084,r*.615);ctx.lineTo(r*.076,r*.66);ctx.lineTo(-r*.076,r*.66);ctx.lineTo(-r*.084,r*.615);ctx.lineTo(-r*.086,-r*.075);ctx.closePath();ctx.stroke();
      ctx.beginPath();ctx.arc(0,r*.655,r*.004,0,TAU);ctx.stroke();ctx.restore();
    }
    drawCursor(ctx,s,cursor,palette){
      ctx.save();ctx.strokeStyle=palette.ship;ctx.lineWidth=Math.max(3.5,this.radius*.007);ctx.lineCap='round';const edge=this.point(C.wrap(s.heading+s.bearing),s.range,s);
      if(!root.NanoLink?.liveMode||(root.NanoLink.connected&&root.NanoLink.status.orientation_ready!==false)){ctx.beginPath();ctx.moveTo(this.cx,this.cy);ctx.lineTo(edge.x,edge.y);ctx.stroke();}
      if(s.cursorVisible){const p=this.point(cursor.bearing,Math.min(cursor.range,s.range),s),half=Math.max(7,this.radius*.019);
        ctx.strokeStyle=palette.cursor;ctx.lineWidth=Math.max(1.8,this.radius*.0038);ctx.beginPath();ctx.moveTo(p.x-half,p.y);ctx.lineTo(p.x+half,p.y);ctx.moveTo(p.x,p.y-half);ctx.lineTo(p.x,p.y+half);ctx.stroke();}
      ctx.restore();
    }
    drawMarks(ctx,s,marks,palette,selected){
      ctx.save();ctx.font=Math.max(10,this.radius*.024)+'px Arial';ctx.textAlign='left';ctx.textBaseline='middle';
      for(const m of marks){if(m.range>s.range)continue;const p=this.point(m.bearing,m.range,s);ctx.strokeStyle=m.label===selected?'#fff':'#ffef9a';ctx.lineWidth=m.label===selected?2:1;ctx.setLineDash([3,2]);ctx.beginPath();ctx.arc(p.x,p.y,Math.max(7,this.radius*.018),0,TAU);ctx.stroke();ctx.setLineDash([]);
        if(s.labels){ctx.fillStyle=palette.cursor;ctx.fillText(m.label,p.x+12,p.y-10);}}
      ctx.restore();
    }
    drawSymbols(ctx,s,symbols,offset={x:0,y:0}){
      ctx.save();ctx.strokeStyle='#ffdc7b';ctx.fillStyle='#ffdc7b';ctx.lineWidth=1.5;ctx.font='11px Arial';ctx.textAlign='left';
      for(const m of symbols){const x=Math.sin(m.bearing*C.RAD)*m.range+m.origin.x-offset.x,y=Math.cos(m.bearing*C.RAD)*m.range+m.origin.y-offset.y;
        const range=Math.hypot(x,y);if(range>s.range)continue;const p=this.point(C.wrap(Math.atan2(x,y)/C.RAD),range,s);ctx.beginPath();
        if(m.kind==='own')ctx.rect(p.x-6,p.y-6,12,12);else if(m.kind==='gear'){ctx.ellipse(p.x,p.y,18,10,0,0,TAU);ctx.moveTo(p.x,p.y-14);ctx.lineTo(p.x,p.y+14);}else ctx.arc(p.x,p.y,14,0,TAU);ctx.stroke();if(s.labels)ctx.fillText(m.label,p.x+20,p.y-8);
      }ctx.restore();
    }
    drawVertical(s,scenario,time,offset){
      const canvas=document.getElementById('verticalSonar');if(!canvas||s.presentation!=='split')return;
      const rect=canvas.getBoundingClientRect(),w=Math.round(rect.width*this.dpr),h=Math.round(rect.height*this.dpr);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
      const ctx=canvas.getContext('2d'),width=rect.width,height=rect.height,palette=palettes[s.palette]||palettes.classic;ctx.setTransform(this.dpr,0,0,this.dpr,0,0);ctx.fillStyle=palette.background;ctx.fillRect(0,0,width,height);
      const left=43,top=32,right=width-15,bottom=height-23,sx=(right-left)/s.rangeV,sy=(bottom-top)/s.rangeV;
      ctx.font='11px Arial';ctx.textAlign='left';ctx.fillStyle=palette.grid;ctx.fillText((root.NanoLink?.liveMode?'NANO · Không có đo độ sâu · B ':'VERTICAL DEMO · B ')+Math.round(s.bearing)+'° · R '+Math.round(s.rangeV*100)+' cm / G '+s.gainV+' · slice ±15°',8,18);
      ctx.strokeStyle=palette.grid;ctx.globalAlpha=.4;ctx.lineWidth=1;
      for(let i=0;i<=4;i++){const x=left+(right-left)*i/4,y=top+(bottom-top)*i/4;ctx.beginPath();ctx.moveTo(x,top);ctx.lineTo(x,bottom);ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();ctx.fillText(String(Number((s.rangeV*100*i/4).toFixed(1))),x-7,bottom+15);ctx.fillText(String(Number((s.rangeV*100*i/4).toFixed(1))),5,y+4);}ctx.globalAlpha=1;
      if(!root.NanoLink?.liveMode&&s.power&&s.tx!=='OFF'&&s.hull==='DOWN')for(const raw of scenario.contacts){const c=this.relativeContact(raw,time,offset);if(Math.abs(C.angleDiff(c.bearing,s.heading+s.bearing))>15||c.range>s.rangeV||c.depth>s.rangeV)continue;
        const strength=C.signalStrength(c,{...s,range:s.rangeV,gain:s.gainV,tilt:-Math.atan2(c.depth,c.range)/C.RAD});if(strength<.03)continue;
        ctx.fillStyle=strength>.6?'#ff4f09':strength>.3?'#ffe600':'#00ee73';ctx.globalAlpha=C.clamp(strength,.2,1);ctx.beginPath();ctx.ellipse(left+c.range*sx,top+c.depth*sy,Math.max(3,c.width*.4),3,0,0,TAU);ctx.fill();}ctx.globalAlpha=1;
      ctx.strokeStyle=palette.ship;ctx.beginPath();ctx.moveTo(left,top);ctx.lineTo(Math.min(right,left+s.rangeV*Math.cos(-s.tilt*C.RAD)*sx),Math.min(bottom,top+s.rangeV*Math.sin(-s.tilt*C.RAD)*sy));ctx.stroke();
    }
    drawTruth(ctx,s,scenario,time,offset){ctx.save();ctx.strokeStyle='#ffd1ff';ctx.fillStyle='#ffd1ff';ctx.font='11px Arial';ctx.textAlign='left';for(const raw of scenario.contacts){const c=this.relativeContact(raw,time,offset);if(c.range>s.range)continue;const p=this.point(c.bearing,c.range,s);ctx.strokeRect(p.x-12,p.y-7,24,14);ctx.fillText(c.id,p.x+15,p.y+3);}ctx.restore();}
    drawSweep(ctx,s,time){const a=time/s.sweepSeconds*TAU-(s.orientation==='bow'?s.heading*C.RAD:0);ctx.save();ctx.strokeStyle='#a1e3fa';ctx.globalAlpha=.9;ctx.lineWidth=Math.max(3.5,this.radius*.007);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(this.cx,this.cy);ctx.lineTo(this.cx+Math.sin(a)*this.radius,this.cy-Math.cos(a)*this.radius);ctx.stroke();ctx.restore();}
    drawHUD(ctx,s,cursor,offset={x:0,y:0}){
      const u=C.clamp(this.radius/500,.45,1.6),pad=n=>String(Math.round(n)).padStart(2,'0');ctx.save();ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.fillStyle='#fffbd0';ctx.strokeStyle='#fffbd0';ctx.lineWidth=2*u;
      ctx.font='bold '+27*u+'px Arial';ctx.fillText((root.NanoLink?.liveMode?'Rxy:  ':'R:  ')+Number((s.range*(root.NanoLink?.liveMode?50:100)).toFixed(1))+' cm/G:'+s.gain,15*u,32*u);
      ctx.beginPath();ctx.moveTo(15*u,49*u);ctx.lineTo(153*u,51*u);ctx.stroke();
      for(let a=12;a<=90;a+=8){const angle=a*C.RAD,rr=124*u,len=(a-12)%16===0?8*u:4*u;
        ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(19*u+Math.cos(angle)*rr,53*u+Math.sin(angle)*rr);ctx.lineTo(19*u+Math.cos(angle)*(rr-len),53*u+Math.sin(angle)*(rr-len));ctx.stroke();}
      ctx.font='bold '+25*u+'px Arial';const tilt=root.NanoLink?.liveMode?(root.NanoLink.status.servo2_deg||0):s.tilt;ctx.fillText((tilt<0?'-':'')+pad(Math.abs(tilt))+'°',151*u,100*u);
      ctx.beginPath();ctx.moveTo(25*u,52*u);ctx.lineTo(138*u,55*u);ctx.lineTo(127*u,51*u);ctx.stroke();
      const geo=(value,lat)=>{const v=Math.abs(value),d=Math.floor(v),mins=(v-d)*60;return(value<0?(lat?'S':'W'):(lat?'N':'E'))+' '+String(d).padStart(lat?2:3,'0')+'° '+mins.toFixed(3);};
      const lat=s.latitude+offset.y/111320,lon=s.longitude+offset.x/(111320*Math.cos(s.latitude*C.RAD));
      const x=this.width-238*u,rx=this.width-87*u;ctx.font='bold '+18*u+'px Arial';ctx.fillStyle='#ffb27d';
      ctx.fillText(geo(lat,true),x,29*u);ctx.fillText('B:',rx,29*u);ctx.textAlign='right';ctx.fillText(String(Math.round(C.wrap(cursor.bearing-s.heading))).padStart(3,'0')+'°',this.width-7*u,29*u);
      ctx.textAlign='left';ctx.fillText(geo(lon,false),x,53*u);ctx.fillText('↘:',rx,53*u);ctx.textAlign='right';ctx.fillText((cursor.range*(root.NanoLink?.liveMode?50:100)).toFixed(1)+' cm',this.width-7*u,53*u);
      ctx.textAlign='left';ctx.fillText('↓:',rx,77*u);ctx.textAlign='right';ctx.fillText(root.NanoLink?.liveMode||s.tilt===-90?'—':(cursor.range*100*Math.tan(-s.tilt*C.RAD)).toFixed(1)+' cm',this.width-7*u,77*u);
      ctx.restore();
    }
    snapshot(s,time){
      const vertical=document.getElementById('verticalSonar'),vh=s.presentation==='split'&&vertical?vertical.height:0;const out=document.createElement('canvas');out.width=this.canvas.width;out.height=this.canvas.height+vh+34;const ctx=out.getContext('2d');ctx.drawImage(this.canvas,0,0);if(vh)ctx.drawImage(vertical,0,this.canvas.height,out.width,vh);ctx.fillStyle='#c6c7cb';ctx.fillRect(0,this.canvas.height+vh,out.width,34);ctx.fillStyle='#4b4e57';ctx.font='12px Arial';ctx.fillText((root.NanoLink?.liveMode?'NANO LIVE · Rxy '+Number((s.range*50).toFixed(1))+' cm · D9 '+(root.NanoLink.status.servo2_deg||0)+'°':'SIMULATION · SH90 photo reference · R '+Math.round(s.range*100)+' cm · Tilt '+s.tilt+'°')+' · '+time.toFixed(1)+' s · '+new Date().toISOString(),8,out.height-12);return out;
    }
  }
  root.SonarRenderer=Renderer;
})(window);
