(function(root){
'use strict';
const RAD=Math.PI/180;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function tiltPulse(deg){deg=clamp(deg,-30,30);return Math.round(900+deg*(deg<0?400:300)/30);}
function pulseTilt(us){return clamp((us-900)*30/(us<900?400:300),-30,30);}
function azimuth(us){return (us-1400)*.18;}
function project(distanceM,p10,tiltDeg){const a=azimuth(p10)*RAD,t=clamp(tiltDeg,-30,30)*RAD,rho=distanceM*Math.sin(t);return {x:-rho*Math.sin(a),y:rho*Math.cos(a),rho,radial:Math.abs(rho),diameter:2*Math.abs(rho),azimuthDeg:azimuth(p10),tiltDeg};}
function bearing(p10,tiltDeg){return (((-azimuth(p10)+(tiltDeg<0?180:0))%360)+360)%360;}
const api={tiltPulse,pulseTilt,azimuth,project,bearing,maxProjection:range=>range*.5};
if(typeof module!=='undefined')module.exports=api;else root.SonarCalibration=api;
})(typeof window!=='undefined'?window:globalThis);
