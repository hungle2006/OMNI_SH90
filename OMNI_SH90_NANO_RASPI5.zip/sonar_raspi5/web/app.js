(function(){
  'use strict';
  const C=window.SonarCore,$=id=>document.getElementById(id),STORE='sh90-classic-v3';
  const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pad=(n,size=3)=>String(Math.round(n)).padStart(size,'0');
  const clock=t=>String(Math.floor(t/60)).padStart(2,'0')+':'+String(Math.floor(t%60)).padStart(2,'0');
  const switches={values:[true,false],names:['ON','OFF']};
  const EXTRA={
    power:{label:'Power',...switches},hull:{label:'Hull Unit',values:['UP','LOWERING','DOWN','HOISTING']},
    presentation:{label:'View',values:['horizontal','split'],names:['HORIZONTAL','H + VERTICAL']},
    rangeV:{label:'Range V',values:C.PARAMS.range.values,unit:'cm'},gainV:{label:'Gain V',min:0,max:40,step:1},
    autoTilt:{label:'Auto Tilt',...switches},autoTrain:{label:'Auto Train',...switches},
    tiltCenter:{label:'Tilt Centre',min:-90,max:0,step:1},tiltSpan:{label:'Tilt Span',min:2,max:40,step:2},
    trainCenter:{label:'Train Centre',min:0,max:359,step:1,wrap:true},trainSpan:{label:'Train Span',min:10,max:360,step:10},
    zoom:{label:'Zoom',...switches},zoomBearing:{label:'Zoom Anchor',min:0,max:359.9,step:.1,wrap:true},zoomRange:{label:'Zoom Range',min:0,max:1000,step:.1},
    offCentre:{label:'Off Centre',...switches},offX:{label:'Off Centre X',min:.15,max:.85,step:.01},offY:{label:'Off Centre Y',min:.15,max:.85,step:.01},menuHidden:{label:'Menu',...switches},
    orientation:{label:'Mode',values:['bow','north'],names:['Bow Up','North Up'],help:'Bow Up đặt mũi tàu ở trên. North Up đặt Bắc ở trên; hướng thực của phản hồi và dấu đo không đổi.'},
    palette:{label:'Colours',values:['classic','night','green'],names:['CLASSIC BLUE','NIGHT','GREEN']},
    aspect:{label:'Screen',values:['original','wide'],names:['ORIGINAL 5:4','WIDESCREEN'],help:'ORIGINAL giữ tỷ lệ bố cục theo ảnh. WIDESCREEN mở rộng ra toàn bộ cửa sổ laptop.'},
    rings:{label:'Range Rings',...switches},ship:{label:'Ship Symbol',...switches},
    cursorVisible:{label:'Cursor',...switches},labels:{label:'Mark Labels',...switches},
    trails:{label:'Echo Trails',...switches},sweep:{label:'Sweep Line',...switches},sound:{label:'Sound',...switches},
    heading:{label:'Heading',min:0,max:359,step:1,wrap:true,unit:'°T',help:'Hướng mũi tàu thực theo Bắc. Mặc định 250° để bố trí la bàn gần ảnh tham chiếu.'},
    speed:{label:'Speed',min:0,max:15,step:.5,unit:'kn',help:'Tốc độ tàu quan sát giả lập; thay đổi vị trí tương đối của các phản hồi.'},
    simSpeed:{label:'Time Scale',values:[.5,1,2,4],unit:'×'},
    sector:{label:'Sector',values:[360,180,120,90,60,30],unit:'°',help:'360° hiển thị toàn hướng. Cung hẹp được đặt quanh đường Bearing trắng; là tùy chọn luyện giao diện.'},
    quality:{label:'Resolution',values:['balanced','high'],names:['NORMAL','HIGH']},
  };
  const HELP={
    range:'Range 7–18 cm, mỗi mức 1 cm; là khoảng cách nghiêng tối đa d. Q/E giảm/tăng một mức. Cuộn chuột trên nút để chỉnh nhanh.',
    tilt:'Tilt là góc nghiêng giả lập: 0° ngang, số âm hướng xuống. S/W chỉnh sâu/nông. Độ sáng thay đổi theo độ sâu của phản hồi.',
    bearing:'Bearing điều khiển đường trắng, tính tương đối với mũi tàu. Khi CONNECT, đường kim lấy từ D10; nút −10°/+10° chỉnh góc D9. Con trỏ đo màu vàng độc lập, điều khiển bằng chuột hoặc phím mũi tên.',
    gain:'Gain khuếch đại cả phản hồi và nhiễu. J/K giảm/tăng; phạm vi 0–40.',
    pulse:'Pulse Form thay đổi bề dày và vệt phụ phản hồi. FM AUTO, SHORT và LONG là các lựa chọn mô phỏng.',
    tx:'TX Power: OFF tắt các tín hiệu phản hồi; LOW, MEDIUM, FULL tăng cường độ. P chuyển phát/chờ và nhớ mức phát trước.',
    beam:'Beam thay đổi bề rộng vệt theo góc và độ nhạy với Tilt.',
    frequency:'Frequency thay đổi hệ số suy hao minh họa. Mặc định *114000 Hz theo nhãn trong ảnh; không điều khiển đầu dò thật.',
    tvg:'TVG bù độ sáng theo cự ly, giúp so sánh phản hồi gần và xa trong dữ liệu giả lập.',
    agc:'AGC nén các phản hồi mạnh; OFF giữ nguyên, HIGH nén nhiều hơn.',
    rcg:'RCG giảm tín hiệu và nhiễu gần tâm; mức 0–5.',
    noise:'Noise Filter giảm nhiễu nền; OFF, LOW, MEDIUM hoặc HIGH.',
    bottom:'Bottom Filter giảm các phản hồi được gắn loại bottom trong kịch bản.',
    pp:'PP Filter điều chỉnh vệt phụ lưu phía sau để minh họa độ lưu ảnh.',
  };
  let state={...C.DEFAULTS},scenario=C.getScenario('reference'),time=0,paused=false,truth=false;
  let cursor={bearing:C.wrap(state.heading+268),range:C.DEFAULTS.range*.5},marks=[],nextMark=1,selectedMark=null;
  let training=new C.Training(scenario),currentTab='sonar',field='tx',lastTx='LOW',boatOffset={x:0,y:0};
  let symbols=[],nextSymbol=1,hullRemaining=0,autoStartTilt=0,autoStartTrain=0,images=[],recording=false,lastCapture=0,recalledId=null,profiles=[];
  let toastTimer,saveTimer,audioContext,editingId=null,testAlarms=[],acknowledged=new Set(),runtimeError='';
  const renderer=new window.SonarRenderer($('sonar'));
  const definition=k=>C.PARAMS[k]||EXTRA[k];
  const dialogOpen=()=>document.querySelector('dialog[open]');
  const blockingDialog=()=>Boolean(document.querySelector('dialog[open]:not(#controlsDialog)'));
  const running=()=>!paused&&state.power&&!training.endedAt&&!blockingDialog()&&!document.hidden;
  function toast(message){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,3500);}
  function status(message,notify=false){$('statusMessage').textContent=(window.NanoLink?.liveMode?'NANO · ':'SIMULATION · ')+message;if(notify)toast(message);}
  function beep(){if(!state.sound)return;try{audioContext ||= new(window.AudioContext||window.webkitAudioContext)();audioContext.resume();const o=audioContext.createOscillator(),g=audioContext.createGain();o.frequency.value=850;g.gain.setValueAtTime(.025,audioContext.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+.05);o.connect(g);g.connect(audioContext.destination);o.start();o.stop(audioContext.currentTime+.06);}catch(_){}}
  function valueText(k,value=state[k],menu=false){
    const p=definition(k);if(p.names)return p.names[p.values.indexOf(value)]||String(value);
    if(k==='range'||k==='rangeV')return Math.round(value*100)+' cm';
    if(k==='bearing')return pad(value)+'°';
    if(k==='tilt')return(value<0?'-':'')+pad(Math.abs(value),2)+'°';
    if(k==='frequency')return(menu?'*':'')+(value*1000)+' Hz';
    if(k==='tvg')return(menu?'*':'')+value+' LOG R';
    if(k==='pulse'||k==='pp'||k==='rcg'||k==='bottom')return(menu?'*':'')+value;
    if(k==='speed')return Number(value).toFixed(1)+' kn';
    if(k==='heading')return pad(value)+'°T';
    if(k==='simSpeed')return value+'×';
    if(typeof value==='boolean')return value?'ON':'OFF';
    return value+(p.unit?(p.unit==='°'?'':' ')+p.unit:'');
  }
  function normalize(k,value){
    if(C.PARAMS[k])return C.normalize(k,value);const p=EXTRA[k];if(!p)return undefined;
    if(p.values)return p.values.includes(value)?value:undefined;
    if(typeof value!=='number'||!Number.isFinite(value))return undefined;
    const v=Math.round(value/p.step)*p.step;return p.wrap?C.wrap(v):C.clamp(v,p.min,p.max);
  }
  function renderMenus(){
    $('parameterList').innerHTML=Object.entries(C.PARAMS).map(([k,p])=>'<button class="bevel parameter-row '+(field===k?'active':'')+'" data-field="'+k+'" title="'+esc(p.vn)+'"><span>'+p.label+': '+esc(valueText(k,state[k],true))+'</span></button>').join('');
    $('modeButton').textContent='Mode: '+valueText('orientation');
    document.querySelectorAll('[data-value]').forEach(el=>el.textContent=valueText(el.dataset.value));
    $('instrument').dataset.aspect=state.aspect;
    syncDemo();fitMenuText();
  }
  function fitMenuText(){document.querySelectorAll('.parameter-row>span').forEach(span=>{const width=span.parentElement.clientWidth;if(width>0&&span.scrollWidth>0)span.style.setProperty('--text-scale',Math.min(1,(width-6)/span.scrollWidth));});}
  function renderProperty(){
    const p=definition(field);$('propertyTitle').textContent=p.label+':';
    if(p.values){$('propertyContent').innerHTML='<div class="choice-list">'+p.values.map((v,i)=>'<button class="choice-option '+(v===state[field]?'active':'')+'" data-choice="'+i+'" aria-pressed="'+(v===state[field])+'">'+esc(valueText(field,v))+'</button>').join('')+'</div>';}
    else{
      $('propertyContent').innerHTML='<div class="numeric-editor"><input id="numericValue" class="numeric-value" type="number" min="'+p.min+'" max="'+p.max+'" step="'+p.step+'" value="'+state[field]+'" aria-label="'+p.label+'"><div class="numeric-buttons"><button class="bevel" data-adjust="'+field+':-1">−</button><button class="bevel" data-adjust="'+field+':1">+</button></div><input id="numericSlider" class="numeric-slider" type="range" min="'+p.min+'" max="'+p.max+'" step="'+p.step+'" value="'+state[field]+'" aria-label="'+p.label+' slider"></div>';
    }
    if(field!=='tx')$('propertyContent').insertAdjacentHTML('beforeend','<p class="property-note">'+esc((HELP[field]||p.help||p.vn||'').split('. ')[0])+'.</p>');
    const list=$('propertyContent').querySelector('.choice-list'),active=list?.querySelector('.active');if(active&&list)list.scrollTop=Math.max(0,active.offsetTop-list.offsetTop-list.clientHeight/2);
  }
  function selectField(k){if(!definition(k))return;field=k;$('propertyBox').hidden=false;$('propertyClosed').hidden=true;renderMenus();renderProperty();}
  function updateAlarms(){
    const list=[];if(!state.power)list.push({id:'power_off',kind:'warning',text:'POWER OFF: mô phỏng máy đã tắt.'});if(state.hull!=='DOWN')list.push({id:'hull_up',kind:'operator',text:'Đầu dò chưa hạ hoàn toàn: '+state.hull});if(state.tx==='OFF')list.push({id:'tx_off',kind:'warning',text:'TX OFF: hệ thống đang ở chế độ chờ.'});if(state.gain===0)list.push({id:'gain_zero',kind:'warning',text:'Gain bằng 0: phản hồi rất yếu.'});
    if(runtimeError)list.push({id:'runtime',kind:'system',text:'Lỗi hiển thị: '+runtimeError});
    list.push(...testAlarms);
    const count=kind=>list.filter(a=>a.kind===kind).length;
    $('warningsButton').textContent=count('warning')+' Warnings';$('operatorAlarmsButton').textContent=count('operator')+' Op. Alarms';$('systemAlarmsButton').textContent=count('system')+' Sys. Alarms';$('errorButton').classList.toggle('active',count('system')>0);
    if($('alertsDialog').open)$('alarmsList').innerHTML=list.length?list.map(a=>'<div class="alarm-row '+a.kind+(acknowledged.has(a.id)?' ack':'')+'"><span class="alarm-kind">'+esc(a.kind.toUpperCase())+'</span>'+esc(a.text)+(acknowledged.has(a.id)?' · Đã xác nhận':'')+'</div>').join(''):'<p>Không có cảnh báo hoặc lỗi đang hoạt động.</p>';
    return list;
  }
  function updateTraining(){
    training.update(state,time);const total=training.steps.length,done=training.steps.filter(s=>s.done).length,score=total?Math.round(done/total*100):0;
    $('trainingScore').textContent=total?score+'%':'Tự do';$('trainingProgress').style.width=score+'%';$('trainingElapsed').textContent=clock(time);$('trainingHits').textContent=training.hits+' / '+training.attempts;
    $('lessonDescription').textContent=scenario.description;$('taskList').innerHTML=training.steps.length?training.steps.map(s=>'<li class="'+(s.done?'done':'')+'">'+esc(s.text)+'</li>').join(''):'<li>Quan sát và thực hành tự do; không chấm điểm.</li>';
  }
  const displayRange=r=>r*(window.NanoLink?.liveMode?50:100);
  function renderMarks(){
    $('marksList').innerHTML=marks.length?marks.map(m=>'<div class="mark-row '+(selectedMark===m.label?'active':'')+'"><span data-select-mark="'+m.label+'">'+m.label+' '+displayRange(m.range).toFixed(1)+' cm</span><button data-delete-mark="'+m.label+'" title="Delete '+m.label+'">×</button></div>').join(''):'<div class="no-marks">No marks</div>';
  }
  function renderLog(){
    $('eventLog').innerHTML='<table><thead><tr><th>Time</th><th>Action</th><th>Value</th></tr></thead><tbody>'+training.events.slice(-300).reverse().map(e=>'<tr><td>'+clock(e.at)+'</td><td>'+esc(definition(e.action)?.label||e.action)+'</td><td>'+esc(typeof e.value==='object'?JSON.stringify(e.value):e.value)+'</td></tr>').join('')+'</tbody></table>';
  }
  function syncControls(){
    if(!$('controlsDialog').open)return;
    for(const k of ['range','tilt','bearing','gain']){
      const readout=document.querySelector('[data-knob-value="'+k+'"]');if(readout)readout.textContent=valueText(k);
      const knob=document.querySelector('[data-encoder="'+k+'"]');const angle=k==='bearing'?state[k]:k==='range'?C.PARAMS.range.values.indexOf(state[k])*220/(C.PARAMS.range.values.length-1)-110:k==='gain'?state[k]*5.5-110:(state[k]+90)*2.5-110;if(knob)knob.style.setProperty('--angle',angle+'deg');
    }
    document.querySelectorAll('[data-direct-param]').forEach(el=>{if(document.activeElement!==el)el.value=String(state[el.dataset.directParam]);});
    $('txButton').textContent='TX: '+state.tx+' [P]';
  }
  function refresh(){renderMenus();renderProperty();updateTraining();renderMarks();updateAlarms();syncControls();$('pauseOverlay').hidden=!paused||blockingDialog()||Boolean(training.endedAt);$('truthBadge').hidden=!truth;$('pauseButton').textContent=training.endedAt?'Session Finished':paused?'Resume [SPACE]':'Pause [SPACE]';}
  function record(action,value){training.record(action,value,time);scheduleSave();updateTraining();}
  function change(k,value,redrawEditor=true){
    const v=normalize(k,value);if(!window.NanoLink?.connected&&k==='tx'&&v!=='OFF'&&(!state.power||state.hull!=='DOWN')){toast('Bật POWER và LOWER đầu dò trước khi phát TX.');return;}if(v===undefined||v===state[k])return;if(k==='tilt')state.autoTilt=false;if(k==='bearing')state.autoTrain=false;if(k==='tx'&&v==='OFF'){state.autoTilt=false;state.autoTrain=false;}state[k]=v;
    if(k==='tx'&&v!=='OFF')lastTx=v;if(k==='range')cursor.range=Math.min(cursor.range,state.range);
    if(window.NanoLink?.connected)window.NanoLink.parameter(k,v);
    record(k==='orientation'?(v==='north'?'north':'bow'):k,v);renderer.dirty=true;renderMenus();if(redrawEditor)renderProperty();syncControls();updateAlarms();beep();status(definition(k).label+': '+valueText(k));
  }
  function adjust(k,delta){if(window.NanoLink?.connected&&window.NanoLink.adjust(k,delta))return;if(k==='tilt')state.autoTilt=false;if(k==='bearing')state.autoTrain=false;const p=definition(k);if(!p)return;if(p.values){const i=p.values.indexOf(state[k]);change(k,p.values[C.clamp(i+delta,0,p.values.length-1)]);}else change(k,state[k]+delta*p.step);}
  function setTab(tab){currentTab=tab;document.querySelectorAll('.tab-page').forEach(p=>p.hidden=p.id!=='tab-'+tab);document.querySelectorAll('[data-tab]').forEach(b=>{b.classList.toggle('active',b.dataset.tab===tab);b.setAttribute('aria-selected',String(b.dataset.tab===tab));});document.querySelector('.menu-pages').scrollTop=0;fitMenuText();if(tab==='objects')renderMarks();}
  function closeDialogs(){document.querySelectorAll('dialog[open]').forEach(d=>d.close());}
  function showDialog(id){window.NanoLink?.release();closeDialogs();$(id).showModal();if(id==='trainingDialog')updateTraining();if(id==='alertsDialog')updateAlarms();if(id==='logDialog')renderLog();if(id==='instructorDialog')renderInstructor();if(id==='controlsDialog')buildControls();if(id==='storeDialog')renderGallery();if(id==='settingsDialog')renderProfiles();}
  function initScenarios(){
    $('scenarioSelect').innerHTML=C.SCENARIOS.map(s=>'<option value="'+s.id+'">'+esc(s.name)+'</option>').join('');
    if(scenario.id==='custom'){const o=document.createElement('option');o.value='custom';o.textContent=scenario.name;$('scenarioSelect').append(o);}
    $('scenarioSelect').value=scenario.id;$('traineeInput').value=training.trainee;
  }
  function startScenario(next,{keepSettings=false}={}){
    if(window.NanoLink?.connected)window.NanoLink.stop();
    const trainee=training.trainee,aspect=state.aspect;scenario=next;state=keepSettings?{...state}:{...C.DEFAULTS,...(next.preset||{}),aspect};state.range=C.normalize('range',state.range)??C.DEFAULTS.range;state.rangeV=normalize('rangeV',state.rangeV)??C.DEFAULTS.rangeV;
    training=new C.Training(scenario,trainee);time=0;paused=false;cursor={bearing:C.wrap(state.heading+268),range:Math.min(13,state.range)};marks=[];nextMark=1;selectedMark=null;boatOffset={x:0,y:0};truth=false;symbols=[];nextSymbol=1;hullRemaining=state.hull==='LOWERING'||state.hull==='HOISTING'?3:0;state.autoTilt=false;state.autoTrain=false;recording=false;testAlarms=[];acknowledged.clear();lastTx=state.tx==='OFF'?'LOW':state.tx;
    $('truthCheck').checked=false;renderer.lastHeat=-Infinity;renderer.dirty=true;initScenarios();refresh();save();status(scenario.name,true);
  }
  function buildControls(){
    $('knobControls').innerHTML=['range','tilt','bearing','gain'].map(k=>'<div class="knob-group"><b>'+C.PARAMS[k].label.toUpperCase()+'</b><div class="knob" data-encoder="'+k+'"><i></i></div><strong data-knob-value="'+k+'">'+valueText(k)+'</strong><div class="knob-buttons"><button class="bevel" data-adjust="'+k+':-1">−</button><span>'+({range:'Q / E',tilt:'S / W',bearing:'−10° / +10°',gain:'J / K'}[k])+'</span><button class="bevel" data-adjust="'+k+':1">+</button></div></div>').join('');
    $('allParameterControls').innerHTML=Object.entries(C.PARAMS).map(([k,p])=>'<label class="all-control"><span>'+p.label+'</span>'+(p.values?'<select data-direct-param="'+k+'">'+p.values.map(v=>'<option value="'+esc(v)+'">'+esc(valueText(k,v))+'</option>').join('')+'</select>':'<input data-direct-param="'+k+'" type="number" min="'+p.min+'" max="'+p.max+'" step="'+p.step+'">')+'</label>').join('');syncControls();syncDemo();
  }
  function mark(){
    if(training.endedAt){toast('Buổi luyện đã kết thúc. Chọn Restart để luyện tiếp.');return;}if(marks.length>=40){toast('Tối đa 40 dấu. Xóa bớt để đặt thêm.');return;}
    const nowScenario={...scenario,contacts:scenario.contacts.map(c=>renderer.relativeContact(c,time,boatOffset))};
    const hit=window.NanoLink?.liveMode?window.NanoLink.findEcho(cursor,state):C.findEcho(cursor,nowScenario,state,0),m={label:'M'+String(nextMark++).padStart(2,'0'),bearing:cursor.bearing,range:Math.round(cursor.range*(window.NanoLink?.liveMode?1000:10))/(window.NanoLink?.liveMode?1000:10),at:Math.round(time*10)/10};
    marks.push(m);selectedMark=m.label;training.mark(Boolean(hit),time);renderMarks();updateTraining();scheduleSave();beep();
    status(m.label+' · '+displayRange(m.range).toFixed(1)+' cm / '+pad(m.bearing)+'°T'+(truth?' · '+(hit?'trúng '+hit.id:'ngoài cụm phản hồi'):''),true);
  }
  function deleteMark(label){const i=marks.findIndex(m=>m.label===label);if(i<0)return;marks.splice(i,1);if(selectedMark===label)selectedMark=null;record('delete_mark',label);renderMarks();status('Deleted '+label);}
  function pause(){if(window.NanoLink?.connected){window.NanoLink.toggleScan();return;}if(training.endedAt){toast('Buổi luyện đã kết thúc. Chọn Restart để bắt đầu lại.');return;}paused=!paused;record(paused?'paused':'resumed',true);$('pauseOverlay').hidden=!paused||blockingDialog();$('pauseButton').textContent=paused?'Resume [SPACE]':'Pause [SPACE]';status(paused?'PAUSED · SPACE để tiếp tục':'RUNNING');}
  function orientation(){change('orientation',state.orientation==='bow'?'north':'bow');}
  function renderInstructor(){
    $('seedInput').value=scenario.seed;$('noiseInput').value=Math.round(scenario.noise*100);$('noiseOutput').textContent=Math.round(scenario.noise*100)+'%';$('truthCheck').checked=truth;
    $('instructorContacts').innerHTML='<table><thead><tr><th>ID</th><th>Range</th><th>Bearing °T</th><th>Depth</th><th></th></tr></thead><tbody>'+scenario.contacts.map((c,i)=>{const p=renderer.relativeContact(c,time,boatOffset);return'<tr><td>'+esc(c.id)+'</td><td>'+(p.range*100).toFixed(1)+' cm</td><td>'+pad(p.bearing)+'</td><td>'+(c.depth*100).toFixed(1)+' cm</td><td><button data-edit-echo="'+i+'">Edit</button></td></tr>';}).join('')+'</tbody></table>';
  }
  function openEcho(index=null){
    const existing=index===null?null:scenario.contacts[index];editingId=existing?.id||null;
    let id=1;while(scenario.contacts.some(c=>c.id==='E'+pad(id,2)))id++;
    const c=existing?renderer.relativeContact(existing,time,boatOffset):{id:'E'+pad(id,2),range:Math.max(.01,cursor.range),bearing:cursor.bearing,depth:1,strength:.95,width:15,radial:0,angular:0,kind:'echo'};
    for(const k of ['id','range','bearing','depth','strength','width','radial','angular','kind'])$('echo'+k[0].toUpperCase()+k.slice(1)).value=typeof c[k]==='number'?Math.round(c[k]*(['range','depth','radial'].includes(k)?100:1)*1000)/1000:c[k];
    $('echoDialogTitle').textContent=existing?'Edit Echo · '+existing.id:'New Echo · Phản hồi giả lập';$('deleteEchoButton').hidden=!existing;showDialog('echoDialog');
  }
  function installEchoData(contacts){
    const custom=C.validateScenario({...scenario,name:'Bài tự do · dữ liệu tùy chỉnh',contacts,duration:0});closeDialogs();startScenario(custom,{keepSettings:true});
  }
  function saveEcho(){
    const candidate={};for(const k of ['id','range','bearing','depth','strength','width','radial','angular','kind']){const value=$('echo'+k[0].toUpperCase()+k.slice(1)).value;candidate[k]=['id','kind'].includes(k)?value:Number(value)/(['range','depth','radial'].includes(k)?100:1);}
    if(!candidate.id.trim()){toast('Hãy nhập mã phản hồi.');return;}
    const contacts=scenario.contacts.map(c=>renderer.relativeContact(c,time,boatOffset)),index=contacts.findIndex(c=>c.id===editingId);if(index>=0)contacts[index]=candidate;else contacts.push(candidate);
    try{installEchoData(contacts);}catch(e){toast('Không lưu được: '+e.message);}
  }
  function deleteEcho(){if(!editingId)return;try{installEchoData(scenario.contacts.filter(c=>c.id!==editingId).map(c=>renderer.relativeContact(c,time,boatOffset)));}catch(e){toast(e.message);}}
  function help(context=false){
    $('contextHelpText').textContent=context?(HELP[field]||EXTRA[field]?.help||definition(field).label+' thay đổi tùy chọn hiển thị tương ứng.'):'Chọn các nút ở bảng bên phải. Giá trị được chọn trong danh sách phía dưới. Horizontal / Display / Setup / Objects tương ứng các tab dọc trong ảnh.';showDialog('helpDialog');
  }
  function finish(){
    if(!training.endedAt){training.finish(state,marks,time);paused=true;save();}
    const r=training.report(state,marks,scenario);$('summaryContent').innerHTML='<div class="summary-number">'+(r.progress?r.progress.score+'%':'Tự do')+'</div><div class="summary-details">'+esc(training.trainee||'Chưa nhập tên học viên')+'<br>'+esc(scenario.name)+'<br>'+clock(time)+' · Dấu trúng '+training.hits+'/'+training.attempts+'</div><ul class="summary-tasks">'+training.steps.map(s=>'<li>'+(s.done?'✓ ':'○ ')+esc(s.text)+'</li>').join('')+'</ul>';showDialog('summaryDialog');refresh();
  }
  function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
  const stamp=()=>new Date().toISOString().slice(0,19).replace(/[:.]/g,'-');
  function reportJSON(){training.update(state,time);const report=training.report(state,marks,scenario);if(window.NanoLink?.liveMode){report.source='NANO';report.rangeUnits='cm';report.rangeReference='horizontal-projection';report.marks=report.marks.map(m=>({...m,range:displayRange(m.range)}));report.events=report.events.map(e=>e.action==='cursor'?{...e,value:{...e.value,range:displayRange(e.value.range)}}:e);report.rangeCalibration={slantMaxCm:state.range*100,horizontalMaxCm:state.range*50};report.settings.range*=100;report.settings.rangeV*=100;report.settingsDistanceUnits='cm';report.latestMeasurement=window.NanoLink.measurement();}report.bearingSelectorReference='relative-to-bow';report.markBearingReference='true-north';download(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}),'SH90-session-'+stamp()+'.json');}
  function reportCSV(){
    const safe=v=>/^[=+\-@\t\r]/.test(String(v))?"'"+v:String(v),quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
    const header=['Hoc vien','Kich ban','Thoi gian (s)','Thao tac','Gia tri'],rows=training.events.map(e=>[safe(training.trainee),safe(scenario.name),e.at,e.action,safe(typeof e.value==='object'?JSON.stringify(window.NanoLink?.liveMode&&e.action==='cursor'?{...e.value,range:displayRange(e.value.range)}:e.value):e.value)]);
    download(new Blob(['\ufeff'+[header,...rows].map(r=>r.map(quote).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),'SH90-log-'+stamp()+'.csv');
  }
  async function fullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(_){change('aspect','wide');toast('Giao diện đã phủ kín cửa sổ. Dùng F11 nếu trình duyệt chặn fullscreen.');}}
  const fullscreenMedia=window.matchMedia('(display-mode: fullscreen)');
  function syncViewport(){document.body.classList.toggle('browser-fullscreen',Boolean(document.fullscreenElement)||fullscreenMedia.matches);renderer.dirty=true;requestAnimationFrame(fitMenuText);}
  fullscreenMedia.addEventListener('change',syncViewport);

  function snapshot(){return{version:C.VERSION,state,scenario,time,paused,cursor,marks,symbols,nextSymbol,hullRemaining,nextMark,boatOffset,testAlarms,acknowledged:[...acknowledged],
    training:{trainee:training.trainee,startedAt:training.startedAt,endedAt:training.endedAt,completedAt:training.completedAt,events:training.events,actions:[...training.actions],visited:Object.fromEntries(Object.entries(training.visited).map(([k,v])=>[k,[...v]])),hits:training.hits,attempts:training.attempts,hitTimes:training.hitTimes,done:training.steps.map(s=>s.done),finalSnapshot:training.finalSnapshot}};}
  function save(){clearTimeout(saveTimer);try{localStorage.setItem(STORE,JSON.stringify(snapshot()));$('saveStatus').textContent='Đã lưu trên trình duyệt';}catch(_){$('saveStatus').textContent='Chưa lưu được · Hãy xuất báo cáo';}}
  function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(save,350);}
  function restore(){
    try{
      const json=localStorage.getItem(STORE)||localStorage.getItem('sh90-classic-v2');if(!json)return false;const raw=JSON.parse(json);if(![C.VERSION,'2.0.0'].includes(raw.version)||!raw.scenario||!raw.training)return false;
      scenario=raw.scenario.id==='custom'?C.validateScenario(raw.scenario):C.getScenario(raw.scenario.id);
      for(const k of [...Object.keys(C.PARAMS),...Object.keys(EXTRA)]){const v=normalize(k,raw.state?.[k]);if(v!==undefined)state[k]=v;}
      if(C.normalize('range',raw.state?.range)===undefined){state.range=C.DEFAULTS.range;state.rangeV=C.DEFAULTS.rangeV;state.zoom=false;state.offCentre=false;}if(raw.version==='2.0.0')state.aspect='wide';state.autoTilt=false;state.autoTrain=false;
      hullRemaining=['LOWERING','HOISTING'].includes(state.hull)?3:0;
      if(!state.power||state.hull!=='DOWN')state.tx='OFF';
      symbols=Array.isArray(raw.symbols)?raw.symbols.filter(m=>m&&['circle','own','gear'].includes(m.kind)&&/^S\d{2,5}$/.test(m.label)&&Number.isFinite(m.range)&&m.range>=0&&Number.isFinite(m.bearing)&&Number.isFinite(m.origin?.x)&&Number.isFinite(m.origin?.y)).slice(0,40):[];nextSymbol=Math.max(1,...symbols.map(m=>Number(m.label.slice(1))+1));
      time=Number.isFinite(raw.time)?C.clamp(raw.time,0,86400):0;paused=true;
      if(Number.isFinite(raw.cursor?.bearing)&&Number.isFinite(raw.cursor?.range))cursor={bearing:C.wrap(raw.cursor.bearing),range:C.clamp(raw.cursor.range,0,state.range)};
      if(Number.isFinite(raw.boatOffset?.x)&&Number.isFinite(raw.boatOffset?.y))boatOffset=raw.boatOffset;
      marks=Array.isArray(raw.marks)?raw.marks.filter(m=>m&&/^M\d{2,5}$/.test(m.label)&&Number.isFinite(m.range)&&m.range>=0&&Number.isFinite(m.bearing)).slice(0,40).map(m=>({...m,bearing:C.wrap(m.bearing)})):[];
      nextMark=Number.isInteger(raw.nextMark)?Math.max(1,raw.nextMark):marks.length+1;
      training=new C.Training(scenario,String(raw.training.trainee||'').slice(0,80));const t=raw.training;
      training.startedAt=typeof t.startedAt==='string'?t.startedAt:training.startedAt;training.endedAt=typeof t.endedAt==='string'?t.endedAt:null;training.completedAt=Number.isFinite(t.completedAt)?t.completedAt:null;
      training.events=Array.isArray(t.events)?t.events.filter(e=>e&&typeof e.action==='string'&&Number.isFinite(e.at)).slice(-2000):[];
      training.actions=new Set(Array.isArray(t.actions)?t.actions:[]);
      for(const[k,v]of Object.entries(t.visited||{}))if(Array.isArray(v)&&definition(k))training.visited[k]=new Set(v);
      training.hits=Number.isInteger(t.hits)?Math.max(0,t.hits):0;training.attempts=Number.isInteger(t.attempts)?Math.max(training.hits,t.attempts):training.hits;
      training.hitTimes=Array.isArray(t.hitTimes)?t.hitTimes.filter(Number.isFinite):[];training.steps.forEach((s,i)=>s.done=Boolean(t.done?.[i]));training.elapsed=time;
      if(training.endedAt&&t.finalSnapshot?.settings&&Array.isArray(t.finalSnapshot.marks))training.finalSnapshot=t.finalSnapshot;
      testAlarms=Array.isArray(raw.testAlarms)?raw.testAlarms.filter(a=>a&&['warning','operator','system'].includes(a.kind)&&typeof a.id==='string'&&typeof a.text==='string').slice(0,10):[];acknowledged=new Set(Array.isArray(raw.acknowledged)?raw.acknowledged:[]);lastTx=state.tx==='OFF'?'LOW':state.tx;
      return true;
    }catch(_){state={...C.DEFAULTS};scenario=C.getScenario('reference');time=0;training=new C.Training(scenario);marks=[];paused=false;return false;}
  }
  function syncDemo(){
    $('instrument').dataset.menuHidden=String(state.menuHidden);$('scopeStage').dataset.presentation=state.presentation;$('verticalSonar').hidden=state.presentation!=='split';
    document.querySelectorAll('[data-indicator]').forEach(b=>b.setAttribute('aria-pressed',String(Boolean(state[b.dataset.indicator]))));
    const readout=[!state.power?'POWER OFF':state.hull!=='DOWN'?'HULL '+state.hull:'',state.autoTilt?'AUTO TILT '+state.tilt+'°':'',state.autoTrain?'AUTO TRAIN '+pad(state.bearing)+'°':'',state.zoom?'ZOOM ×2':'',state.offCentre?'OFF CENTRE':'',recording?'● RECORDING':''].filter(Boolean).join(' · ');
    $('demoReadout').textContent=window.NanoLink?.liveMode?window.NanoLink.readout():readout;$('demoReadout').hidden=window.NanoLink?.liveMode?false:!readout;
    $('hullReadout').textContent=window.NanoLink?.liveMode?window.NanoLink.readout():(state.power?'POWER ON':'POWER OFF')+' · HULL '+state.hull+(hullRemaining?' · '+Math.ceil(hullRemaining)+' s':'')+' · TX '+state.tx;
    $('symbolList').textContent=symbols.length?symbols.length+' symbols · '+symbols.map(m=>m.label).join(', '):'No symbols';
    if($('controlsDialog').open)document.querySelectorAll('[data-demo-param]').forEach(el=>{const k=el.dataset.demoParam;if(el.tagName==='SELECT'&&!el.options.length)el.innerHTML=definition(k).values.map(v=>'<option value="'+esc(v)+'">'+esc(valueText(k,v))+'</option>').join('');if(document.activeElement!==el)el.value=state[k];});
  }
  function hullMove(direction){if(window.NanoLink?.connected){window.NanoLink.toggleMove(direction==='LOWERING'?'DOWN':'UP');return;}
    if(!state.power){toast('Bật POWER trước.');return;}
    if((direction==='LOWERING'&&state.hull==='DOWN')||(direction==='HOISTING'&&state.hull==='UP')){status('HULL '+state.hull,true);return;}
    state.tx='OFF';state.autoTilt=false;state.autoTrain=false;state.hull=direction;hullRemaining=3;record('hull',direction);renderer.dirty=true;refresh();status(direction+' · 3 giây mô phỏng; TX chuyển chờ',true);
  }
  function advanceHull(dt){if(window.NanoLink?.liveMode)return;if(!hullRemaining||!state.power)return;hullRemaining=Math.max(0,hullRemaining-dt);if(!hullRemaining){state.hull=state.hull==='LOWERING'?'DOWN':'UP';record('hull',state.hull);refresh();status('HULL '+state.hull+(state.hull==='DOWN'?' · Bấm P để phát TX':''),true);}}
  function toggleAuto(k){if(window.NanoLink?.connected){window.NanoLink.auto(k);return;}if(!state.power||state.hull!=='DOWN'||state.tx==='OFF'){toast('Auto cần POWER ON, HULL DOWN và TX đang phát.');return;}if(!state[k]){if(k==='autoTilt'){state.tiltCenter=state.tilt;autoStartTilt=time;}else{state.trainCenter=state.bearing;autoStartTrain=time;}}change(k,!state[k]);}
  function advanceAutomatic(){if(window.NanoLink?.liveMode)return;if(state.tx==='OFF'||state.hull!=='DOWN')return;if(state.autoTilt)state.tilt=C.scanValue(state.tiltCenter,state.tiltSpan,time-autoStartTilt,8,-90,0);if(state.autoTrain)state.bearing=C.wrap(C.scanValue(state.trainCenter,state.trainSpan,time-autoStartTrain,12,-360,720));}
  function mode(index){change('orientation',index%2?'north':'bow');change('presentation',index>=2?'split':'horizontal');record('mode',index+1);status('Mode '+(index+1)+' · '+valueText('orientation')+' · '+valueText('presentation'),true);}
  function cursorStep(direction){if(direction==='left'||direction==='right')cursor.bearing=C.wrap(cursor.bearing+(direction==='left'?-1:1)*2);else cursor.range=C.clamp(cursor.range+(direction==='up'?1:-1)*state.range*.02,0,state.range);record('cursor',{...cursor});}
  function addSymbol(kind){if(symbols.length>=40){toast('Tối đa 40 symbol; xóa bớt để thêm.');return;}const p=kind==='own'?{bearing:state.heading,range:0}:cursor;const symbol={label:'S'+String(nextSymbol++).padStart(2,'0'),kind,bearing:p.bearing,range:p.range,origin:{...boatOffset}};symbols.push(symbol);record('symbol',symbol);syncDemo();status(symbol.label+' · '+kind.toUpperCase(),true);}
  function shortcut(kind){$('shortcutTitle').textContent=kind==='view'?'View · Menu trình bày':'Object · Menu tại con trỏ';const entries=kind==='view'?[['zoom','Zoom ×2'],['offCentre','Off Centre'],['orientation','Bow / North Up'],['vertical','Horizontal / H + Vertical'],['toggleSweep','Sweep Line'],['menu','Hide / Show Menu']]:[['mark','New Mark'],['circleSymbol','Circle Symbol'],['ownSymbol','Own Ship Symbol'],['gearSymbol','Gear Symbol'],['deleteLastMark','Delete Last Mark'],['deleteSymbol','Delete Oldest Symbol']];$('shortcutContent').innerHTML='<div class="button-grid">'+entries.map(([action,label])=>'<button class="bevel" data-action="'+action+'">'+label+'</button>').join('')+'</div><button class="bevel" data-action="select">Select / Close</button>';showDialog('shortcutDialog');}
  function captureImage(){if(images.length>=12){recording=false;status('Đã đủ 12 ảnh. Tải ảnh cần giữ rồi xóa bớt.',true);renderGallery();return false;}const id=String(Date.now())+'-'+images.length;images.push({id,name:'SH90-'+stamp()+'-'+images.length+'.png',at:time,url:renderer.snapshot(state,time).toDataURL('image/png')});record('store_image',id);if($('storeDialog').open)renderGallery();return true;}
  function recordImage(){if($('storeMode').value==='sequence'){if(images.length>=12&&!recording){toast('Đã đủ 12 ảnh; xóa bớt trước.');return;}recording=!recording;if(recording){captureImage();lastCapture=time;}record('record_sequence',recording);status(recording?'RECORDING · Đóng hộp thoại để thời gian tiếp tục':'RECORD STOPPED',true);}else{if(captureImage())status('Đã lưu ảnh · F6 để Recall / Download',true);}syncDemo();if($('storeDialog').open)renderGallery();}
  function renderGallery(){$('recordStatus').textContent=(recording?'● RECORDING':'STOPPED')+' · '+images.length+' / 12 ảnh';$('imageGallery').innerHTML=images.map(im=>'<button class="bevel gallery-item" data-recall="'+im.id+'"><img src="'+im.url+'" alt="Sonar '+clock(im.at)+'"><span>'+clock(im.at)+' · Recall</span></button>').join('')||'<p>Chưa có ảnh. Bấm Record để lưu.</p>';}
  function recallImage(id){const im=images.find(im=>im.id===id);if(!im)return;recalledId=id;$('recallTitle').textContent='Recall · '+im.name;$('recalledImage').src=im.url;showDialog('recallDialog');record('recall_image',id);}
  function loadProfiles(){try{const raw=JSON.parse(localStorage.getItem('sh90-user-settings')||'[]');profiles=Array.isArray(raw)?raw.slice(0,4):[];}catch(_){profiles=[];}}
  function renderProfiles(){$('profileList').innerHTML=Array.from({length:4},(_,i)=>'<div class="profile-row"><input id="profileName'+i+'" maxlength="40" aria-label="Tên bộ '+(i+1)+'" value="'+esc(profiles[i]?.name||'User '+(i+1))+'"><button class="bevel" data-save-profile="'+i+'">Save</button><button class="bevel" data-load-profile="'+i+'" '+(!profiles[i]?'disabled':'')+'>Recall</button></div>').join('');}
  function saveProfile(i){profiles[i]={name:($('profileName'+i).value||'User '+(i+1)).slice(0,40),settings:{...state}};try{localStorage.setItem('sh90-user-settings',JSON.stringify(profiles));record('save_profile',i+1);renderProfiles();status('Đã lưu User '+(i+1),true);}catch(_){toast('Không lưu được; trình duyệt chặn lưu dữ liệu.');}}
  function loadProfile(i){const profile=profiles[i];if(!profile?.settings)return;const excluded=new Set(['power','hull','autoTilt','autoTrain','menuHidden']);for(const k of [...Object.keys(C.PARAMS),...Object.keys(EXTRA)]){if(excluded.has(k))continue;const v=normalize(k,profile.settings[k]);if(v!==undefined)state[k]=v;}if(C.normalize('range',profile.settings.range)===undefined){state.zoom=false;state.offCentre=false;}state.autoTilt=false;state.autoTrain=false;if(!state.power||state.hull!=='DOWN')state.tx='OFF';if(window.NanoLink?.connected&&state.tx==='OFF')window.NanoLink.scan(false);cursor.range=Math.min(cursor.range,state.range);renderer.dirty=true;record('recall_profile',i+1);refresh();status('Đã nạp '+String(profile.name),true);}
  const actions={
    help:()=>help(false),contextHelp:()=>help(true),closeDialog:closeDialogs,
    controls:()=>showDialog('controlsDialog'),training:()=>showDialog('trainingDialog'),instructor:()=>showDialog('instructorDialog'),alerts:()=>showDialog('alertsDialog'),showLog:()=>showDialog('logDialog'),
    fullscreen,pause,orientation,mark,tx:()=>change('tx',state.tx==='OFF'?lastTx:'OFF'),
    power:()=>{if(window.NanoLink?.connected){window.NanoLink.power(!state.power);}state.power=!state.power;state.tx='OFF';state.autoTilt=false;state.autoTrain=false;recording=false;if(!state.power){state.hull='UP';hullRemaining=0;}record('power',state.power);refresh();status(state.power?'POWER ON · LOWER đầu dò rồi bật TX':'POWER OFF · chỉ tắt máy giả lập',true);},
    lower:()=>hullMove('LOWERING'),hoist:()=>hullMove('HOISTING'),
    autoTilt:()=>toggleAuto('autoTilt'),autoTrain:()=>toggleAuto('autoTrain'),tiltManual:()=>{if(window.NanoLink?.connected)window.NanoLink.scan(false);change('autoTilt',false);},trainManual:()=>{window.NanoLink?.panManual();change('autoTrain',false);},
    zoom:()=>{if(!state.zoom){state.zoomBearing=cursor.bearing;state.zoomRange=cursor.range;}change('zoom',!state.zoom);},
    offCentre:()=>{if(!state.offCentre){const p=renderer.point(cursor.bearing,cursor.range,state);state.offX=C.clamp(p.x/renderer.width,.15,.85);state.offY=C.clamp(p.y/renderer.height,.15,.85);}change('offCentre',!state.offCentre);},
    menu:()=>change('menuHidden',!state.menuHidden),toggleSweep:()=>{if(window.NanoLink?.connected){window.NanoLink.toggleScan();return;}change('sweep',!state.sweep);},vertical:()=>change('presentation',state.presentation==='split'?'horizontal':'split'),
    mute:()=>{change('sound',false);actions.ackAlarms();status('MUTE · Đã xác nhận cảnh báo',true);},
    circleSymbol:()=>addSymbol('circle'),ownSymbol:()=>addSymbol('own'),gearSymbol:()=>addSymbol('gear'),deleteSymbol:()=>{if(symbols.length){record('delete_symbol',symbols.shift().label);syncDemo();}},clearSymbols:()=>{symbols=[];record('clear_symbols',true);syncDemo();},
    storeRecall:()=>showDialog('storeDialog'),recordImage,userSettings:()=>showDialog('settingsDialog'),
    clearImages:()=>{recording=false;images=[];renderGallery();record('clear_images',true);},
    downloadRecalled:()=>{const im=images.find(im=>im.id===recalledId);if(im){const bytes=Uint8Array.from(atob(im.url.split(',')[1]),c=>c.charCodeAt(0));download(new Blob([bytes],{type:'image/png'}),im.name);}},
    deleteRecalled:()=>{images=images.filter(im=>im.id!==recalledId);showDialog('storeDialog');},
    viewMenu:()=>shortcut('view'),objectMenu:()=>shortcut('object'),select:()=>{if($('shortcutDialog').open){closeDialogs();return;}selectField(field);closeDialogs();$('propertyContent').querySelector('.active,input')?.focus();status('SELECT · '+definition(field).label);},
    closeProperty:()=>{$('propertyBox').hidden=true;$('propertyClosed').hidden=false;},
    restart:()=>showDialog('restartDialog'),confirmRestart:()=>{closeDialogs();startScenario(scenario.id==='custom'?C.validateScenario(scenario):C.getScenario(scenario.id));},
    resetSettings:()=>{if(window.NanoLink?.connected)window.NanoLink.stop();const aspect=state.aspect;state={...C.DEFAULTS,aspect};hullRemaining=0;recording=false;cursor.range=Math.min(cursor.range,state.range);record('reset_settings',true);renderer.dirty=true;refresh();status('Default settings restored.');},
    deleteLastMark:()=>{if(marks.length)deleteMark(marks.at(-1).label);},clearMarks:()=>{marks=[];selectedMark=null;record('clear_marks',true);renderMarks();},
    report:reportJSON,reportCSV,finish,
    screenshot:()=>renderer.snapshot(state,time).toBlob(blob=>{if(blob)download(blob,'SH90-sonar-'+stamp()+'.png');},'image/png'),
    addEcho:()=>openEcho(),saveEcho,deleteEcho,
    generate:()=>{const seed=Number($('seedInput').value),count=Number($('countInput').value),noise=Number($('noiseInput').value)/100;if(!Number.isInteger(seed)||seed<0||seed>4294967295||!Number.isInteger(count)||count<0||count>30){toast('Seed 0–4294967295, số cụm 0–30.');return;}closeDialogs();startScenario(C.generateScenario(seed,count,noise));},
    exportScenario:()=>download(new Blob([JSON.stringify(scenario,null,2)],{type:'application/json'}),'SH90-scenario-'+stamp()+'.json'),importScenario:()=>$('scenarioFile').click(),
    ackAlarms:()=>{for(const a of updateAlarms())acknowledged.add(a.id);record('acknowledge_alarms',true);updateAlarms();},
    clearAlarms:()=>{testAlarms=[];acknowledged.clear();record('clear_test_alarms',true);updateAlarms();},
  };
  document.addEventListener('click',e=>{
    const b=e.target.closest('button');
    if(b&&!b.disabled){
      if(b.dataset.action)actions[b.dataset.action]?.();if(b.dataset.mode!==undefined)mode(Number(b.dataset.mode));if(b.dataset.cursor)cursorStep(b.dataset.cursor);if(b.dataset.recall)recallImage(b.dataset.recall);if(b.dataset.saveProfile!==undefined)saveProfile(Number(b.dataset.saveProfile));if(b.dataset.loadProfile!==undefined)loadProfile(Number(b.dataset.loadProfile));if(b.dataset.tab)setTab(b.dataset.tab);if(b.dataset.field)selectField(b.dataset.field);
      if(b.dataset.choice!==undefined)change(field,definition(field).values[Number(b.dataset.choice)]);
      if(b.dataset.adjust){const[k,d]=b.dataset.adjust.split(':');adjust(k,Number(d));}
      if(b.dataset.deleteMark)deleteMark(b.dataset.deleteMark);if(b.dataset.editEcho!==undefined)openEcho(Number(b.dataset.editEcho));
      if(b.dataset.testAlarm){const kind=b.dataset.testAlarm;if(!testAlarms.some(a=>a.id==='test_'+kind))testAlarms.push({id:'test_'+kind,kind,text:'Cảnh báo thử do người dùng tạo.'});acknowledged.delete('test_'+kind);record('test_alarm',kind);updateAlarms();}
    }
    const markEl=e.target.closest('[data-select-mark]');if(markEl){const m=marks.find(m=>m.label===markEl.dataset.selectMark);if(m){selectedMark=m.label;cursor={bearing:m.bearing,range:Math.min(state.range,m.range)};record('select_mark',m.label);renderMarks();}}
  });
  document.addEventListener('change',e=>{
    if(e.target.dataset.demoParam){const k=e.target.dataset.demoParam;change(k,Number(e.target.value));}
    if(e.target.id==='storeMode'){recording=false;renderGallery();}
    if(e.target.id==='numericValue'){if(e.target.value===''){renderProperty();return;}change(field,Number(e.target.value));}
    if(e.target.dataset.directParam){const k=e.target.dataset.directParam,p=C.PARAMS[k];change(k,p.values&&typeof p.values[0]==='string'?e.target.value:Number(e.target.value));}
  });
  document.addEventListener('input',e=>{if(e.target.id==='numericSlider'){change(field,Number(e.target.value),false);$('numericValue').value=state[field];}});
  $('scenarioSelect').addEventListener('change',e=>{if(e.target.value!=='custom'){const wasOpen=$('trainingDialog').open;startScenario(C.getScenario(e.target.value));if(wasOpen)updateTraining();}});
  $('traineeInput').addEventListener('input',e=>{training.trainee=e.target.value.slice(0,80);scheduleSave();});
  $('truthCheck').addEventListener('change',e=>{truth=e.target.checked;record('instructor_truth',truth);$('truthBadge').hidden=!truth;});
  $('noiseInput').addEventListener('input',e=>$('noiseOutput').textContent=e.target.value+'%');
  $('scenarioFile').addEventListener('change',async e=>{
    const f=e.target.files[0];if(!f)return;try{if(f.size>256000)throw new Error('Tệp lớn hơn 250 KB.');const next=C.validateScenario(JSON.parse(await f.text()));closeDialogs();startScenario(next);}catch(error){toast('Không nhập được kịch bản: '+error.message);}finally{e.target.value='';}
  });
  let dragging=false;
  function moveCursor(e){const p=renderer.polarFromEvent(e,state);if(p.range>state.range||p.range<0)return;cursor={bearing:p.bearing,range:C.clamp(p.range,0,state.range)};}
  $('sonar').addEventListener('pointerdown',e=>{dragging=true;$('sonar').setPointerCapture(e.pointerId);moveCursor(e);$('sonar').focus({preventScroll:true});});
  $('sonar').addEventListener('pointermove',e=>{if(dragging)moveCursor(e);});
  $('sonar').addEventListener('pointerup',()=>{if(dragging){dragging=false;record('cursor',{bearing:Math.round(cursor.bearing*10)/10,range:Math.round(cursor.range*10000)/10000});status('B: '+pad(C.wrap(cursor.bearing-state.heading))+'° · '+displayRange(cursor.range).toFixed(1)+' cm');}});
  $('sonar').addEventListener('contextmenu',e=>{e.preventDefault();moveCursor(e);shortcut('object');});
  $('sonar').addEventListener('pointercancel',()=>dragging=false);$('sonar').addEventListener('dblclick',mark);
  document.addEventListener('wheel',e=>{const knob=e.target.closest('[data-encoder]'),row=e.target.closest('[data-field]');if(knob||row){e.preventDefault();adjust(knob?.dataset.encoder||row.dataset.field,e.deltaY<0?1:-1);}},{passive:false});
  $('sonar').addEventListener('wheel',e=>{e.preventDefault();adjust('range',e.deltaY<0?-1:1);},{passive:false});
  const keyAdjust={KeyQ:['range',-1],KeyE:['range',1],KeyS:['tilt',-1],KeyW:['tilt',1],KeyJ:['gain',-1],KeyK:['gain',1]};
  const keyActions={KeyZ:'zoom',KeyX:'offCentre',KeyM:'menu',KeyL:'lower',KeyI:'hoist',F3:'power',F4:'mute',F6:'storeRecall',F7:'recordImage',KeyY:'circleSymbol',Digit0:'ownSymbol',KeyG:'gearSymbol',KeyV:'viewMenu',KeyO:'objectMenu',Space:'pause',KeyP:'tx',KeyN:'orientation',Enter:'mark',KeyF:'fullscreen',KeyC:'screenshot',KeyH:'help',F2:'controls',KeyR:'restart',KeyT:'addEcho'};
  document.addEventListener('keydown',e=>{
    if(e.ctrlKey||e.altKey||e.metaKey||e.isComposing)return;const input=e.target.closest('input,select,textarea,[contenteditable=true]');
    if(e.code==='KeyH'&&$('helpDialog').open&&!input){e.preventDefault();closeDialogs();return;}
    if(!input&&e.code==='F2'){e.preventDefault();if($('controlsDialog').open)closeDialogs();else showDialog('controlsDialog');return;}
    if(!input&&['F6','F7'].includes(e.code)&&$('storeDialog').open){e.preventDefault();if(e.code==='F6')closeDialogs();else recordImage();return;}
    if(blockingDialog()||input)return;
    if(/^Digit[5-8]$/.test(e.code)){e.preventDefault();mode(Number(e.code.slice(-1))-5);return;}
    if(e.target.closest('button')&&['Space','Enter'].includes(e.code))return;const fast=e.shiftKey?5:1;
    if(keyAdjust[e.code]){e.preventDefault();const[k,d]=keyAdjust[e.code];adjust(k,d*fast);return;}
    if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code)){
      e.preventDefault();if(e.code==='ArrowLeft'||e.code==='ArrowRight')cursor.bearing=C.wrap(cursor.bearing+(e.code==='ArrowLeft'?-1:1)*fast);
      else cursor.range=C.clamp(cursor.range+(e.code==='ArrowUp'?1:-1)*state.range*.01*fast,0,state.range);record('cursor',{bearing:cursor.bearing,range:cursor.range});return;
    }
    if(/^Digit[1-4]$/.test(e.code)){e.preventDefault();setTab(['sonar','display','setup','objects'][Number(e.code.slice(-1))-1]);return;}
    if(e.code==='Backspace'){e.preventDefault();actions.deleteLastMark();return;}
    if(keyActions[e.code]){e.preventDefault();if(!e.repeat)actions[keyActions[e.code]]();}
  });
  document.querySelectorAll('dialog').forEach(d=>d.addEventListener('close',()=>{$('pauseOverlay').hidden=!paused||blockingDialog()||Boolean(training.endedAt);}));
  document.addEventListener('fullscreenchange',syncViewport);
  window.addEventListener('resize',syncViewport);
  let lastFrame=0,lastDraw=0,lastUI=0;
  document.addEventListener('visibilitychange',()=>{lastFrame=0;if(document.hidden)save();});window.addEventListener('pagehide',save);setInterval(save,5000);
  window.addEventListener('error',e=>{runtimeError=String(e.message||'Unknown').slice(0,200);updateAlarms();});
  window.NanoUI={
    notify:message=>status(message,true),
    resetHome:()=>{cursor={bearing:state.heading,range:0};renderer.dirty=true;},
    receive:(hw)=>{paused=!hw.scanning;state.sweep=!!hw.scanning;state.autoTilt=!!hw.scanning;state.autoTrain=false;
      hullRemaining=0;state.hull=hw.motor==='home'?'HOISTING':hw.motor==='move'?(window.NanoLink.direction==='UP'?'HOISTING':'LOWERING'):(hw.pos>0?'DOWN':'UP');
      const bearing=C.wrap(-window.SonarCalibration.azimuth(hw.servo1_us??1400));if(state.bearing!==bearing){state.bearing=bearing;renderMenus();}syncDemo();syncControls();$('pauseOverlay').hidden=!paused||blockingDialog();$('pauseButton').textContent=paused?'Resume [SPACE]':'Pause [SPACE]';
    },
    lost:()=>{state.autoTilt=false;state.autoTrain=false;renderer.dirty=true;},
    view:()=>state,
  };
  const restored=restore();loadProfiles();initScenarios();refresh();syncViewport();if(restored)status('Đã khôi phục buổi luyện · SPACE để tiếp tục',true);else status('v3.0 · F2 bảng nút · F toàn màn hình');
  function frame(now){
    requestAnimationFrame(frame);const dt=lastFrame?Math.min((now-lastFrame)/1000,.15):0;lastFrame=now;
    if(!blockingDialog()&&!document.hidden)advanceHull(dt);
    if(running()){
      const step=dt*state.simSpeed;time+=step;advanceAutomatic();if(recording&&time-lastCapture>=2){captureImage();lastCapture=time;}const distance=(window.NanoLink?.liveMode?0:state.speed)*.514444*step;boatOffset.x+=Math.sin(state.heading*C.RAD)*distance;boatOffset.y+=Math.cos(state.heading*C.RAD)*distance;
      if(!window.NanoLink?.liveMode&&scenario.duration&&time>=scenario.duration){time=scenario.duration;finish();}
    }
    if(now-lastDraw>=1000/30){renderer.draw(state,scenario,time,cursor,marks,{truth,boatOffset,selectedMark,symbols});lastDraw=now;}
    if(now-lastUI>400){if(state.autoTilt||state.autoTrain){renderMenus();syncControls();}syncDemo();if($('trainingDialog').open)updateTraining();$('pauseOverlay').hidden=!paused||blockingDialog()||Boolean(training.endedAt);lastUI=now;}
  }
  requestAnimationFrame(frame);
})();
