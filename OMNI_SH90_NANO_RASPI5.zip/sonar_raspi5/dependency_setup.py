"""Install missing declared Python dependencies in a project venv, never globally."""
from pathlib import Path
import os
import subprocess
import sys
import venv

PROBE = 'import serial; from serial.tools import list_ports; assert callable(serial.Serial); assert callable(list_ports.comports)'

def _probe(python: Path, code: str) -> bool:
    try:
        return subprocess.run([str(python), '-c', code], stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL, timeout=20).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False

def _run_install(command, description):
    try:
        subprocess.run(command, check=True, timeout=240)
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(description + '\nKiem tra Internet va thu chay lai main.py. '
                           'Khong can cai pip vao Python he thong.') from exc

def ensure_dependencies(root: Path):
    """Return venv Python to re-exec, or None if this interpreter is ready.

    Only installs requirements.txt after the declared pyserial API probe fails.
    Application source files are validated separately and never guessed as packages.
    """
    root = root.resolve()
    for name in ('server.py', 'hardware_bridge.py', 'requirements.txt', 'web/index.html'):
        if not (root / name).is_file():
            raise RuntimeError('Thieu tep du an: ' + name + '. Hay giai nen toan bo ZIP; pip khong khoi phuc tep nay.')
    env_dir = root / '.venv'
    env_python = env_dir / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    current_python = Path(sys.executable)
    in_project_env = Path(sys.prefix).resolve() == env_dir.resolve()

    if in_project_env and _probe(current_python, PROBE):
        print('Thu vien Python: OK (moi truong du an).', flush=True)
        return None
    if not in_project_env and env_python.is_file() and _probe(env_python, PROBE):
        print('Dung thu vien da cai trong .venv; khong can tai lai.', flush=True)
        return env_python
    if not in_project_env and not env_python.is_file() and _probe(current_python, PROBE):
        print('Thu vien Python: OK; khong can cai them.', flush=True)
        return None

    print('Thieu pyserial hoac module serial khong dung. Dang tu cai thu vien du an...', flush=True)
    if not _probe(env_python, 'pass'):
        try:
            venv.EnvBuilder(with_pip=True).create(env_dir)
        except (OSError, subprocess.CalledProcessError, SystemExit) as exc:
            raise RuntimeError('Khong tao duoc .venv. Tren Pi chay mot lan: '
                               'sudo apt install python3-venv python3-pip\n'
                               'Sau do chay lai: python3 main.py') from exc
    if not _probe(env_python, 'import pip'):
        _run_install([str(env_python), '-m', 'ensurepip', '--upgrade'],
                     'Khong khoi tao duoc pip trong .venv. Tren Pi: sudo apt install python3-venv python3-pip')
    _run_install([str(env_python), '-m', 'pip', 'install', '--disable-pip-version-check',
                  '--retries', '2', '--timeout', '20', '-r', str(root / 'requirements.txt')],
                 'Cai thu vien Python that bai.')
    if not _probe(env_python, PROBE):
        raise RuntimeError('Da cai requirements nhung pyserial van khong dung API. '
                           'Kiem tra tep serial.py/trung ten module trong thu muc du an; '
                           'xem startup_error.log. Chuong trinh se khong lap cai vo han.')
    print('Cai thu vien thanh cong. Dang khoi dong Sonar...', flush=True)
    return None if in_project_env else env_python
