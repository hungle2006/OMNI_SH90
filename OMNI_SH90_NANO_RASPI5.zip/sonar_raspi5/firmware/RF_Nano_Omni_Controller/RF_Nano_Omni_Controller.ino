/*
  RF-Nano / Arduino Nano ATmega328P - OMNI Sonar laptop bridge v2
  Wiring:
    D3 = SoftwareSerial RX <- sonar white TX
    D2 = SoftwareSerial TX -> sonar yellow RX
    D4 = NO top HOME switch to GND, INPUT_PULLUP (LOW=pressed)
    D5 = stepper PUL+ (driver-compatible signalling)
    D6 = stepper DIR+ (HIGH=UP; LOW=DOWN)
    D10 = servo1 scan signal (500..2500 us, VERIFY SERVO RATING)
    D9 = servo2 pan signal (-30..+30 deg; 500/900/1200us calibration)
  Servo power from separate regulated supply; GND common.
  USB Serial 115200, newline-terminated ASCII commands; JSON status/echo lines.
  SoftwareSerial at 115200 is near AVR limits.  Use another MCU with
  hardware UART for reliable sensor acquisition where required.
*/
#include <Arduino.h>
#include <Servo.h>
#include <SoftwareSerial.h>
#include <string.h>
#include <stdlib.h>

constexpr uint8_t SONAR_RX = 3, SONAR_TX = 2, HOME_PIN = 4;
constexpr uint8_t STEP_PIN = 5, DIR_PIN = 6;
constexpr uint8_t SERVO1_PIN = 10, SERVO2_PIN = 9;
constexpr uint32_t BAUD = 115200UL;
constexpr unsigned long HOME_MAX_PULSES = 40000UL;
constexpr unsigned long HOME_TIMEOUT_MS = 180000UL;
constexpr unsigned long HOME_CONFIRM_MS=2000UL;
bool homeConfirming=false; unsigned long homeLowSince=0;
constexpr unsigned long HOST_WATCHDOG_MS = 2500UL;
// Direct waveform from the user's tested sketch; no acceleration scheduler.
constexpr unsigned long STEP_HIGH_US=500UL, STEP_LOW_US=500UL;
bool directionKnown=false, lastStepDown=false;
constexpr int SERVO1_MIN_US = 500, SERVO1_MAX_US = 2500;
constexpr int PAN_MAX_DEG = 30;
constexpr long DEFAULT_DOWN_LIMIT = 0; // 0 = no cumulative downward pulse limit
constexpr long MAX_DOWN_LIMIT = 12000;

SoftwareSerial sonar(SONAR_RX, SONAR_TX); // receive, transmit
Servo servo1, servo2;
char lineBuffer[64]; uint8_t lineLength=0;
enum MotorState : uint8_t { IDLE=0, HOMING=1, MOVING=2 };
MotorState motorState = IDLE;
int32_t posPulses=0, moveRemaining=0, downLimit=DEFAULT_DOWN_LIMIT;
bool continuousMove=false; unsigned long lastMoveLeaseMs=0;
bool homed=false, armed=false, movingDown=false, moveStartedPressed=false, seenRelease=false;
uint16_t movePressedSteps=0;
constexpr unsigned long DOWN_SWITCH_DEBOUNCE_MS=20;
bool downReleaseTiming=false, downPressTiming=false;
unsigned long downReleaseSince=0, downPressSince=0;
unsigned long lastPulseUs=0, homeStartedMs=0, homeSent=0, homePulseCount=0;
unsigned long lastHostMs=0, lastStatusMs=0;
unsigned long lastScanMs=0, lastSonarMs=0;
int servo1Us=1400, servo1Dir=1, servo1Rate=10, panDeg=0;
bool scanning=false, lastSonarValid=false, scanInitialized=false;
uint16_t sonarMm=0, echoSequence=0; unsigned long sonarMeasuredAt=0;
uint8_t sonarFrame[4], sonarIndex=0;
bool awaitingSonar=false;
int measuredServo1=1400, measuredPan=0; float measuredPhase=0;
bool measuredOrientationReady=false;
int panPulse(int deg){return deg<0?900-((-deg*400+15)/30):900+((deg*300+15)/30);}
float scanPhase(){float a=(servo1Us-1400)*.18f;return a<0?a+360.0f:a;}


bool pressed(){return digitalRead(HOME_PIN)==LOW;}
void event(const __FlashStringHelper *kind){ Serial.print(F("{\"type\":\"event\",\"event\":\""));Serial.print(kind);Serial.println(F("\"}")); }
void error(const __FlashStringHelper *msg){Serial.print(F("{\"type\":\"error\",\"message\":\""));Serial.print(msg);Serial.println(F("\"}"));}
void stopped(){digitalWrite(STEP_PIN,LOW);homeConfirming=false;motorState=IDLE;moveRemaining=0;armed=false;continuousMove=false;}
void stopAll(){stopped();scanning=false;event(F("stopped"));}
void setPan(int deg){panDeg=constrain(deg,-PAN_MAX_DEG,PAN_MAX_DEG); // calibrated D9: -30=500us, 0=900us, +30=1200us
 int pulse=panPulse(panDeg);
 if(!servo2.attached())servo2.attach(SERVO2_PIN,500,2500);
 servo2.writeMicroseconds(pulse);
}
void setServo1(int pulse){servo1Us=constrain(pulse,SERVO1_MIN_US,SERVO1_MAX_US);if(!servo1.attached())servo1.attach(SERVO1_PIN,SERVO1_MIN_US,SERVO1_MAX_US);servo1.writeMicroseconds(servo1Us);}
void sendStatus(){
 Serial.print(F("{\"type\":\"status\",\"device\":\"OMNI_NANO\",\"protocol\":3,\"homed\":"));Serial.print(homed?F("true"):F("false"));
 Serial.print(F(",\"armed\":"));Serial.print(armed?F("true"):F("false"));
 Serial.print(F(",\"motor\":\""));Serial.print(motorState==HOMING?F("home"):motorState==MOVING?F("move"):F("idle"));
 Serial.print(F("\",\"limit_pressed\":"));Serial.print(pressed()?F("true"):F("false"));
 Serial.print(F(",\"home_confirming\":"));Serial.print(homeConfirming?F("true"):F("false"));
 Serial.print(F(",\"home_confirm_ms\":"));Serial.print(homeConfirming?((millis()-homeLowSince)>HOME_CONFIRM_MS?HOME_CONFIRM_MS:(millis()-homeLowSince)):0UL);
 Serial.print(F(",\"pos\":"));Serial.print(posPulses);
 Serial.print(F(",\"down_limit\":"));Serial.print(downLimit);
 Serial.print(F(",\"scan_phase_deg\":"));Serial.print(scanPhase(),2);
 Serial.print(F(",\"servo1_us\":"));Serial.print(servo1Us);
 Serial.print(F(",\"servo2_deg\":"));Serial.print(panDeg);
 Serial.print(F(",\"servo2_us\":"));Serial.print(panPulse(panDeg));
 Serial.print(F(",\"orientation_ready\":"));Serial.print(servo1.attached()&&servo2.attached()?F("true"):F("false"));
 Serial.print(F(",\"scanning\":"));Serial.print(scanning?F("true"):F("false"));
 Serial.print(F(",\"distance_mm\":"));Serial.print(lastSonarValid&&millis()-sonarMeasuredAt<1400?sonarMm:0);
 Serial.print(F(",\"sonar_ok\":"));Serial.print(lastSonarValid&&millis()-sonarMeasuredAt<1400?F("true"):F("false"));
 Serial.println('}');
}
void resetStepTiming(){digitalWrite(STEP_PIN,LOW);}
void pulseStep(bool down){
 if(!directionKnown||lastStepDown!=down){digitalWrite(DIR_PIN,down?LOW:HIGH);delayMicroseconds(15);lastStepDown=down;directionKnown=true;}
 digitalWrite(STEP_PIN,HIGH);
 delayMicroseconds(500);
 digitalWrite(STEP_PIN,LOW);
 delayMicroseconds(500);
 if(homed){if(down){if(posPulses<2147483647L)posPulses++;}else if(posPulses>0)posPulses--;}
}
void finishHome(){stopped();homed=true;posPulses=0;scanning=false;scanInitialized=false;servo1Dir=1;event(F("home_reached"));sendStatus();}
void startHome(){
 stopAll();homed=false;posPulses=0;lastHostMs=millis();
 motorState=HOMING;homePulseCount=0;homeStartedMs=millis();resetStepTiming();
 // One shared reset for automatic USB HOME and the on-screen HOME button.
 setPan(0);setServo1(1400);servo1Dir=1;scanInitialized=false;
 lastSonarValid=false;awaitingSonar=false;sonarIndex=0;measuredOrientationReady=false;
 event(F("homing_up"));sendStatus();
}
void startMove(bool down,long steps,bool preHome){
 if(motorState!=IDLE){error(F("motor_busy"));return;}
 if(!armed){error(F("arm_required"));return;}
 if(steps<1||steps>(preHome?50:5000)){error(F("jog_out_of_range"));return;}
 if(!homed && !preHome){error(F("home_required"));return;}
 if(!homed && !down && pressed()){error(F("top_switch_pressed"));return;}
 if(homed){
   if(!down&&pressed()){error(F("already_at_home"));return;}
   if(down&&downLimit>0&&steps>downLimit-posPulses){error(F("down_travel_limit"));return;}
   if(!down&&posPulses-steps<0){error(F("upper_travel_limit"));return;}
 }
 continuousMove=false;motorState=MOVING;movingDown=down;moveRemaining=steps;
 moveStartedPressed=pressed()&&down;seenRelease=false;downReleaseTiming=false;downPressTiming=false;
 movePressedSteps=0;resetStepTiming();lastHostMs=millis();
 event(F("moving"));
}
void startContinuous(bool down){
 if(!homed){error(F("home_required"));return;}
 if(motorState==HOMING){error(F("motor_busy"));return;}
 if(motorState==MOVING&&continuousMove&&movingDown==down){lastMoveLeaseMs=millis();return;}
 if(!down&&(pressed()||posPulses<=0)){stopped();sendStatus();return;}
 stopped();armed=true;continuousMove=true;motorState=MOVING;movingDown=down;
 moveStartedPressed=pressed()&&down;seenRelease=false;downReleaseTiming=false;downPressTiming=false;movePressedSteps=0;
 resetStepTiming();lastMoveLeaseMs=millis();event(F("continuous_move"));sendStatus();
}
void processCommand(char *raw){
 while(*raw==' ')raw++;if(!*raw)return;
 char *arg=strchr(raw,' ');if(arg){*arg++=0;while(*arg==' ')arg++;}
 lastHostMs=millis();
 if(!strcmp(raw,"PING"))return;
 if(!strcmp(raw,"HELLO")||!strcmp(raw,"STATUS")){sendStatus();return;}
 if(!strcmp(raw,"LIMIT")){sendStatus();return;}
 if(!strcmp(raw,"STOP")){stopAll();sendStatus();return;}
 if(!strcmp(raw,"HOME")){startHome();return;}
 if(!strcmp(raw,"MOVE")){
   if(!arg){error(F("move_argument"));return;}
   if(!strcmp(arg,"STOP")){if(motorState!=HOMING)stopped();sendStatus();return;}
   if(!strcmp(arg,"DOWN")){startContinuous(true);return;}
   if(!strcmp(arg,"UP")){startContinuous(false);return;}
   error(F("move_argument"));return;
 }
 if(!strcmp(raw,"ARM")){if(motorState!=IDLE){error(F("motor_busy"));return;}armed=true;event(F("armed"));return;}
 if(!strcmp(raw,"DISARM")){stopAll();event(F("disarmed"));return;}
 if(!strcmp(raw,"SCAN")){
   if(!arg){error(F("scan_argument"));return;}
   if(!strcmp(arg,"START")){if(!homed){error(F("home_required"));return;}if(!servo2.attached())setPan(0);if(!scanInitialized){setServo1(1400);servo1Dir=1;scanInitialized=true;}lastScanMs=millis();scanning=true;event(F("scan_started"));sendStatus();}
   else if(!strcmp(arg,"STOP")){scanning=false;event(F("scan_paused"));sendStatus();}
   else error(F("scan_argument"));return;
 }
 if(!strcmp(raw,"RATE")){
   if(!arg){error(F("rate_argument"));return;}int r=atoi(arg);
   if(r<1||r>30){error(F("rate_1_to_30"));return;}servo1Rate=r;event(F("rate_set"));return;
 }
 if(!strcmp(raw,"PAN")){
   if(motorState==HOMING){error(F("home_in_progress"));return;}
   if(!arg){error(F("pan_argument"));return;}int deg=atoi(arg);
   if(deg<-30||deg>30){error(F("pan_out_of_range"));return;}
   setPan(deg);event(F("pan_set"));return;
 }
 if(!strcmp(raw,"SERVO1")){
   if(motorState==HOMING){error(F("home_in_progress"));return;}
   if(!arg){error(F("pulse_argument"));return;}
   int v=atoi(arg);if(v<500||v>2500){error(F("servo1_out_of_range"));return;}
   scanning=false;scanInitialized=true;setServo1(v);event(F("servo1_manual"));return;
 }
 if(!strcmp(raw,"TRAVEL")){
   if(!homed||motorState!=IDLE){error(F("home_first"));return;}
   if(!arg){error(F("travel_argument"));return;}long n=atol(arg);
   if(n!=0&&(n<posPulses||n<1||n>MAX_DOWN_LIMIT)){error(F("travel_out_of_range"));return;}
   downLimit=n;event(F("travel_set"));sendStatus();return;
 }
 if(!strcmp(raw,"JOG")){
   if(!arg){error(F("jog_argument"));return;}
   if(*arg!='+'&&*arg!='-'){error(F("jog_sign_required"));return;}
   char dir=*arg++;if(!*arg){error(F("jog_argument"));return;}
   for(char*p=arg;*p;p++)if(*p<'0'||*p>'9'){error(F("jog_argument"));return;}
   long steps=atol(arg);startMove(dir=='+',steps,!homed);return;
 }
 error(F("unknown_command"));
}
void serviceUsb(){
 // Nonblocking newline line protocol. '!' is immediate software abort.
 while(Serial.available()){
   char c=Serial.read();if(c=='!'){stopAll();lineLength=0;continue;}
   if(c=='\r'||c=='\n'){
     if(lineLength){lineBuffer[lineLength]=0;processCommand(lineBuffer);lineLength=0;}
   }else if(lineLength<sizeof(lineBuffer)-1)lineBuffer[lineLength++]=c;
   else{lineLength=0;error(F("command_too_long"));}
 }
}
void serviceMotor(){
 if(motorState==IDLE)return;
 if(millis()-lastHostMs>HOST_WATCHDOG_MS){stopAll();error(F("host_watchdog_stop"));return;}
 if(continuousMove&&millis()-lastMoveLeaseMs>600){stopped();event(F("move_key_released"));sendStatus();return;}
 if(motorState==HOMING){
   if(millis()-homeStartedMs>HOME_TIMEOUT_MS){stopped();error(F("home_timeout_or_pulse_cutoff"));return;}
   if(pressed()){
     if(!homeConfirming){homeConfirming=true;homeLowSince=millis();event(F("home_confirming_low"));}
     if(millis()-homeLowSince>=HOME_CONFIRM_MS){finishHome();}
     return; // No STEP pulses while the switch is pressed, including the 2-second confirmation.
   }
   if(homeConfirming){homeConfirming=false;resetStepTiming();event(F("home_low_rejected_resume"));}
   if(homePulseCount>=HOME_MAX_PULSES){stopped();error(F("home_timeout_or_pulse_cutoff"));return;}
 }else if(!movingDown){
   if(homed&&posPulses<=0){stopped();sendStatus();return;}
   if(pressed()){startHome();return;}
 }else{
   if(downLimit>0&&posPulses>=downLimit){stopped();error(F("down_travel_limit"));return;}
   if(!pressed()){
     downPressTiming=false;
     if(!downReleaseTiming){downReleaseTiming=true;downReleaseSince=millis();}
     if(millis()-downReleaseSince>=DOWN_SWITCH_DEBOUNCE_MS)seenRelease=true;
   }else{
     downReleaseTiming=false;
     if(seenRelease||!moveStartedPressed){
       // Pause STEP immediately while confirming D4; never drive into a pressed switch.
       if(!downPressTiming){downPressTiming=true;downPressSince=millis();}
       if(millis()-downPressSince>=DOWN_SWITCH_DEBOUNCE_MS){stopAll();error(F("unexpected_home_switch_during_down"));sendStatus();}
       return;
     }
     if(movePressedSteps>200){stopAll();error(F("home_switch_stuck_low"));sendStatus();return;}
   }
 }
 if(motorState==HOMING){pulseStep(false);homePulseCount++;}
 else{
   pulseStep(movingDown);if(!continuousMove)moveRemaining--;if(movingDown&&moveStartedPressed)movePressedSteps++;
   if(!continuousMove&&moveRemaining==0){stopped();event(F("move_complete"));sendStatus();}
 }
}
void serviceScan(){
 if(!scanning)return;
 if(millis()-lastScanMs<20)return;
 lastScanMs=millis();
 int v=servo1Us+servo1Dir*servo1Rate;
 if(v>=SERVO1_MAX_US){v=SERVO1_MAX_US;servo1Dir=-1;}
 if(v<=SERVO1_MIN_US){v=SERVO1_MIN_US;servo1Dir=1;}
 setServo1(v);
}
void serviceSonar(){
 // No new coordinate samples while the rig returns to its reference position.
 if(motorState==HOMING){
   awaitingSonar=false;sonarIndex=0;
   while(sonar.available())sonar.read();
   return;
 }
 if(awaitingSonar&&millis()-lastSonarMs>200){awaitingSonar=false;sonarIndex=0;}
 // Parse FF HH LL CHECKSUM; 0mm and out-of-range ignored.
 while(sonar.available()){
   uint8_t b=(uint8_t)sonar.read();
   if(!awaitingSonar)continue;
   if(sonarIndex==0){if(b!=0xFF)continue;sonarFrame[0]=b;sonarIndex=1;}
   else{
     sonarFrame[sonarIndex++]=b;
     if(sonarIndex==4){
       sonarIndex=0;uint8_t check=(uint8_t)(sonarFrame[0]+sonarFrame[1]+sonarFrame[2]);
       uint16_t mm=((uint16_t)sonarFrame[1]<<8)|sonarFrame[2];
       if(check==sonarFrame[3]&&mm>=50&&mm<=6000){
         awaitingSonar=false;lastSonarValid=true;sonarMm=mm;sonarMeasuredAt=millis();
         if(measuredOrientationReady){
         Serial.print(F("{\"type\":\"echo\",\"distance_mm\":"));Serial.print(mm);
         Serial.print(F(",\"servo1_us\":"));Serial.print(measuredServo1);
         Serial.print(F(",\"servo2_deg\":"));Serial.print(measuredPan);
         Serial.print(F(",\"servo2_us\":"));Serial.print(panPulse(measuredPan));
         Serial.print(F(",\"scan_phase_deg\":"));Serial.print(measuredPhase,2);
         Serial.print(F(",\"seq\":"));Serial.print(++echoSequence);Serial.println('}');
         }
       }
     }
   }
 }
 if(!awaitingSonar&&millis()-lastSonarMs>=125){
   sonarIndex=0;lastSonarMs=millis();measuredOrientationReady=servo1.attached()&&servo2.attached();measuredServo1=servo1Us;measuredPan=panDeg;measuredPhase=scanPhase();
   awaitingSonar=true;sonar.write((uint8_t)0x55);
 }
}
void setup(){
 pinMode(HOME_PIN,INPUT_PULLUP);pinMode(STEP_PIN,OUTPUT);pinMode(DIR_PIN,OUTPUT);
 digitalWrite(STEP_PIN,LOW);digitalWrite(DIR_PIN,LOW);
 // No servo attach/write at boot: first explicit SCAN/SERVO1/PAN command enables it.
 Serial.begin(BAUD);sonar.begin(115200);sonar.listen();
 lastHostMs=millis();lastScanMs=millis();lastSonarMs=millis();
 event(F("boot_ready"));sendStatus();
}
void loop(){
 serviceUsb();serviceMotor();
 // If Python/USB connection disappears, stop the continuous servo scan as well.
 if(scanning && millis()-lastHostMs>HOST_WATCHDOG_MS){scanning=false;event(F("scan_stopped_host_watchdog"));}
 serviceScan();serviceSonar();
 if(millis()-lastStatusMs>=((motorState==MOVING||(motorState==HOMING&&!homeConfirming))?250UL:100UL)){lastStatusMs=millis();sendStatus();}
}
