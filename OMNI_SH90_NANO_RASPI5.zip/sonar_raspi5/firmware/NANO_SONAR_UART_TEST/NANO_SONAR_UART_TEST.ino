/* Standalone SEN0599 UART diagnostic for classic Arduino Nano ATmega328P.
   Sensor TX (white) -> Nano D3; sensor RX (yellow) <- Nano D2.
   VCC/GND per the sensor's own specification; common GND with Nano.
   Close Python before uploading. Serial Monitor: 115200 baud.
   Does not attach Servo or start HOME/STEP motion. Re-upload controller after test.
*/
#include <Arduino.h>
#include <SoftwareSerial.h>

SoftwareSerial sensor(3, 2); // Nano RX=D3, TX=D2
constexpr unsigned long SENSOR_BAUD = 115200UL;
constexpr unsigned long RECEIVE_WINDOW_MS = 200UL;
constexpr unsigned int RAW_CAPACITY = 64;
uint8_t rawBytes[RAW_CAPACITY];
unsigned int storedBytes = 0;
unsigned long receivedBytes = 0, cycle = 0;

void printHexByte(uint8_t value) {
  const char digits[] = "0123456789ABCDEF";
  Serial.print(digits[value >> 4]);
  Serial.print(digits[value & 15]);
}

void reportCapture() {
  Serial.print(F("\nTEST #")); Serial.print(++cycle);
  Serial.print(F(" | TX=55 | RX_BYTES=")); Serial.println(receivedBytes);
  Serial.print(F("RAW_HEX: "));
  for (unsigned int i = 0; i < storedBytes; i++) {
    printHexByte(rawBytes[i]); Serial.print(' ');
  }
  Serial.println();
  if (receivedBytes > RAW_CAPACITY) Serial.println(F("NOTE=RAW_TRUNCATED_AT_64_BYTES"));
  if (receivedBytes == 0) {
    Serial.println(F("STATE=NO_RX | Khong nhan byte UART nao trong 200 ms."));
    return;
  }

  unsigned int frames = 0, badChecksum = 0;
  bool headerSeen = false;
  for (unsigned int i = 0; i < storedBytes; i++) {
    if (rawBytes[i] != 0xFF) continue;
    headerSeen = true;
    if (i + 3 >= storedBytes) continue;
    uint8_t checksum = (uint8_t)(rawBytes[i] + rawBytes[i+1] + rawBytes[i+2]);
    if (checksum != rawBytes[i+3]) { badChecksum++; continue; }
    frames++;
    unsigned int mm = ((unsigned int)rawBytes[i+1] << 8) | rawBytes[i+2];
    Serial.print(F("FRAME_OK | mm=")); Serial.print(mm);
    Serial.print(F(" | d=")); Serial.print(mm/10.0f, 1); Serial.println(F(" cm"));
    if (mm == 0) Serial.println(F("STATE=ZERO_MM | UART co phan hoi, cam bien tra 0; app khong ve cham tu gia tri nay."));
    else if (mm < 50 || mm > 6000) Serial.println(F("STATE=OUT_OF_RANGE | Ngoai dai 50..6000 mm dang cau hinh trong app."));
    else Serial.println(F("STATE=VALID_DISTANCE"));
    i += 3;
  }
  if (badChecksum) {
    Serial.print(F("CHECKSUM_ERRORS=")); Serial.println(badChecksum);
  }
  if (frames == 0) {
    if (badChecksum) Serial.println(F("STATE=BAD_CHECKSUM | Co byte nhung khung loi; kiem tra UART/nguon/baud/model."));
    else if (headerSeen) Serial.println(F("STATE=INCOMPLETE_FRAME | Co FF nhung chua du khung 4 byte."));
    else Serial.println(F("STATE=NO_FF_HEADER | Co byte nhung khong co header FF."));
  }
}

void setup() {
  // Hold the existing rig's STEP and servo signal pins LOW; no motion commands.
  const uint8_t pins[] = {5, 6, 9, 10};
  for (uint8_t i = 0; i < sizeof(pins)/sizeof(pins[0]); i++) {
    digitalWrite(pins[i], LOW); pinMode(pins[i], OUTPUT);
  }
  Serial.begin(115200);
  sensor.begin(SENSOR_BAUD); sensor.listen();
  delay(600); // Sensor power-on specification <=500 ms.
  Serial.println(F("NANO SONAR UART TEST | D3=RX D2=TX | 115200 baud | CMD=0x55"));
  Serial.println(F("Close Python. This sketch only reads the sensor; it does not HOME or scan."));
}

void loop() {
  storedBytes = 0; receivedBytes = 0;
  // Finish the preceding USB print before receiving the sensor burst.
  Serial.flush();
  sensor.write((uint8_t)0x55);
  unsigned long started = millis();
  while (millis() - started < RECEIVE_WINDOW_MS) {
    while (sensor.available()) {
      int value = sensor.read();
      if (value < 0) break;
      receivedBytes++;
      if (storedBytes < RAW_CAPACITY) rawBytes[storedBytes++] = (uint8_t)value;
    }
  }
  // Print only after collecting the burst, with no Servo timer running.
  reportCapture();
  delay(550);
}
