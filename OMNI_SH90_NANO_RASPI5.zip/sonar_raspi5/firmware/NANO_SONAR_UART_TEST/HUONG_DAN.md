# Test riêng cảm biến UART — Nano RX D3 / TX D2

Log V13 chỉ xác nhận Nano/USB hoạt động và HOME đã xong; nó chưa cho biết cảm biến im lặng hay đang trả 0/checksum lỗi. Test này in byte thô để phân biệt các trường hợp đó. Không tự quay servo hoặc về HOME.

1. Đóng hoàn toàn main.py/DO_CAM_BIEN_WINDOWS.bat và Serial Monitor cũ.
2. Giải nén ZIP, mở NANO_SONAR_UART_TEST/NANO_SONAR_UART_TEST.ino bằng Arduino IDE.
3. Chọn đúng Arduino Nano/ATmega328P, cổng COM và bootloader đang dùng, rồi Upload.
4. Mở Serial Monitor ở 115200 baud. Đầu dò tiếp tục ở trong nước như bạn đang thử. Đưa vật vào đúng hướng mặt đầu dò, trong khoảng đo của model.
5. Sao chép 3–5 nhóm log TEST/RAW_HEX/STATE gửi lại để xác định bước sửa tiếp.

## Dây của SEN0599 theo nhà sản xuất

| Cảm biến | Arduino Nano |
|---|---|
| Trắng TX | D3 (RX của Nano) |
| Vàng RX | D2 (TX của Nano) |
| Đen GND | GND chung |
| Đỏ VCC | Nguồn phù hợp model; SEN0599 hỗ trợ 5–24 V |

Không đưa nguồn motor vào đường tín hiệu. Nếu model khác, xác nhận nhãn chân/thông số của model đó, không suy ra theo màu dây SEN0599.

## Đọc kết quả

| Log | Ý nghĩa |
|---|---|
| RX_BYTES=0 / STATE=NO_RX | Chưa nhận được byte trong cửa sổ 200 ms; chưa xác định do nguồn, dây, cấu hình hay cảm biến |
| RAW_HEX: FF 00 00 FF / ZERO_MM | Có phản hồi UART đúng checksum, nhưng giá trị khoảng cách bằng 0 |
| FRAME_OK / VALID_DISTANCE | Có phép đo hợp lệ; d là khoảng cách cm, quan sát d có đổi khi vật tiến/lùi |
| BAD_CHECKSUM | Có byte nhưng khung không hợp lệ; cần kiểm tra UART/timing/nguồn/baud/model |
| INCOMPLETE_FRAME | Có header nhưng thiếu byte |
| NO_FF_HEADER | Có byte không khớp khung đang chờ |
| OUT_OF_RANGE | Có khung đúng checksum, nhưng giá trị ngoài 50–6000 mm mà app đang chấp nhận |

Ví dụ khung `FF 00 C8 C7` là 200 mm = 20,0 cm. Đây là ví dụ định dạng, không phải phép đo đã lấy từ thiết bị của bạn.

Mã test không dùng thư viện Servo, không chạy vòng STEP và gom đủ dữ liệu rồi mới in USB để giảm yếu tố gây nhiễu thời gian thu. Điều này giúp so sánh với firmware toàn hệ thống; không bảo đảm SoftwareSerial 115200 luôn tin cậy trên mọi Nano. Chưa có thiết bị thật để đo thời gian hoặc xác minh cảm biến.

Sau khi test, đóng Serial Monitor rồi nạp lại RF_Nano_Omni_Controller.ino của V13/V12 để dùng lại giao diện Python. Không mở Python với mã test này: mã test không phải firmware OMNI_NANO, nên Python sẽ không xác minh/kết nối điều khiển nó.

Nguồn đối chiếu: https://wiki.dfrobot.com/sen0599 ; https://wiki.dfrobot.com/sen0599/docs/18113 ; https://wiki.dfrobot.com/sen0599/docs/18114 .
