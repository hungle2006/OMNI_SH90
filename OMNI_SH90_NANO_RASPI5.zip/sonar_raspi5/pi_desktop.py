#!/usr/bin/env python3
"""Install a per-user shortcut; do not change desktop autostart."""
from pathlib import Path
import os
import subprocess

ROOT = Path(__file__).resolve().parent

def desktop_entry(root: Path) -> str:
    path = str(root / 'RUN_RASPI5.sh').replace('%', '%%')
    for character in ('\\', '"', '`', '$'):
        path = path.replace(character, '\\' + character)
    return ('[Desktop Entry]\nType=Application\nName=OMNI Sonar Nano\n'
            'Comment=Sonar USB Nano - khoang cach trong Terminal\n'
            f'Exec=/bin/bash "{path}"\n'
            'Terminal=true\nIcon=applications-science\nCategories=Education;Science;\n')

def main():
    home = Path.home()
    config = Path(os.environ.get('XDG_DATA_HOME', str(home / '.local/share')))
    destinations = [config / 'applications/omni-sonar-nano.desktop']
    try:
        result = subprocess.run(['xdg-user-dir', 'DESKTOP'], capture_output=True, text=True, check=True)
        desktop = Path(result.stdout.strip())
        if desktop.is_absolute() and desktop != home and desktop.is_dir():
            destinations.append(desktop / 'omni-sonar-nano.desktop')
    except (OSError, subprocess.CalledProcessError):
        desktop = home / 'Desktop'
        if desktop.is_dir(): destinations.append(desktop / 'omni-sonar-nano.desktop')
    for path in destinations:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(desktop_entry(ROOT), encoding='utf-8')
        path.chmod(0o755)
        print('Da tao shortcut:', path)
    print('Neu desktop yeu cau, chon Allow Launching/Cho phep khoi chay.')

if __name__ == '__main__':
    main()
