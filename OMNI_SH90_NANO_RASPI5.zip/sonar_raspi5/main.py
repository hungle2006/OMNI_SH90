#!/usr/bin/env python3
"""Double-click entry point. Sets up pyserial on first use, then opens the UI."""
from __future__ import annotations
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parent

def launch() -> int:
    os.chdir(ROOT)
    if sys.version_info < (3, 9):
        raise RuntimeError('Can cai Python 3.9 tro len (tren Pi: sudo apt install python3).')
    from dependency_setup import ensure_dependencies
    python = ensure_dependencies(ROOT)
    if python is not None:
        # Replace this process so Ctrl+C still reaches the actual server.
        os.execv(str(python), [str(python), '-u', str(ROOT / 'main.py'), *sys.argv[1:]])
    from server import main
    return main()

if __name__ == '__main__':
    try:
        raise SystemExit(launch())
    except Exception:
        details = traceback.format_exc()
        (ROOT / 'startup_error.log').write_text(details, encoding='utf-8')
        print(details)
        try:
            import tkinter as tk
            from tkinter import messagebox
            ui = tk.Tk(); ui.withdraw()
            messagebox.showerror('OMNI Sonar', 'Khong khoi dong duoc. Xem startup_error.log trong thu muc da giai nen.\n\n' + details[-900:])
            ui.destroy()
        except Exception:
            if sys.stdin and sys.stdin.isatty(): input('Nhan Enter de dong...')
        raise SystemExit(1)
