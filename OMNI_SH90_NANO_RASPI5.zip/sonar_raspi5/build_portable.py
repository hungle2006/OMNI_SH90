#!/usr/bin/env python3
"""Generate the dependency-free single HTML deliverable from editable web sources."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent
web = ROOT / 'web'
html = (web / 'index.html').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + (web / 'styles.css').read_text(encoding='utf-8') + '\n</style>')
html = html.replace('  <script defer src="core.js"></script>\n', '')
html = html.replace('  <script defer src="renderer.js"></script>\n', '')
html = html.replace('  <script defer src="app.js"></script>\n', '')
html = html.replace('  <script defer src="nano.js"></script>\n', '')
html = html.replace('  <script defer src="calibration.js"></script>\n', '')
# Keep source load order, and execute only after all DOM nodes exist.
scripts = '\n'.join('<script>\n' + (web / name).read_text(encoding='utf-8').replace('</script', '<\\/script') + '\n</script>'
                    for name in ('core.js', 'renderer.js', 'calibration.js', 'nano.js', 'app.js'))
html = html.replace('</body>', scripts + '\n</body>')
(ROOT / 'SONAR_TRAINER.html').write_text(html, encoding='utf-8')
(ROOT / 'index.html').write_text(html, encoding='utf-8')
print('Built SONAR_TRAINER.html and index.html')
