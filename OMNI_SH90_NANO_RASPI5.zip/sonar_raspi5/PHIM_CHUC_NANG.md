# Phím và nút OMNI SH90 Nano V16 PC

Khi CONNECT, các điều khiển thiết bị gửi lệnh xuống Nano. Không tự bắt đầu quét sau HOME.

| Phím/nút | Chức năng |
|---|---|
| Giữ W / S | Nâng / hạ; thả để dừng motor |
| Giữ I / L | Nâng / hạ tương tự W / S |
| Space | Dừng / tiếp tục quét servo D10 |
| HOME trên màn hình | Trục đi lên tìm D4; D10=1400 µs, D9=900 µs; nhận HOME sau LOW liên tục 2 giây |
| −10° / +10° trên màn hình | Đổi D9 từng 10°, giới hạn −30°…+30° |
| DỪNG trên màn hình | Dừng motor và quét, kể cả đang HOME |
| Q / E | Giảm / tăng Range từng 1 cm, từ 7 đến 18 cm; Rxy = Range/2 |
| J / K | Giảm / tăng độ rõ hiển thị |
| P | Đổi TX hiển thị; tắt TX cũng dừng quét; bật TX không tự quay |
| F3 | POWER; tắt gửi DỪNG xuống Nano |
| Các phím mũi tên | Di chuyển con trỏ đo |
| Enter / Backspace | Đặt / xóa dấu đo |
| F / M | Toàn màn hình / ẩn hiện menu |
| F2 / H | Bảng nút / hướng dẫn |
| N | Bow Up / North Up |
| Z / X | Zoom / Off Centre |
| C | Chụp ảnh màn hình sonar |
| F6 / F7 | Xem ảnh / chụp hoặc ghi chuỗi ảnh |
| F4 | Tắt âm và xác nhận cảnh báo |
| Y / 0 / G | Symbol tròn / tàu / ngư cụ |
| V / O | Menu View / Object |
| 1…4 | Chọn tab Horizontal / Display / Setup / Objects |
| 5…8 | Chọn bốn chế độ trình bày gốc |
| R | Mở hộp thoại khởi động lại phiên; xác nhận sẽ dừng thiết bị |
| T | Mở trình sửa kịch bản demo; không thêm phản hồi giả vào lớp đo Nano |

A/D đã bỏ; U/B/Esc/Home không gửi lệnh thiết bị. HOME, DỪNG và chỉnh góc dùng nút sẵn trên màn hình. D9 không tự lia. Giữ Shift khi chỉnh thông số giao diện để đổi nhanh; bước D9 vẫn là 10°.

Mất focus/thả phím ngừng nâng hạ. Mất liên lạc USB có watchdog dừng motor và quét. Các tham số mô phỏng như tần số/beam không lập trình lại cảm biến thật. Xem README.md để biết chân nối, phép chiếu và cách khởi động.

Mở DO_CAM_BIEN_WINDOWS.bat trên máy tính để giữ Terminal và xem SONAR d=... cm tự động sau HOME. Không cần thêm phím đọc khoảng cách; Space chỉ điều khiển quét.
