// Host simulation of actual .ino logic, not an AVR/library timing test.
#include <cassert>
#include <cmath>
#include <iostream>
#include "../firmware/RF_Nano_Omni_Controller/RF_Nano_Omni_Controller.ino"
void command(const char* v){char b[64];strcpy(b,v);processCommand(b);}
void tick(){mockUs+=100;serviceMotor();}
void confirmHome(){serviceMotor();assert(homeConfirming&&!homed);mockUs+=2000000;command("PING");serviceMotor();assert(homed&&motorState==IDLE);}
int main(){
 static_assert(SONAR_RX==3&&SONAR_TX==2,"White TX must connect to D3; yellow RX to D2");
 assert(panPulse(-30)==500&&panPulse(0)==900&&panPulse(30)==1200);assert(panPulse(-10)==767&&panPulse(10)==1000);
 setup();assert(!servo1.attached()&&!servo2.attached());assert(servo1.writes==0&&servo2.writes==0);assert(downLimit==0);
 // Sensor distance is usable before servo commands; its XY orientation is unknown.
 mockUs+=130000;serviceSonar();assert(awaitingSonar&&!measuredOrientationReady);
 Serial.output.clear();sonar.incoming={0xff,0x03,0xe8,0xea};serviceSonar();
 assert(sonarMm==1000&&lastSonarValid);assert(Serial.output.find("\"type\":\"echo\"")==std::string::npos);
 switchLevel=LOW;command("HOME");assert(!homed);confirmHome();assert(homed&&!scanning&&posPulses==0);assert(servo1.attached()&&servo2.attached());
 assert(servo1Us==1400&&panDeg==0&&servo1.value==1400&&servo2.value==900);
 int homeServoWrites=servo1.writes;
 for(int i=0;i<10;i++){mockUs+=25000;serviceScan();}assert(servo1.writes==homeServoWrites);
 command("SCAN START");assert(servo1.attached()&&servo1Us==1400&&scanning);
 mockUs+=25000;serviceScan();assert(servo1Us>1400);command("SCAN STOP");int pausedPulse=servo1Us;
 mockUs+=500000;serviceScan();assert(servo1Us==pausedPulse);
 command("SCAN START");assert(servo1Us==pausedPulse);switchLevel=HIGH;
 command("MOVE DOWN");for(int i=0;i<16000;i++){if(i%20==0)command("MOVE DOWN");tick();}assert(posPulses>12000);assert(continuousMove);
 command("MOVE STOP");int pos=posPulses;for(int i=0;i<100;i++)tick();assert(posPulses==pos);assert(scanning);
 command("MOVE DOWN");for(int i=0;i<700;i++)tick();assert(motorState==IDLE); // movement lease expires
 int beforeUp=posPulses;command("MOVE UP");for(int i=0;i<50;i++){command("MOVE UP");tick();}assert(posPulses<beforeUp);
 switchLevel=LOW;tick();assert(motorState==HOMING);confirmHome();assert(motorState==IDLE&&posPulses==0);switchLevel=HIGH;
 command("MOVE DOWN");command("STOP");assert(motorState==IDLE&&!scanning);
 setServo1(500);servo1Dir=1;assert(std::abs(scanPhase()-198)<.01);setServo1(2500);servo1Dir=-1;assert(std::abs(scanPhase()-198)<.01);setServo1(1400);servo1Dir=-1;assert(scanPhase()==0);
 command("SCAN START");for(int i=0;i<500;i++){mockUs+=21000;serviceScan();assert(servo1Us>=500&&servo1Us<=2500);}command("SCAN STOP");int pulse=servo1Us;mockUs+=21000;serviceScan();assert(servo1Us==pulse);
 command("MOVE DOWN");lastHostMs=millis()-3000;tick();assert(motorState==IDLE);
 sendStatus();assert(Serial.output.find("\"protocol\":3")!=std::string::npos);
 // Keep acquisition metadata until its response; no overlapping requests.
 setServo1(1000);servo1Dir=1;mockUs+=300000;serviceSonar();
 int requests=sonar.requests;assert(awaitingSonar);float acquisitionPhase=measuredPhase;
 setServo1(2300);mockUs+=130000;serviceSonar();assert(sonar.requests==requests);
 Serial.output.clear();sonar.incoming={0xff,0x03,0xe8,0xea}; // 1000 mm checksum
 serviceSonar();assert(sonarMm==1000);assert(std::abs(acquisitionPhase-288)<.01);assert(Serial.output.find("\"scan_phase_deg\":288")!=std::string::npos);
 // Timeout releases an outstanding request so failed sensors do not stall forever.
 mockUs+=210000;serviceSonar();assert(awaitingSonar);
 switchLevel=HIGH;command("HOME");assert(motorState==HOMING);
 command("MOVE STOP");assert(motorState==HOMING);
 command("STOP");assert(motorState==IDLE);
 // Switch bounce while leaving HOME must not cause a false re-press fault.
 switchLevel=LOW;command("HOME");confirmHome();command("MOVE DOWN");
 for(int i=0;i<5;i++)tick();switchLevel=HIGH;tick();switchLevel=LOW;
 for(int i=0;i<10;i++)tick();assert(motorState==MOVING);
 switchLevel=HIGH;for(int i=0;i<30;i++)tick();assert(seenRelease);
 // A short LOW spike pauses pulses but is not latched as a fault.
 int beforeSpike=posPulses;switchLevel=LOW;tick();assert(posPulses==beforeSpike);assert(motorState==MOVING);
 switchLevel=HIGH;tick();assert(motorState==MOVING);
 // Stable LOW after release still faults, with zero extra STEP pulses during confirmation.
 beforeSpike=posPulses;switchLevel=LOW;for(int i=0;i<240;i++)tick();
 assert(motorState==IDLE);assert(posPulses==beforeSpike);
 assert(Serial.output.find("unexpected_home_switch_during_down")!=std::string::npos);
 // Reject a one-second LOW, resume HOME, then require a fresh continuous two seconds.
 switchLevel=HIGH;command("HOME");tick();switchLevel=LOW;tick();
 unsigned long held=homePulseCount;mockUs+=1000000;command("PING");serviceMotor();
 assert(!homed&&homePulseCount==held);
 switchLevel=HIGH;tick();assert(!homeConfirming&&!homed);tick();assert(homePulseCount>held);
 switchLevel=LOW;tick();held=homePulseCount;mockUs=(homeLowSince+1999)*1000;command("PING");serviceMotor();assert(!homed&&homePulseCount==held);
 mockUs=(homeLowSince+2000)*1000;serviceMotor();assert(homed&&posPulses==0&&!scanning);
 // Status must fit the bridge's complete-line limit, including large pulse counts.
 posPulses=2147483647;downLimit=12000;servo1Us=2500;panDeg=-30;
 sendStatus();size_t at=Serial.output.rfind("{\"type\":\"status\"");assert(at!=std::string::npos);assert(Serial.output.size()-at<=380);
 // Direct pulseStep is exactly HIGH 500us / LOW 500us in the host timing model.
 stepEdges.clear();for(int i=0;i<200;i++)pulseStep(false);
 assert(stepEdges.size()==400);
 for(size_t i=1;i<stepEdges.size();i++)assert(stepEdges[i].first-stepEdges[i-1].first==500UL);
 command("STOP");assert(mockPins[5]==LOW);
 switchLevel=HIGH;command("HOME");stepEdges.clear();unsigned long count=homePulseCount;serviceMotor();assert(homePulseCount==count+1);assert(mockPins[5]==LOW);
 command("STOP");
 // Repeated HOME must restore both references even after scanning and pan changes.
 homed=true;setServo1(2200);setPan(-30);scanning=true;switchLevel=HIGH;lastSonarValid=true;awaitingSonar=true;
 command("HOME");assert(motorState==HOMING&&!homed&&!scanning);
 assert(servo1Us==1400&&panDeg==0&&servo2.value==900&&!lastSonarValid&&!awaitingSonar);
 command("PAN 20");command("SERVO1 1800");command("SCAN START");
 assert(servo1Us==1400&&panDeg==0&&!scanning);
 unsigned long requestsBeforeHome=sonar.requests;sonar.incoming={0xff,0x03,0xe8,0xea};
 serviceSonar();assert(sonar.requests==requestsBeforeHome&&sonar.incoming.empty());
 tick();assert(motorState==HOMING&&homePulseCount>0); // HIGH must keep searching upward.
 switchLevel=LOW;confirmHome();assert(servo1Us==1400&&panDeg==0&&!scanning);
 command("HOME");assert(!homed&&motorState==HOMING);confirmHome();assert(!scanning);
 // A deliberate post-HOME angle is preserved when scanning starts.
 command("PAN 10");command("SCAN START");assert(panDeg==10&&servo1Us==1400);command("STOP");
 // The main loop also stops an idle stepper's servo scan if the host disappears.
 homed=true;command("SCAN START");assert(scanning&&motorState==IDLE);
 lastHostMs=millis()-3000;loop();assert(!scanning&&motorState==IDLE);
 command("SCAN START");command("DISARM");assert(!scanning&&!armed);
 // SERVO1 before SCAN must still initialise D9, never leave its orientation unknown.
 servo2.enabled=false;command("SERVO1 1700");command("SCAN START");assert(servo2.attached()&&servo1Us==1700);
 command("STOP");
 std::cout<<"Firmware logic: unlimited downward travel, release, lease, HOME, scan phase, watchdog OK\n";
}
