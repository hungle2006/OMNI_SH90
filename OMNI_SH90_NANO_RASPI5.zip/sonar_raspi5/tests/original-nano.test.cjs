'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require(process.env.SONAR_TEST_NODE_MODULES?path.join(process.env.SONAR_TEST_NODE_MODULES,'jsdom'):'jsdom');
const {createCanvas}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'@napi-rs/canvas'):'@napi-rs/canvas');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
test('original SH90 UI and Nano controls share original buttons without replacing layout',{timeout:15000},async()=>{
const dom=new JSDOM(fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8'),{url:'http://127.0.0.1:8765',runScripts:'outside-only',pretendToBeVisual:true});const w=dom.window,d=w.document;let connected=false,raf,panAck=true,stopAck=true,failScanStart=false,session='first-server',homeCycle=0,hasSample=true;const queries=[];const sample={id:1,time:Date.now()/1000,distance_mm:165,servo1_us:1400,servo2_deg:30,scan_phase_deg:0};const commands=[],errors=[],canvases=new WeakMap();
w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.addEventListener('error',e=>errors.push(e.message));w.ResizeObserver=class{observe(){}};w.requestAnimationFrame=cb=>{raf=cb;return 1;};w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};
w.HTMLElement.prototype.getBoundingClientRect=function(){return {x:0,y:0,width:this.id==='sonar'?850:100,height:this.id==='sonar'?800:30};};
w.HTMLCanvasElement.prototype.getContext=function(){if(!canvases.has(this))canvases.set(this,createCanvas(this.width||640,this.height||640));const c=canvases.get(this);if(c.width!==this.width)c.width=this.width;if(c.height!==this.height)c.height=this.height;return c.getContext('2d');};
// napi-rs expects native canvases in drawImage/createPattern.
const rawGet=w.HTMLCanvasElement.prototype.getContext;w.HTMLCanvasElement.prototype.getContext=function(...a){const ctx=rawGet.apply(this,a);return new Proxy(ctx,{get(t,k){if(k==='drawImage'||k==='createPattern')return (source,...rest)=>t[k](canvases.get(source)||source,...rest);const v=t[k];return typeof v==='function'?v.bind(t):v;},set(t,k,v){t[k]=v;return true;}});};
const hw={homed:true,pos:3000,motor:'idle',scanning:true,servo1_us:1500,servo2_deg:0,scan_phase_deg:90,distance_mm:165,sonar_ok:true};
w.fetch=async(url,options)=>{let data={};if(url.startsWith('/api/state')){queries.push(url);data={session_id:session,home_cycle:homeCycle,latest_echo:connected&&hasSample?sample:null,connected,port_open:connected,auto_connect:true,port:'COM5',status:connected?{...hw}:{},echoes:connected&&hasSample&&Number(new URL(url,'http://localhost').searchParams.get('since'))<sample.id?[sample]:[],last_id:sample.id,events:[]};}else if(url==='/api/ports')data={ports:[]};else if(url==='/api/command'){const c=JSON.parse(options.body);commands.push(c.command);if(c.command==='HOME'){homeCycle++;hasSample=false;hw.servo1_us=1400;hw.servo2_deg=0;}if(c.command==='HOME'||c.command==='STOP')hw.scanning=false;if(c.command==='SCAN STOP'&&stopAck)hw.scanning=false;if(c.command==='SCAN START'){if(failScanStart){failScanStart=false;return {ok:false,json:async()=>({error:'home_required'})};}hw.scanning=true;}if(c.command.startsWith('PAN ')&&panAck)hw.servo2_deg=Number(c.command.slice(4));data={ok:true};}return {ok:true,json:async()=>data};};
const key=(type,code,target=d.getElementById('sonar'))=>target.dispatchEvent(new w.KeyboardEvent(type,{code,bubbles:true,cancelable:true}));
try{
for(const n of ['core.js','renderer.js','calibration.js','nano.js','app.js']){if(n==='app.js')w.localStorage.setItem('sh90-classic-v3',JSON.stringify({version:w.SonarCore.VERSION,scenario:{id:'reference'},training:{},state:{range:50,rangeV:50,zoom:true,zoomRange:13,offCentre:true}}));w.eval(fs.readFileSync(path.join(__dirname,'../web',n),'utf8'));}
await wait(100);assert.equal(d.querySelector('.device-title').textContent,'Simrad SH90');assert.equal(d.querySelectorAll('.parameter-row').length,14);assert.equal(d.querySelectorAll('#hwPanel,#liveSonar,.card,.scope-panel').length,0);const aspect=d.getElementById('instrument').dataset.aspect;
key('keydown','KeyS');w.dispatchEvent(new w.Event('pagehide'));let demo=JSON.parse(w.localStorage.getItem('sh90-classic-v3'));assert.equal(demo.state.tilt,-3);assert.equal(commands.length,0);assert.equal(d.getElementById('nanoGeometry').hidden,false);assert.ok(d.getElementById('nanoGeometry').textContent.includes('Chưa kết nối Nano'));
connected=true;await wait(200);assert.equal(d.getElementById('nanoBadge').textContent,'● CONNECT');assert.equal(d.getElementById('instrument').dataset.aspect,aspect);assert.equal(w.NanoUI.view().range,.18);assert.equal(w.NanoUI.view().zoom,false);assert.equal(w.NanoUI.view().offCentre,false);const projection=w.NanoLink.projection();assert.ok(Math.abs(projection.x)<1e-9);assert.ok(Math.abs(projection.y-.0825)<1e-9);assert.ok(d.getElementById('nanoGeometry').textContent.includes('X=0.0 Y=8.2'));assert.ok(d.getElementById('nanoDistance').textContent.includes('d=16.5 cm'));assert.equal(d.body.dataset.nanoLive,'true');assert.equal(w.NanoLink.echoes.length,1);assert.ok(!commands.includes('SCAN START'));hw.scanning=false;await wait(170);assert.ok(!commands.includes('SCAN START'));d.querySelector('.scope-tools [data-action=toggleSweep]').click();await wait(170);assert.ok(commands.includes('SCAN START'));
// Q/E cover every one-centimetre level and clamp; CONNECT polling never inserts metre levels.
key('keydown','KeyQ');assert.equal(w.NanoUI.view().range,.17);for(let i=0;i<30;i++)key('keydown','KeyQ');assert.equal(w.NanoUI.view().range,.07);for(let i=0;i<30;i++)key('keydown','KeyE');assert.equal(w.NanoUI.view().range,.18);await wait(150);assert.deepEqual(Array.from(w.SonarCore.PARAMS.range.values,v=>Math.round(v*100)),[7,8,9,10,11,12,13,14,15,16,17,18]);assert.ok(d.querySelector('[data-field=range]').textContent.includes('18 cm'));
key('keydown','KeyS');await wait(260);key('keyup','KeyS');await wait(150);assert.ok(commands.includes('MOVE DOWN'));assert.equal(commands.at(-1),'MOVE STOP');
key('keydown','KeyW');await wait(150);key('keyup','KeyW');await wait(150);assert.ok(commands.includes('MOVE UP'));
const keyCount=commands.length;key('keydown','KeyA');key('keydown','KeyD');await wait(150);assert.equal(commands.length,keyCount);
d.getElementById('nanoTiltPlus').click();await wait(150);assert.equal(commands.at(-1),'PAN 10');
d.getElementById('nanoTiltPlus').click();d.getElementById('nanoTiltPlus').click();d.getElementById('nanoTiltPlus').click();await wait(150);assert.equal(commands.at(-1),'PAN 30');
for(let i=0;i<7;i++)d.getElementById('nanoTiltMinus').click();await wait(150);assert.equal(commands.at(-1),'PAN -30');
assert.equal(d.getElementById('nanoScopePan'),null);
// Slow telemetry must not reset the intended tilt between two presses.
hw.servo2_deg=0;await wait(170);panAck=false;d.getElementById('nanoTiltPlus').click();await wait(520);d.getElementById('nanoTiltPlus').click();await wait(170);assert.equal(commands.at(-1),'PAN 20');panAck=true;hw.servo2_deg=20;await wait(170);

const probe={ctx:createCanvas(800,800).getContext('2d'),radius:300,cx:400,cy:400,point:()=>({x:420,y:420})};w.NanoLink.draw(probe,w.NanoUI.view());const frozen=w.NanoLink.phase;stopAck=false;key('keydown','Space',d.getElementById('nanoBadge'));await wait(170);assert.ok(commands.includes('SCAN STOP'));hw.scan_phase_deg=170;hw.servo1_us=2300;await wait(150);for(let i=0;i<20;i++)w.NanoLink.draw(probe,w.NanoUI.view());assert.equal(w.NanoLink.phase,frozen);
// After STOP is confirmed, use the final hardware-reported position exactly once.
stopAck=true;hw.scanning=false;await wait(170);w.NanoLink.draw(probe,w.NanoUI.view());assert.equal(w.NanoLink.phase,2300);key('keydown','Space');await wait(170);assert.equal(commands.at(-1),'SCAN START');
key('keydown','KeyL');await wait(140);w.dispatchEvent(new w.Event('blur'));await wait(100);assert.equal(commands.at(-1),'MOVE STOP');
const beforeRemoved=commands.length;
for(const code of ['KeyU','KeyB','Escape','Home'])key('keydown',code);
await wait(120);assert.equal(commands.length,beforeRemoved);
// Mark labels use horizontal metres before HOME recentres the cursor.
key('keydown','Enter');assert.ok(d.getElementById('marksList').textContent.includes('3.5 cm'));
const homes=commands.filter(c=>c==='HOME').length;d.getElementById('nanoScopeHome').click();await wait(100);assert.equal(commands.filter(c=>c==='HOME').length,homes+1);await wait(100);assert.equal(w.NanoLink.phase,1400);assert.equal(w.NanoLink.bearing(),0);assert.equal(w.NanoLink.echoes.length,0);w.dispatchEvent(new w.Event('pagehide'));assert.equal(JSON.parse(w.localStorage.getItem('sh90-classic-v3')).cursor.range,0);
d.getElementById('nanoScopeScan').click();await wait(150);assert.equal(commands.at(-1),'SCAN START');
d.getElementById('nanoScopeScan').click();await wait(150);assert.equal(commands.at(-1),'SCAN STOP');
d.getElementById('nanoScopeStop').click();await wait(150);assert.equal(commands.at(-1),'STOP');assert.equal(w.NanoLink.autoPan,false);
// A rejected START must not latch the next Space press into an unwanted STOP.
hw.scanning=false;await wait(170);failScanStart=true;key('keydown','Space');await wait(170);assert.equal(commands.at(-1),'SCAN START');key('keydown','Space');await wait(170);assert.equal(commands.at(-1),'SCAN START');
// A Python restart resets the echo cursor, even when the old sequence was large.
w.NanoLink.lastId=9999;session='restarted-server';hasSample=true;sample.time=Date.now()/1000;await wait(350);assert.ok(queries.slice(-3).some(q=>q.endsWith('since=0')));assert.equal(w.NanoLink.echoes.length,1);assert.equal(w.NanoLink.echoes[0].id,1);
// A point at O has no unique bearing; marking it must work at every cursor angle.
const centreEcho={...sample,servo2_deg:0,time:Date.now()/1000};w.NanoLink.echoes=[centreEcho];assert.ok(w.NanoLink.findEcho({bearing:123,range:0},w.NanoUI.view()));

// No stale projection is presented as a fresh measurement.
sample.time=Date.now()/1000-2;await wait(170);assert.equal(w.NanoLink.projection(),null);
// Renderer invokes live adapter, with no fake contacts drawn in live mode.
const R=w.SonarRenderer,renderer=new R(d.getElementById('sonar'));let madeHeat=false;renderer.makeHeat=()=>{madeHeat=true;};renderer.draw(w.NanoUI.view(),w.SonarCore.getScenario('reference'),1,{bearing:0,range:1},[],{});assert.equal(madeHeat,false);
const labels=[],recordingCtx=new Proxy({},{get:(target,key)=>key==='fillText'?(text)=>labels.push(String(text)):()=>{},set:(target,key,value)=>{target[key]=value;return true;}});renderer.drawHUD(recordingCtx,w.NanoUI.view(),{bearing:0,range:.10});renderer.drawGrid(recordingCtx,w.NanoUI.view(),{grid:'#fff'});assert.ok(labels.some(t=>t.includes('Rxy:  9 cm')));assert.ok(labels.includes('5.0 cm'));assert.ok(labels.includes('1.8'));assert.ok(!labels.some(t=>/\b[0-9.]+ m\b/.test(t)));
connected=false;await wait(170);assert.equal(w.NanoLink.liveMode,true);assert.equal(w.NanoLink.connected,false);assert.equal(w.NanoLink.echoes.length,0);assert.equal(d.getElementById('nanoGeometry').hidden,false);assert.ok(d.getElementById('nanoGeometry').textContent.includes('Chưa kết nối Nano'));assert.deepEqual(errors,[]);
}finally{dom.window.close();}
});
