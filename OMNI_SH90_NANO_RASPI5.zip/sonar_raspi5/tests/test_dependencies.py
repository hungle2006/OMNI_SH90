import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import dependency_setup as setup
import main as launcher

class DependencySetupTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for name in ('server.py', 'hardware_bridge.py', 'requirements.txt', 'web/index.html'):
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('')
        self.python = self.root / '.venv' / ('Scripts/python.exe' if setup.os.name == 'nt' else 'bin/python')

    def touch_python(self):
        self.python.parent.mkdir(parents=True, exist_ok=True)
        self.python.touch()

    def test_ready_system_needs_no_install_or_network(self):
        with patch.object(setup, '_probe', return_value=True), patch.object(setup, '_run_install') as install:
            self.assertIsNone(setup.ensure_dependencies(self.root))
            install.assert_not_called()

    def test_reuse_existing_venv_offline(self):
        self.touch_python()
        with patch.object(setup, '_probe', return_value=True), patch.object(setup, '_run_install') as install:
            self.assertEqual(setup.ensure_dependencies(self.root), self.python)
            install.assert_not_called()

    def test_missing_package_installs_only_into_project_venv(self):
        with patch.object(setup, '_probe', side_effect=[False, False, True, True]), \
             patch.object(setup.venv, 'EnvBuilder') as builder, \
             patch.object(setup.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0)) as run:
            self.assertEqual(setup.ensure_dependencies(self.root), self.python)
            builder.return_value.create.assert_called_once_with(self.root / '.venv')
            args = run.call_args.args[0]
            self.assertEqual(args[:4], [str(self.python), '-m', 'pip', 'install'])
            self.assertEqual(args[-2:], ['-r', str(self.root / 'requirements.txt')])
            self.assertNotIn('--break-system-packages', args)

    def test_in_project_environment_does_not_relaunch(self):
        self.touch_python()
        with patch.object(setup.sys, 'prefix', str(self.root / '.venv')), patch.object(setup, '_probe', return_value=True):
            self.assertIsNone(setup.ensure_dependencies(self.root))

    def test_failed_pip_reports_error_without_repeating_install(self):
        self.touch_python()
        with patch.object(setup, '_probe', side_effect=[False, True, True]), \
             patch.object(setup.subprocess, 'run', side_effect=subprocess.CalledProcessError(1, 'pip')) as run:
            with self.assertRaisesRegex(RuntimeError, 'Internet'):
                setup.ensure_dependencies(self.root)
            self.assertEqual(run.call_count, 1)

    def test_missing_application_source_is_not_treated_as_pip_package(self):
        (self.root / 'server.py').unlink()
        with patch.object(setup, '_run_install') as install:
            with self.assertRaisesRegex(RuntimeError, 'server.py'):
                setup.ensure_dependencies(self.root)
            install.assert_not_called()

    def test_post_install_failure_stops_instead_of_recursing(self):
        self.touch_python()
        with patch.object(setup, '_probe', side_effect=[False, True, True, False]), patch.object(setup, '_run_install') as install:
            with self.assertRaisesRegex(RuntimeError, 'API'):
                setup.ensure_dependencies(self.root)
            self.assertEqual(install.call_count, 1)

    def test_missing_venv_support_reports_one_time_apt_command(self):
        with patch.object(setup, '_probe', return_value=False), patch.object(setup.venv, 'EnvBuilder') as builder:
            builder.return_value.create.side_effect = subprocess.CalledProcessError(1, 'ensurepip')
            with self.assertRaisesRegex(RuntimeError, 'python3-venv python3-pip'):
                setup.ensure_dependencies(self.root)

class MainEntrypointTest(unittest.TestCase):
    def test_main_starts_server_when_dependencies_ready(self):
        with patch.object(launcher.os, 'chdir'), patch.object(setup, 'ensure_dependencies', return_value=None), patch('server.main', return_value=0) as server_main:
            self.assertEqual(launcher.launch(), 0)
            server_main.assert_called_once()

    def test_main_reexec_preserves_arguments_after_install(self):
        python = Path('/project/.venv/bin/python')
        with patch.object(launcher.os, 'chdir'), patch.object(setup, 'ensure_dependencies', return_value=python), \
             patch.object(launcher.sys, 'argv', ['main.py', '--kiosk', '--port', '8766']), \
             patch.object(launcher.os, 'execv', side_effect=RuntimeError('exec-sentinel')) as execute:
            with self.assertRaisesRegex(RuntimeError, 'exec-sentinel'):
                launcher.launch()
            self.assertEqual(execute.call_args.args[1][-3:], ['--kiosk', '--port', '8766'])
            self.assertEqual(execute.call_args.args[0], str(python))
