const test=require('node:test'),assert=require('node:assert/strict'),G=require('../web/calibration.js');
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
test('D9 reference pulses and 10 degree steps',()=>{assert.equal(G.tiltPulse(-30),500);assert.equal(G.tiltPulse(0),900);assert.equal(G.tiltPulse(30),1200);assert.equal(G.tiltPulse(10),1000);assert.equal(G.tiltPulse(-10),767);});
test('centre, axis signs, D10 full revolution and circle diameter',()=>{let p=G.project(2,1400,0);near(p.x,0);near(p.y,0);p=G.project(2,1400,30);near(p.x,0);near(p.y,1);near(p.diameter,2);p=G.project(2,1400,-30);near(p.y,-1);p=G.project(2,1900,30);near(p.x,-1);near(p.y,0);p=G.project(2,900,30);near(p.x,1);p=G.project(1,1400,10);near(p.diameter,.34729635533386066);near(G.azimuth(2500)-G.azimuth(500),360);near(G.project(1,500,30).x,G.project(1,2500,30).x);});

const C=require('../web/core.js');
test('cm range 7..18 and unchanged 16.5cm sample projection at 30 degrees',()=>{
 assert.deepEqual(C.PARAMS.range.values.map(v=>Math.round(v*100)),[7,8,9,10,11,12,13,14,15,16,17,18]);assert.equal(C.PARAMS.range.unit,'cm');assert.equal(C.DEFAULTS.range,.18);
 const p=G.project(.165,1400,30);near(p.radial,.0825);near(p.diameter,.165);near(p.radial*2/C.DEFAULTS.range,11/12);
});
