import unittest
from hardware_bridge import check_command, NanoBridge

class TestHardwareCommandValidation(unittest.TestCase):
    def test_valid(self):
        for cmd in ("home", "scan start", "scan stop", "jog +500", "JOG -5000", "PAN -30", "PAN +30".replace('+', ''),
                    "TRAVEL 12000", "SERVO1 500", "SERVO1 2500", "RATE 30", "STOP"):
            self.assertEqual(check_command(cmd), cmd.upper())
    def test_invalid(self):
        for cmd in ("", "JOG +0", "JOG +5001", "JOG 500+", "PAN 31", "PAN -31", "TRAVEL 12001",
                    "SERVO1 2501", "SERVO1 499", "RATE 0", "HOME;PAN 30", "RESET", "COMMAND X"):
            with self.assertRaises(ValueError, msg=cmd):check_command(cmd)
    def test_echo_quality_filter(self):
        bridge=NanoBridge(); bridge._firmware_seen=True
        bridge._on_line(b'{"type":"echo","distance_mm":5,"servo1_us":1500,"servo2_deg":0}\n')
        self.assertEqual(bridge.snapshot()['echoes'],[])
        bridge._on_line(b'{"type":"echo","distance_mm":500,"servo1_us":1500,"servo2_deg":-30}\n')
        self.assertEqual(bridge.snapshot()['echoes'][0]['distance_mm'],500)
        bridge._on_line(b'{"type":"status","device":"OMNI_NANO","protocol":3,"homed":true,"limit_pressed":false,"servo1_us":1500,"servo2_deg":0}\n')
        self.assertTrue(bridge._firmware_seen)

class TestBridgeHandshake(unittest.TestCase):
    def test_command_denied_without_verified_firmware(self):
        bridge=NanoBridge()
        with self.assertRaises(RuntimeError):bridge.command('HOME')
        self.assertFalse(bridge.snapshot()['connected'])
        self.assertFalse(bridge.snapshot()['port_open'])


class TestContinuousControl(unittest.TestCase):
    def ready(self):
        from unittest.mock import Mock
        b=NanoBridge(); b._serial=Mock(); b._firmware_seen=True
        return b

    def test_new_commands_and_unlimited_setting(self):
        for command in ('MOVE UP','MOVE DOWN','MOVE STOP','TRAVEL 0'):
            self.assertEqual(check_command(command), command)
        for command in ('MOVE LEFT','MOVE DOWN\nHOME'):
            with self.assertRaises(ValueError): check_command(command)

    def test_stop_cancels_pending_home(self):
        b=self.ready(); b._auto_home_pending=True
        b.command('STOP'); self.assertFalse(b._auto_home_pending)
        b._serial.write.assert_called_with(b'STOP\n')

    def test_stale_move_cannot_restart_after_stop(self):
        b=self.ready(); b.command('MOVE DOWN','tab1',1); b.command('MOVE STOP','tab1',3)
        b.command('MOVE DOWN','tab1',2)
        self.assertEqual(b._serial.write.call_count,2)
        self.assertEqual(b._client_motion_until,0)

    def test_legacy_firmware_does_not_trigger_home(self):
        b=NanoBridge()
        b._on_line(b'{"type":"status","homed":true,"limit_pressed":false,"servo1_us":1500,"servo2_deg":0}')
        self.assertFalse(b._firmware_seen)
        with self.assertRaises(RuntimeError): b.command('HOME')

    def test_reader_expires_browser_lease_while_usb_heartbeat_continues(self):
        import time
        b=self.ready(); b._generation=1; b._last_ping=time.monotonic(); b._client_motion_until=time.monotonic()-.1
        def read(*args): b._stop.set(); return b''
        b._serial.readline.side_effect=read
        dev=b._serial; b._reader(1)
        self.assertIn(b'MOVE STOP\n',[c.args[0] for c in dev.write.call_args_list])

class TestAutomaticUSB(unittest.TestCase):
    def test_auto_connection_home_and_manual_disconnect(self):
        import json,time,types
        from unittest.mock import patch
        devices=[]
        class Device:
            def __init__(self,*a,**kw): self.sent=[]; self.closed=False; devices.append(self)
            def write(self,v): self.sent.append(v)
            def close(self): self.closed=True
            def readline(self,*args):
                time.sleep(.01)
                if self.closed: raise OSError('USB unplugged')
                return json.dumps(dict(type='status',device='OMNI_NANO',protocol=3,homed=False,limit_pressed=False,servo1_us=1500,servo2_deg=0)).encode()+b'\n'
        with patch('hardware_bridge.serial',types.SimpleNamespace(Serial=Device,SerialException=OSError)):
            b=NanoBridge()
            with patch.object(b,'ports',return_value=[dict(device='COM5',description='USB Serial CH340',usb=True)]):
                try:
                    b.start_auto()
                    deadline=time.monotonic()+2
                    while not b._firmware_seen and time.monotonic()<deadline: time.sleep(.02)
                    self.assertTrue(b.snapshot()['connected'])
                    b._opened_at=time.monotonic()-3
                    time.sleep(.1)
                    self.assertEqual(devices[0].sent.count(b'HOME\n'),1)
                    time.sleep(.1)
                    self.assertEqual(devices[0].sent.count(b'HOME\n'),1)
                    devices[0].closed=True
                    deadline=time.monotonic()+4
                    while (len(devices)<2 or not b._firmware_seen) and time.monotonic()<deadline: time.sleep(.02)
                    self.assertEqual(len(devices),2)
                    self.assertTrue(b.snapshot()['connected'])
                    b._opened_at=time.monotonic()-3
                    time.sleep(.1)
                    self.assertEqual(devices[1].sent.count(b'HOME\n'),1)
                    b.disconnect();self.assertFalse(b.snapshot()['auto_connect']);self.assertFalse(b.snapshot()['connected'])
                    time.sleep(.7);self.assertEqual(len(devices),2)
                finally:b.shutdown()

class TestAutoHomeRelease(unittest.TestCase):
    def test_ui_release_does_not_cancel_auto_home(self):
        from unittest.mock import Mock
        b=NanoBridge();b._firmware_seen=True;b._serial=Mock();b._auto_home_pending=True
        b.command('MOVE STOP')
        self.assertTrue(b._auto_home_pending)
        b._serial.write.assert_not_called()
        b.command('STOP')
        self.assertFalse(b._auto_home_pending)
        b._serial.write.assert_called_with(b'STOP\n')

class TestCalibrationRange(unittest.TestCase):
    def test_six_metre_echo_still_supported(self):
        b=NanoBridge(); b._firmware_seen=True
        b._on_line(b'{"type":"echo","distance_mm":6000,"servo1_us":1400,"servo2_deg":30,"servo2_us":1200,"scan_phase_deg":0}')
        self.assertEqual(b.snapshot()['echoes'][0]['distance_mm'],6000)
        self.assertEqual(b.snapshot()['echoes'][0]['servo2_us'],1200)

class TestReviewedTelemetry(unittest.TestCase):
    def test_unknown_board_cannot_supply_echo_coordinates(self):
        b=NanoBridge()
        b._on_line(b'{"type":"echo","distance_mm":500,"servo1_us":1400,"servo2_deg":30}')
        self.assertEqual(b.snapshot()['echoes'], [])

    def test_latest_sample_keeps_acquisition_angles_even_if_status_changes(self):
        import json
        b=NanoBridge(); b._firmware_seen=True
        b._on_line(b'{"type":"echo","distance_mm":1000,"servo1_us":1400,"servo2_deg":30}')
        b._on_line(json.dumps(dict(type='status',device='OMNI_NANO',protocol=3,homed=True,
            limit_pressed=False,servo1_us=2300,servo2_deg=-30,orientation_ready=True)).encode())
        snapshot=b.snapshot(since=999)
        self.assertEqual(snapshot['echoes'], [])
        self.assertEqual(snapshot['latest_echo']['servo1_us'], 1400)
        self.assertEqual(snapshot['latest_echo']['servo2_deg'], 30)
        self.assertTrue(snapshot['status']['orientation_ready'])
        self.assertNotEqual(NanoBridge().snapshot()['session_id'],snapshot['session_id'])
        session=snapshot['session_id'];b._generation+=1
        self.assertNotEqual(b.snapshot()['session_id'],session)

class TestHomeSetupReset(unittest.TestCase):
    def test_home_cycle_clears_old_coordinates_for_all_clients(self):
        b=NanoBridge();b._firmware_seen=True
        b._on_line(b'{"type":"echo","distance_mm":1000,"servo1_us":2200,"servo2_deg":30}')
        self.assertIsNotNone(b.snapshot()['latest_echo'])
        for cycle in (1,2):
            b._on_line(b'{"type":"event","event":"homing_up"}')
            snapshot=b.snapshot()
            self.assertEqual(snapshot['home_cycle'],cycle)
            self.assertEqual(snapshot['echoes'],[])
            self.assertIsNone(snapshot['latest_echo'])
        b._on_line(b'{"type":"echo","distance_mm":1000,"servo1_us":1400,"servo2_deg":0}')
        self.assertEqual(b.snapshot()['latest_echo']['servo2_deg'],0)

class TestHomeTerminal(unittest.TestCase):
    def test_home_progress_is_logged_and_exposed(self):
        from unittest.mock import patch
        import json
        b=NanoBridge()
        data=dict(type='status',device='OMNI_NANO',protocol=3,homed=False,limit_pressed=True,servo1_us=1500,servo2_deg=0,motor='home',home_confirming=True,home_confirm_ms=1200)
        with patch('builtins.print') as out:
            b._on_line(json.dumps(data).encode())
            self.assertTrue(any('LOW=1200/2000 ms' in c.args[0] for c in out.call_args_list))
            self.assertEqual(b.snapshot()['status']['home_confirm_ms'],1200)
            data.update(homed=True,motor='idle',home_confirming=False,home_confirm_ms=0)
            b._on_line(json.dumps(data).encode())
            self.assertTrue(any('HOME OK' in c.args[0] for c in out.call_args_list))

class TestSensorConsole(unittest.TestCase):
    def test_valid_distance_and_acquisition_coordinates_print_when_paused(self):
        from unittest.mock import patch
        b=NanoBridge();b._firmware_seen=True;b._status={'scanning':False}
        with patch('builtins.print') as output:
            b._on_line(b'{"type":"echo","distance_mm":200,"servo1_us":1400,"servo2_deg":30}')
        line=output.call_args.args[0]
        self.assertIn('SONAR d=20.0 cm',line)
        self.assertIn('D9=30 deg',line)
        self.assertIn('Y=10.0 cm',line)
        self.assertIn('scan_diameter=20.0 cm',line)

    def test_invalid_frame_never_prints_a_measurement(self):
        from unittest.mock import patch
        b=NanoBridge();b._firmware_seen=True
        with patch('builtins.print') as output:
            b._on_line(b'{"type":"echo","distance_mm":5,"servo1_us":1400,"servo2_deg":0}')
        output.assert_not_called()

    def test_waiting_message_and_measurement_rate_limit(self):
        from unittest.mock import patch
        import json
        b=NanoBridge()
        status=dict(type='status',device='OMNI_NANO',protocol=3,homed=True,
            limit_pressed=False,servo1_us=1400,servo2_deg=0,motor='idle',sonar_ok=False)
        with patch('builtins.print') as output, patch('hardware_bridge.time.monotonic',return_value=10) as clock:
            for _ in range(3):b._on_line(json.dumps(status).encode())
            self.assertEqual(sum('SONAR CHUA CO MAU DO HOP LE' in c.args[0] for c in output.call_args_list),1)
            echo=b'{"type":"echo","distance_mm":300,"servo1_us":1400,"servo2_deg":0}'
            b._on_line(echo);b._on_line(echo)
            self.assertEqual(sum('SONAR d=' in c.args[0] for c in output.call_args_list),1)
            clock.return_value=10.3;b._on_line(echo)
            self.assertEqual(sum('SONAR d=' in c.args[0] for c in output.call_args_list),2)

class TestSerialFraming(unittest.TestCase):
    def test_split_status_survives_serial_timeout(self):
        b=NanoBridge()
        raw=b'{"type":"status","device":"OMNI_NANO","protocol":3,"homed":true,"limit_pressed":false,"servo1_us":1500,"servo2_deg":0}\n'
        for part in (raw[:8],raw[8:43],raw[43:-1]): b._consume(part)
        self.assertFalse(b._firmware_seen)
        b._consume(raw[-1:]);self.assertTrue(b._firmware_seen)

    def test_invalid_phase_is_not_forwarded(self):
        b=NanoBridge()
        b._on_line(b'{"type":"echo","distance_mm":100,"servo1_us":1500,"servo2_deg":0,"scan_phase_deg":"wrong"}')
        self.assertEqual(b.snapshot()['echoes'],[])

    def test_invalid_status_cannot_verify_board(self):
        b=NanoBridge()
        b._on_line(b'{"type":"status","device":"OMNI_NANO","protocol":3,"homed":"yes","limit_pressed":false,"servo1_us":1500,"servo2_deg":0}')
        self.assertFalse(b._firmware_seen)

if __name__ == "__main__": unittest.main()
