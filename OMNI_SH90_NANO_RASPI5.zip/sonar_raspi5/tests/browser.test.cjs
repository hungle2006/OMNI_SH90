'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const{spawn}=require('node:child_process'),{pathToFileURL}=require('node:url');
const{chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright'):'playwright');
const root=path.resolve(__dirname,'..'),qa=process.env.SONAR_QA_DIR||path.join(os.tmpdir(),'sh90-classic-qa');
test('SH90 classic: reference layout and all simulated controls',{timeout:180000},async t=>{
  let browser;const server=spawn(process.env.SONAR_PYTHON||'python3',['server.py','--no-browser','--port','18765'],{cwd:root,stdio:['ignore','pipe','pipe']});
  try{
    await fs.mkdir(qa,{recursive:true});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Server startup timeout')),5000);server.stdout.once('data',()=>{clearTimeout(timer);resolve();});server.once('error',reject);server.once('exit',c=>reject(new Error('Server exited '+c)));});
    browser=await chromium.launch({headless:true,...(process.env.SONAR_BROWSER_PATH?{executablePath:process.env.SONAR_BROWSER_PATH}:{}),args:process.env.SONAR_SINGLE_PROCESS?['--no-sandbox','--no-zygote','--single-process']:[]});
    const context=await browser.newContext({viewport:{width:1280,height:1024},screen:{width:2560,height:1600},deviceScaleFactor:1,acceptDownloads:true}),page=await context.newPage();
    page.setDefaultTimeout(7000);const errors=[],external=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url())&&!r.url().startsWith('http://127.0.0.1:18765'))external.push(r.url());});
    t.beforeEach(async()=>{await page.evaluate(()=>document.querySelectorAll('dialog[open]').forEach(d=>d.close()));});
    await page.goto('http://127.0.0.1:18765');await page.waitForFunction(()=>document.querySelectorAll('.parameter-row').length===14);await page.waitForTimeout(250);
    const snapshot=()=>page.evaluate(()=>{window.dispatchEvent(new Event('pagehide'));return JSON.parse(localStorage.getItem('sh90-classic-v3'));});
    const field=async k=>{await page.click('[data-field="'+k+'"]');};
    const choose=async(k,v)=>{await field(k);const index=await page.evaluate(({k,v})=>{const c=window.SonarCore.PARAMS[k];if(c)return c.values.indexOf(v);const extra={orientation:['bow','north'],palette:['classic','night','green'],aspect:['original','wide'],rings:[true,false],ship:[true,false],cursorVisible:[true,false],labels:[true,false],trails:[true,false],sweep:[true,false],sound:[true,false],sector:[360,180,120,90,60,30],quality:['balanced','high'],simSpeed:[.5,1,2,4]};return extra[k].indexOf(v);},{k,v});await page.click('[data-choice="'+index+'"]');assert.equal((await snapshot()).state[k],v);};
    const numeric=async(k,v)=>{await field(k);await page.locator('#numericValue').fill(String(v));await page.locator('#numericValue').press('Tab');assert.equal((await snapshot()).state[k],v);};
    const pixelStats=()=>page.evaluate(()=>{const c=document.querySelector('#sonar'),d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let hot=0,hash=0;for(let i=0;i<d.length;i+=4){if(Math.floor(i/(c.width*4))<c.height*.13)continue;if(d[i]>190&&d[i+1]<130&&d[i+2]<90)hot++;hash=(Math.imul(hash,31)+d[i]+d[i+1]*3+d[i+2]*7)>>>0;}return{hot,hash};});
    await t.test('default frame follows the reference photo',async()=>{
      const result=await page.evaluate(()=>{const f=document.querySelector('#instrument').getBoundingClientRect(),s=document.querySelector('#sonar').getBoundingClientRect(),panel=document.querySelector('.control-panel').getBoundingClientRect();return{ratio:f.width/f.height,scopeRatio:s.width/s.height,panelFraction:panel.width/f.width,rows:document.querySelectorAll('.parameter-row').length,labels:[...document.querySelectorAll('.vertical-tabs button')].map(b=>b.textContent),tabsVertical:getComputedStyle(document.querySelector('.vertical-tabs button')).writingMode};});
      assert.ok(Math.abs(result.ratio-1.25)<.01);assert.ok(result.scopeRatio<1.13&&result.scopeRatio>1);assert.ok(result.panelFraction<.19);assert.equal(result.rows,14);assert.deepEqual(result.labels,['Horizontal','Display','Setup','Objects']);assert.equal(result.tabsVertical,'vertical-rl');
      assert.equal(await page.locator('.device-title').textContent(),'Simrad SH90');assert.equal(await page.locator('#modeButton').textContent(),'Mode: Bow Up');assert.equal(await page.locator('#propertyTitle').textContent(),'TX Power:');assert.equal(await page.locator('.choice-option.active').textContent(),'LOW');
      const s=await snapshot();assert.equal(s.state.sweep,false);assert.equal(s.state.bearing,60);assert.equal(s.cursor.range,13);assert.ok(Math.abs((s.cursor.bearing-s.state.heading+360)%360-268)<.01);
    });
    await t.test('all 14 Horizontal controls update live parameters',async()=>{
      await page.keyboard.press('Space');
      await choose('range',75);await choose('range',50);await numeric('tilt',-20);await numeric('tilt',-2);await numeric('bearing',359);await numeric('bearing',60);await numeric('gain',25);await numeric('gain',19);
      for(const[k,values]of Object.entries({pulse:['SHORT','LONG','FM AUTO'],beam:['NARROW','WIDE','AUTO'],frequency:[85,120,114],tvg:[10,40,20],agc:['OFF','HIGH','MEDIUM'],noise:['OFF','HIGH','MEDIUM'],pp:['OFF','HIGH','MEDIUM']}))for(const v of values)await choose(k,v);
      await numeric('rcg',5);await numeric('rcg',2);await numeric('bottom',5);await numeric('bottom',0);
      await choose('tx','MEDIUM');await choose('tx','FULL');await choose('tx','LOW');
      assert.equal((await snapshot()).training.visited.frequency.length,3);
    });
    await t.test('pulse/beam/filters alter echoes; TX OFF clears signal',async()=>{
      await choose('pulse','SHORT');await page.waitForTimeout(100);const short=await pixelStats();await choose('pulse','LONG');await page.waitForTimeout(100);const long=await pixelStats();assert.ok(long.hot>short.hot*1.15);await choose('pulse','FM AUTO');
      await choose('beam','NARROW');await page.waitForTimeout(100);const narrow=await pixelStats();await choose('beam','WIDE');await page.waitForTimeout(100);const wide=await pixelStats();assert.ok(wide.hot>narrow.hot);await choose('beam','AUTO');
      await choose('noise','OFF');await page.waitForTimeout(100);const a=await pixelStats();await choose('noise','HIGH');await page.waitForTimeout(100);const b=await pixelStats();assert.notEqual(a.hash,b.hash);await choose('noise','MEDIUM');
      await choose('tx','OFF');await page.waitForTimeout(100);assert.equal((await pixelStats()).hot,0);assert.equal(await page.locator('#warningsButton').textContent(),'1 Warnings');await choose('tx','LOW');await page.waitForTimeout(100);assert.ok((await pixelStats()).hot>100);
    });
    await t.test('Close/Help property actions and numeric keyboard limits',async()=>{
      await page.click('[data-action="closeProperty"]');assert.equal(await page.locator('#propertyClosed').isVisible(),true);await field('tx');assert.equal(await page.locator('#propertyBox').isVisible(),true);
      await page.click('.property-footer [data-action="contextHelp"]');assert.ok((await page.locator('#contextHelpText').textContent()).includes('TX Power'));await page.click('#helpDialog [data-action="closeDialog"]');
      await page.locator('#sonar').focus();await page.keyboard.press('a');assert.equal((await snapshot()).state.bearing,59);await page.keyboard.press('d');assert.equal((await snapshot()).state.bearing,60);
      await page.keyboard.press('j');await page.keyboard.press('k');await page.keyboard.press('s');await page.keyboard.press('w');assert.equal((await snapshot()).state.tilt,-2);assert.equal((await snapshot()).state.gain,19);
    });
    await t.test('Display tab switches all display fields and preserves coordinates',async()=>{
      await page.click('[data-tab="display"]');for(const v of ['night','green','classic'])await choose('palette',v);
      for(const k of ['rings','ship','cursorVisible','labels','trails','sweep']){await choose(k,false);await choose(k,true);}await choose('sweep',false);
      await choose('sector',30);await page.waitForTimeout(100);const sector=await pixelStats();await choose('sector',360);await page.waitForTimeout(100);assert.ok((await pixelStats()).hot>sector.hot*2);
      await choose('quality','high');await choose('quality','balanced');await choose('aspect','wide');assert.equal(Math.round((await page.locator('#instrument').boundingBox()).width),1280);await choose('aspect','original');
      const before=await snapshot();await choose('orientation','north');const after=await snapshot();assert.equal(before.cursor.bearing,after.cursor.bearing);assert.equal(before.state.bearing,after.state.bearing);await choose('orientation','bow');
    });
    async function markEcho(i){
      const point=await page.evaluate(i=>{const C=window.SonarCore,c=C.getScenario('reference').contacts[i],el=document.querySelector('#sonar'),rect=el.getBoundingClientRect(),p=C.screenPoint(c.bearing,c.range,C.DEFAULTS,Number(el.dataset.radius),Number(el.dataset.cx),Number(el.dataset.cy));return{x:rect.x+p.x,y:rect.y+p.y};},i);await page.mouse.click(point.x,point.y);await page.keyboard.press('Enter');
    }
    await t.test('measurement cursor is independent of bearing; training marks score',async()=>{
      await page.click('[data-tab="sonar"]');await markEcho(0);await markEcho(1);const snap=await snapshot();assert.equal(snap.state.bearing,60);assert.ok(Math.abs(snap.cursor.bearing-222)<.2);assert.equal(snap.training.hits,2);assert.equal(snap.marks.length,2);
      await page.keyboard.press('4');assert.equal(await page.locator('#marksList .mark-row').count(),2);await page.click('#tab-objects [data-action="training"]');assert.equal(await page.locator('#trainingScore').textContent(),'100%');
      await page.locator('#traineeInput').fill('Học viên thử');await page.locator('#traineeInput').press('q');assert.equal((await snapshot()).state.range,50);await page.locator('#traineeInput').fill('Học viên thử');
      const time=(await snapshot()).time;await page.waitForTimeout(150);assert.equal((await snapshot()).time,time);await page.click('#trainingDialog [data-action="closeDialog"]');
    });
    const readDownload=async promise=>fs.readFile(await (await promise).path());
    await t.test('exports JSON/CSV/PNG and restores the session',async()=>{
      await page.keyboard.press('3');await page.click('[data-action="training"]');const json=page.waitForEvent('download');await page.click('#trainingDialog [data-action="report"]');const report=JSON.parse((await readDownload(json)).toString());assert.equal(report.progress.score,100);assert.equal(report.marks.length,2);assert.equal(report.markBearingReference,'true-north');
      const csv=page.waitForEvent('download');await page.click('#trainingDialog [data-action="reportCSV"]');assert.ok((await readDownload(csv)).toString().includes('Học viên thử'));
      await page.click('#trainingDialog [data-action="closeDialog"]');await page.keyboard.press('2');const png=page.waitForEvent('download');await page.click('[data-action="screenshot"]');const bytes=await readDownload(png);assert.equal(bytes.subarray(1,4).toString(),'PNG');assert.ok(bytes.length>10000);
      await snapshot();await page.reload();await page.waitForTimeout(150);const restored=await snapshot();assert.equal(restored.marks.length,2);assert.equal(restored.paused,true);assert.equal(restored.training.hits,2);
    });
    await t.test('Setup controls, physical button simulator and simulated alarms work',async()=>{
      await page.click('[data-tab="setup"]');await numeric('heading',270);await numeric('heading',250);await numeric('speed',.5);await numeric('speed',0);await choose('simSpeed',2);await choose('simSpeed',1);await choose('sound',true);await choose('sound',false);
      await page.locator('#sonar').focus();await page.keyboard.press('F2');assert.equal(await page.locator('#controlsDialog').isVisible(),true);await page.click('#controlsDialog [data-adjust="gain:1"]');assert.equal((await snapshot()).state.gain,20);await page.selectOption('[data-direct-param="tx"]','OFF');assert.equal((await snapshot()).state.tx,'OFF');await page.selectOption('[data-direct-param="tx"]','LOW');await page.click('#controlsDialog [data-action="closeDialog"]');
      await page.click('[data-action="alerts"]');for(const type of ['warning','operator','system'])await page.click('[data-test-alarm="'+type+'"]');assert.equal(await page.locator('#systemAlarmsButton').textContent(),'1 Sys. Alarms');await page.click('[data-action="ackAlarms"]');assert.equal(await page.locator('.alarm-row.ack').count(),3);await page.click('[data-action="clearAlarms"]');assert.equal(await page.locator('#warningsButton').textContent(),'0 Warnings');await page.click('#alertsDialog [data-action="closeDialog"]');
    });
    await t.test('finished reports freeze even if settings change',async()=>{
      await page.click('[data-action="training"]');await page.click('[data-action="finish"]');assert.equal(await page.locator('#summaryDialog').isVisible(),true);await page.click('#summaryDialog [data-action="closeDialog"]');
      await page.locator('#sonar').focus();await page.keyboard.press('e');await page.click('[data-action="training"]');const d=page.waitForEvent('download');await page.click('#trainingDialog [data-action="report"]');const report=JSON.parse((await readDownload(d)).toString());assert.ok(report.endedAt);assert.equal(report.settings.range,50);await page.click('#trainingDialog [data-action="closeDialog"]');
    });
    await t.test('instructor can add, edit, delete and import echoes safely',async()=>{
      await page.click('[data-action="instructor"]');await page.check('#truthCheck');assert.equal(await page.locator('#truthBadge').isVisible(),true);await page.click('#instructorDialog [data-action="addEcho"]');await page.locator('#echoId').fill('TEST01');await page.locator('#echoRange').fill('20');await page.click('[data-action="saveEcho"]');assert.ok((await snapshot()).scenario.contacts.some(c=>c.id==='TEST01'));
      await page.click('[data-action="instructor"]');await page.click('[data-edit-echo="0"]');await page.locator('#echoRange').fill('21');await page.click('[data-action="saveEcho"]');assert.equal((await snapshot()).scenario.contacts[0].range,21);
      await page.click('[data-action="instructor"]');await page.click('[data-edit-echo="0"]');await page.click('[data-action="deleteEcho"]');assert.equal((await snapshot()).scenario.contacts.some(c=>c.id==='E01'),false);
      await page.click('[data-action="instructor"]');await page.setInputFiles('#scenarioFile',{name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{"noise":9,"contacts":[]}')});await page.waitForFunction(()=>document.querySelector('#toast').textContent.includes('Không nhập được'));
      const imported={name:'<img src=x onerror=alert(1)>',seed:7,noise:.3,duration:0,contacts:[{id:'Z01',range:20,bearing:140,strength:.9,width:15,depth:1}]};await page.setInputFiles('#scenarioFile',{name:'good.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(imported))});await page.waitForTimeout(100);assert.equal((await snapshot()).scenario.name,imported.name);assert.equal(await page.locator('img[src=x]').count(),0);
      await page.click('[data-action="instructor"]');await page.locator('#seedInput').fill('15');await page.locator('#countInput').fill('6');await page.click('[data-action="generate"]');assert.equal((await snapshot()).scenario.contacts.length,6);
    });
    await t.test('reference layout and menu labels fit multiple laptop resolutions',async()=>{
      await page.click('[data-action="training"]');await page.selectOption('#scenarioSelect','reference');await page.click('#trainingDialog [data-action="closeDialog"]');await page.click('[data-tab="sonar"]');await field('tx');
      for(const size of [{width:1280,height:1024},{width:1366,height:768},{width:1440,height:900},{width:1920,height:1080}]){
        await page.setViewportSize(size);await page.waitForTimeout(150);await page.screenshot({path:path.join(qa,'classic-'+size.width+'x'+size.height+'.png')});
        const clips=await page.evaluate(()=>{const area=document.querySelector('.menu-pages').getBoundingClientRect();return[...document.querySelectorAll('.parameter-row')].filter(b=>{const r=b.getBoundingClientRect(),s=b.querySelector('span').getBoundingClientRect();return r.bottom>area.bottom+1||s.left<r.left-1||s.right>r.right+1;}).map(b=>b.textContent);});assert.deepEqual(clips,[],'Every label and row must fit '+size.width);
      }
      await page.keyboard.press('f');await page.waitForFunction(()=>Boolean(document.fullscreenElement));await page.evaluate(()=>document.exitFullscreen());
    });
    await t.test('standalone index.html and full HTML run without network assets',async()=>{
      await page.goto(pathToFileURL(path.join(root,'index.html')).href);await page.waitForFunction(()=>document.querySelectorAll('.parameter-row').length===14);await page.keyboard.press('e');assert.equal((await snapshot()).state.range,75);assert.deepEqual(external,[]);assert.deepEqual(errors,[]);
    });
    await context.close();
  }finally{if(browser)await browser.close();server.kill();}
});
