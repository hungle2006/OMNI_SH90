'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs/promises'),{pathToFileURL}=require('node:url');
const{chromium}=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'','playwright'));
const root=path.resolve(__dirname,'..'),qa=process.env.SONAR_QA_DIR||'/tmp/sonar-v3-qa';
test('v3 operating panel and offline workflows',{timeout:120000},async t=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.SONAR_BROWSER_PATH,args:['--no-sandbox','--no-zygote','--single-process']});
 try{
  await fs.mkdir(qa,{recursive:true});const ctx=await browser.newContext({viewport:{width:1366,height:768},screen:{width:2560,height:1600},acceptDownloads:true}),page=await ctx.newPage(),errors=[],network=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url());});page.setDefaultTimeout(7000);
  const snap=()=>page.evaluate(()=>{window.dispatchEvent(new Event('pagehide'));return JSON.parse(localStorage.getItem('sh90-classic-v3'));});
  const press=async key=>{await page.evaluate(()=>document.querySelector('#sonar').focus());await page.keyboard.press(key);};
  const click=action=>page.locator('#controlsDialog [data-action="'+action+'"]').click();
  await page.goto(pathToFileURL(path.join(root,'index.html')).href);await page.waitForFunction(()=>window.SonarCore&&document.querySelectorAll('.parameter-row').length===14);
  t.beforeEach(async()=>page.evaluate(()=>document.querySelectorAll('dialog[open]').forEach(d=>d.close())));
  await t.test('layout fills laptops; fullscreen overrides original ratio',async()=>{
   for(const size of [{width:1366,height:768},{width:1440,height:900},{width:1920,height:1080},{width:1280,height:720}]){
    await page.setViewportSize(size);await page.waitForTimeout(80);let rect=await page.locator('#instrument').boundingBox();assert.equal(Math.round(rect.x),0);assert.equal(Math.round(rect.y),0);assert.equal(Math.round(rect.width),size.width);assert.equal(Math.round(rect.height),size.height);
    await press('2');await page.click('[data-field="aspect"]');await page.click('[data-choice="0"]');const original=await page.locator('#instrument').boundingBox();assert.ok(Math.abs(original.width/original.height-1.25)<.01);await press('f');await page.waitForFunction(()=>Boolean(document.fullscreenElement));await page.waitForTimeout(80);
    rect=await page.locator('#instrument').boundingBox();const view=await page.evaluate(()=>({width:innerWidth,height:innerHeight}));assert.equal(Math.round(rect.width),view.width);assert.equal(Math.round(rect.height),view.height);assert.equal(Math.round(rect.x),0);assert.equal(Math.round(rect.y),0);assert.ok(await page.locator('.control-panel').isVisible());
    await page.evaluate(()=>document.exitFullscreen());await page.click('[data-field="aspect"]');await page.click('[data-choice="1"]');
   }
   await page.setViewportSize({width:1366,height:768});await press('1');await page.screenshot({path:path.join(qa,'v3-widescreen.png')});
  });
  await t.test('F2 exposes all groups, vertical settings and trackball',async()=>{
   await press('F2');assert.equal(await page.locator('.hardware-groups fieldset').count(),8);assert.equal(await page.locator('#knobControls .knob').count(),4);await page.locator('[data-demo-param="rangeV"]').selectOption('100');await page.locator('[data-demo-param="gainV"]').fill('25');await page.locator('[data-demo-param="gainV"]').press('Tab');const s=await snap();assert.equal(s.state.rangeV,100);assert.equal(s.state.gainV,25);
   await page.locator('[data-cursor="right"]').click();assert.equal((await snap()).cursor.bearing,(s.cursor.bearing+2)%360);await page.screenshot({path:path.join(qa,'v3-operating-panel.png')});await page.keyboard.press('F2');assert.equal(await page.locator('#controlsDialog').isVisible(),false);
  });
  await t.test('automatic scans run, pause and stop manually',async()=>{
   await press('u');await press('b');const a=await snap();await page.waitForTimeout(1100);const b=await snap();assert.notEqual(a.state.tilt,b.state.tilt);assert.notEqual(a.state.bearing,b.state.bearing);assert.equal(b.state.autoTilt,true);assert.equal(b.state.autoTrain,true);
   await press('Space');const frozen=await snap();await page.waitForTimeout(250);assert.equal((await snap()).state.bearing,frozen.state.bearing);await press('a');await press('w');assert.equal((await snap()).state.autoTrain,false);assert.equal((await snap()).state.autoTilt,false);await press('Space');
  });
  await t.test('zoom geometry preserves inverse cursor coordinates; off centre toggles',async()=>{
   const radius=Number(await page.locator('#sonar').getAttribute('data-radius'));await press('z');await page.waitForTimeout(80);assert.ok(Number(await page.locator('#sonar').getAttribute('data-radius'))>radius*1.9);
   const p=await page.evaluate(()=>{const el=document.querySelector('#sonar'),r=el.getBoundingClientRect();return{x:r.x+Number(el.dataset.cx)+Number(el.dataset.radius)*.25,y:r.y+Number(el.dataset.cy)};});await page.mouse.click(p.x,p.y);const s=await snap();assert.ok(Math.abs(s.cursor.range-s.state.range*.25)<.2);await press('z');await press('x');assert.equal((await snap()).state.offCentre,true);await press('x');assert.equal((await snap()).state.offCentre,false);
  });
  await t.test('hidden menu recovers by visible button; four modes include vertical canvas',async()=>{
   await press('m');assert.equal(await page.locator('.control-panel').isVisible(),false);await page.click('.scope-tools [data-action="menu"]');assert.equal(await page.locator('.control-panel').isVisible(),true);
   for(const k of ['5','6','7','8']){await press(k);const s=await snap();assert.equal(s.state.orientation,['6','8'].includes(k)?'north':'bow');assert.equal(await page.locator('#verticalSonar').isVisible(),['7','8'].includes(k));}
   await page.waitForTimeout(100);const v=await page.evaluate(()=>{const c=document.querySelector('#verticalSonar');return{w:c.width,h:c.height};});assert.ok(v.w>400&&v.h>100);await press('F2');await page.locator('[data-direct-param="bearing"]').fill('268');await page.locator('[data-direct-param="bearing"]').press('Tab');await page.locator('[data-direct-param="tilt"]').fill('-2');await page.locator('[data-direct-param="tilt"]').press('Tab');await page.keyboard.press('F2');await page.waitForTimeout(120);
   const coloured=await page.evaluate(()=>{const c=document.querySelector('#verticalSonar'),d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=0;i<d.length;i+=4)if(d[i]>190&&d[i+1]<130&&d[i+2]<90)n++;return n;});assert.ok(coloured>5,'Vertical slice must draw scenario echoes');await page.screenshot({path:path.join(qa,'v3-vertical.png')});await press('5');
  });
  await t.test('three symbols are separate from scored marks',async()=>{
   const attempts=(await snap()).training.attempts;await press('y');await press('0');await press('g');const s=await snap();assert.deepEqual(s.symbols.map(m=>m.kind),['circle','own','gear']);assert.equal(s.training.attempts,attempts);assert.equal(s.symbols[1].range,0);await press('F2');await click('deleteSymbol');assert.deepEqual((await snap()).symbols.map(m=>m.kind),['own','gear']);await page.keyboard.press('F2');
  });
  await t.test('Store/Recall includes PNG download and timed sequence',async()=>{
   await press('F7');await press('F6');assert.equal(await page.locator('.gallery-item').count(),1);await page.click('.gallery-item');const d=page.waitForEvent('download');await page.click('[data-action="downloadRecalled"]');const bytes=await fs.readFile(await(await d).path());assert.equal(bytes.subarray(1,4).toString(),'PNG');await page.click('#recallDialog [data-action="storeRecall"]');
   await page.selectOption('#storeMode','sequence');await page.click('#storeDialog [data-action="recordImage"]');assert.ok((await page.locator('#recordStatus').textContent()).includes('RECORDING'));await page.click('#storeDialog [data-action="closeDialog"]');await page.waitForTimeout(2200);await press('F7');await press('F6');assert.ok(await page.locator('.gallery-item').count()>=3);assert.ok((await page.locator('#recordStatus').textContent()).includes('STOPPED'));await page.selectOption('#storeMode','single');for(let i=0;i<15;i++)await page.click('#storeDialog [data-action="recordImage"]');assert.equal(await page.locator('.gallery-item').count(),12);assert.ok((await page.locator('#toast').textContent()).includes('12 ảnh'));await page.click('#storeDialog [data-action="closeDialog"]');
  });
  await t.test('user presets recall settings while keeping lesson and symbols',async()=>{
   await press('F2');await click('userSettings');await page.fill('#profileName0','Demo test');await page.click('[data-save-profile="0"]');const saved=await snap();await page.click('#settingsDialog [data-action="closeDialog"]');await press('k');assert.notEqual((await snap()).state.gain,saved.state.gain);await press('F2');await click('userSettings');await page.click('[data-load-profile="0"]');const r=await snap();assert.equal(r.state.gain,saved.state.gain);assert.equal(r.scenario.id,saved.scenario.id);assert.equal(r.symbols.length,saved.symbols.length);await page.click('#settingsDialog [data-action="closeDialog"]');
  });
  await t.test('power and timed hull movement gate TX; mute acknowledges alarms',async()=>{
   await press('F3');assert.equal((await snap()).state.power,false);await press('p');assert.equal((await snap()).state.tx,'OFF');await press('F3');await press('l');assert.equal((await snap()).state.hull,'LOWERING');await press('p');assert.equal((await snap()).state.tx,'OFF');await page.waitForTimeout(3300);assert.equal((await snap()).state.hull,'DOWN');await press('p');assert.notEqual((await snap()).state.tx,'OFF');
   await press('i');assert.equal((await snap()).state.hull,'HOISTING');assert.equal((await snap()).state.tx,'OFF');await page.waitForTimeout(3300);assert.equal((await snap()).state.hull,'UP');await press('F4');assert.equal((await snap()).state.sound,false);assert.ok((await snap()).acknowledged.includes('hull_up'));await press('l');await page.waitForTimeout(3300);await press('p');
  });
  await t.test('context menus and reload keep symbols, profiles and manual state',async()=>{
   await press('v');assert.equal(await page.locator('#shortcutTitle').textContent(),'View · Menu trình bày');await page.click('#shortcutDialog [data-action="select"]');await press('o');await page.click('#shortcutDialog [data-action="circleSymbol"]');await page.click('#shortcutDialog [data-action="select"]');const old=await snap();await page.reload();await page.waitForTimeout(150);const s=await snap();assert.equal(s.paused,true);assert.equal(s.symbols.length,old.symbols.length);assert.equal(s.state.autoTilt,false);assert.equal(s.state.autoTrain,false);await press('F2');await click('userSettings');assert.equal(await page.inputValue('#profileName0'),'Demo test');assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
  });
  await t.test('v2 sessions migrate to wide layout with saved marks',async()=>{
   await page.evaluate(()=>document.querySelectorAll('dialog[open]').forEach(d=>d.close()));const old=await snap();old.version='2.0.0';old.state.aspect='original';delete old.symbols;
   await page.addInitScript(old=>{localStorage.removeItem('sh90-classic-v3');localStorage.setItem('sh90-classic-v2',JSON.stringify(old));},old);await page.reload();await page.waitForTimeout(150);const migrated=await snap();assert.equal(migrated.version,'3.0.0');assert.equal(migrated.state.aspect,'wide');assert.equal(migrated.paused,true);assert.equal(migrated.marks.length,old.marks.length);assert.equal(migrated.symbols.length,0);
  });
  await ctx.close();
 }finally{await browser.close();}
});
