'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../web/core.js');

test('seed generates the same exercise, and a different seed changes contacts',()=>{
  assert.deepEqual(C.generateScenario(123,6,.5),C.generateScenario(123,6,.5));
  assert.notDeepEqual(C.generateScenario(123,6,.5).contacts,C.generateScenario(124,6,.5).contacts);
});
test('controls clamp correctly; true bearing wraps across north',()=>{
  const s={...C.DEFAULTS,range:.07,gain:40,bearing:359,tilt:-90};
  C.adjust(s,'range',-1);assert.equal(s.range,.07);
  C.adjust(s,'gain',1);assert.equal(s.gain,40);
  C.adjust(s,'bearing',1);assert.equal(s.bearing,0);
  C.adjust(s,'tilt',-1);assert.equal(s.tilt,-90);
  assert.equal(C.normalize('range',51),undefined);
  assert.equal(C.normalize('gain',NaN),undefined);
});
test('screen coordinate round-trip preserves true bearing and range in both modes',()=>{
  for(const orientation of ['bow','north'])for(const heading of [0,90,268,359])for(const bearing of [0,1,90,180,359]){
    const s={...C.DEFAULTS,orientation,heading};
    const p=C.screenPoint(bearing,23,s,300);
    const measured=C.screenToPolar(p.x,p.y,s,300);
    assert.ok(Math.abs(C.angleDiff(measured.bearing,bearing))<1e-8);
    assert.ok(Math.abs(measured.range-23)<1e-8);
  }
});
test('TX, Gain, Tilt and Bottom Filter change synthetic echo strength',()=>{
  const c=C.getScenario('reference').contacts[0],s={...C.DEFAULTS};
  assert.equal(C.signalStrength(c,{...s,tx:'OFF'}),0);
  assert.ok(C.signalStrength(c,{...s,gain:30})>C.signalStrength(c,{...s,gain:10}));
  assert.ok(C.signalStrength(c,{...s,tilt:-2})>C.signalStrength(c,{...s,tilt:-60}));
  const b={...c,kind:'bottom'};
  assert.ok(C.signalStrength(b,{...s,bottom:4})<C.signalStrength(b,s));
  const scenario=C.getScenario('clutter');
  assert.ok(C.noiseLevel({...s,noise:'HIGH'},scenario)<C.noiseLevel({...s,noise:'OFF'},scenario));
});
test('mark scoring uses true coordinates and excludes invisible/off-range echoes',()=>{
  const scenario=C.getScenario('reference'),s={...C.DEFAULTS,range:50},c=scenario.contacts[0];
  assert.equal(C.findEcho({bearing:c.bearing,range:c.range},scenario,s,0).id,c.id);
  assert.equal(C.findEcho({bearing:c.bearing,range:c.range},scenario,{...s,tx:'OFF'},0),null);
  assert.equal(C.findEcho({bearing:c.bearing,range:c.range},scenario,{...s,range:25},0),null);
  assert.equal(C.findEcho({bearing:60,range:49},scenario,s,0),null);
  assert.equal(C.findEcho({bearing:c.bearing,range:c.range},scenario,{...s,sector:30,bearing:60},0),null);
});
test('lesson completion follows actions; finished report remains frozen',()=>{
  const scenario=C.getScenario('reference'),s={...C.DEFAULTS,range:50},training=new C.Training(scenario,'Học viên');
  training.update(s,0);assert.equal(training.steps.filter(s=>s.done).length,0);
  training.record('range',75,1);training.record('range',50,2);training.record('gain',20,3);s.gain=20;
  training.record('north',true,4);training.mark(true,5);training.mark(true,6);training.update(s,6);
  assert.equal(training.steps.filter(s=>s.done).length,4);
  const marks=[{label:'M01',range:10,bearing:20}];training.finish(s,marks,7);
  s.range=100;marks.push({label:'M02'});training.mark(true,8);training.record('gain',1,9);training.update(s,10);
  const report=training.report(s,marks,scenario);
  assert.equal(report.settings.range,50);assert.equal(report.marks.length,1);
  assert.equal(report.elapsedSeconds,7);assert.equal(report.marksOnEcho,2);assert.equal(report.progress.score,100);
});
test('scenario import limits file structure and rejects invalid coordinates',()=>{
  const valid={name:'Demo',seed:2,noise:.5,contacts:[{id:'E01',range:20,bearing:359,strength:.9,width:10}]};
  assert.equal(C.validateScenario(valid).contacts[0].depth,1);
  for(const patch of [{noise:9},{seed:-1},{contacts:Array(61).fill(valid.contacts[0])},
    {contacts:[{...valid.contacts[0],bearing:360}]},{contacts:[{...valid.contacts[0],range:-2}]},
    {contacts:[{...valid.contacts[0],strength:NaN}]},{contacts:[...valid.contacts,...valid.contacts]}]){
    assert.throws(()=>C.validateScenario({...valid,...patch}));
  }
});
test('automatic scan is bounded, deterministic and crosses north smoothly',()=>{
  assert.equal(C.scanValue(-20,10,0,8,-90,0),-20);
  assert.equal(C.scanValue(-20,10,2,8,-90,0),-15);
  assert.equal(C.scanValue(-20,10,6,8,-90,0),-25);
  for(let i=0;i<1000;i++){const tilt=C.scanValue(-2,40,i/10,8,-90,0);assert.ok(tilt>=-90&&tilt<=0);}
  assert.equal(C.wrap(C.scanValue(359,60,3,12,-360,720)),29);
});
