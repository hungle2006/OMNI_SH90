#pragma once
#include <deque>
struct SoftwareSerial{
 std::deque<uint8_t> incoming;int requests=0;
 SoftwareSerial(int,int){}void begin(unsigned long){}void listen(){}
 void write(uint8_t){requests++;}int available(){return incoming.size();}
 int read(){int b=incoming.front();incoming.pop_front();return b;}
};
