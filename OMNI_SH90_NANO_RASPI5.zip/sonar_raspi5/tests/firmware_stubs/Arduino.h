#pragma once
#include <stdint.h>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <utility>
struct __FlashStringHelper {};
#define F(s) reinterpret_cast<const __FlashStringHelper*>(s)
constexpr int LOW=0,HIGH=1,INPUT_PULLUP=2,OUTPUT=3,A1=15,A2=16;
inline unsigned long mockUs=0;
inline int switchLevel=HIGH;
inline void pinMode(int,int){}
inline int digitalRead(int){return switchLevel;}
inline int mockPins[32]={};
inline std::vector<std::pair<unsigned long,int>> stepEdges;
inline void digitalWrite(int pin,int v){if(pin==5&&mockPins[pin]!=v)stepEdges.push_back({mockUs,v});mockPins[pin]=v;}
inline void delayMicroseconds(int n){mockUs+=n;}
inline unsigned long micros(){return mockUs;}
inline unsigned long millis(){return mockUs/1000;}
template<class T>T constrain(T v,T a,T b){return std::max(a,std::min(b,v));}
inline long map(long v,long a,long b,long c,long d){return (v-a)*(d-c)/(b-a)+c;}
struct MockSerial{
 std::string output;
 void begin(unsigned long){} int available(){return 0;} char read(){return 0;}
 void print(const __FlashStringHelper* s){output+=reinterpret_cast<const char*>(s);}
 template<class T>void print(T v){std::ostringstream ss;ss<<v;output+=ss.str();}
 void print(float v,int){print(v);}
 template<class T>void println(T v){print(v);output+='\n';}
};
inline MockSerial Serial;
