#pragma once
struct Servo {int value=1500,writes=0;bool enabled=false;void attach(int,int,int){enabled=true;}bool attached(){return enabled;}void writeMicroseconds(int v){value=v;writes++;}};
